//"use strict";
console.log("agarplus_v2m6 ver.N325");

function trace(s) {
	console.log(s);
}

//160515_A201
//S停止なしで

//160615_A202
//_MOVEタスク, setInterval --> setTimeoutに
//ゲームのメインループvuにtry-catch

//160615_A203
//S停止ありで

//160616_A204
//minimap描画タスク, setInterval --> setTimeoutに

//160618_A300
//custom_client_entry.jsを吸収
//ソース構成を調整

//160619_A301
//joinRoom,leaveRoomを繰り返してしまう問題を修正
//マップの先輩/敵色分け表示,質量表示を実装

//160620_A302
//joinRoom,leaveRoomを長めの周期で繰り返すように修正

//160620_A303
//sao, caffeソース共通化

//160620_A304
//チームテキスト色分け実装
//フォントの縁の太さを調整

//160622_A305
//分裂順序マーカー(分裂予測)を実装..途中

//160623_A308
//joinRoomで対象サーバuriをデータに含めて送信するように修正
//パーティーコードを使わないように変更,チーム名とプレイヤ名を独立して保持・利用するように変更

//160624_A310
//コードを整理
//分裂予測マーカ表示を実装

//160625_A311
//クロスヘアカーソル表示実装

//160625_A312
//分裂時クロスへアカーソル色変更

//160625_A312
//チーム名が空の時joinRoomでダミーのチーム名(NOTAG)挿入
//タグなしのプレイヤのスキン・チャットが他のタグの人から見える問題を修正

//160626_A314
//スプリットインジケータがonの時にしか分裂マーカーが表示されない問題を修正

//160628_A315
//Ogar内に追加実装したマップ・チャットに対応

//A316_160629
//マップ上のプレイヤの位置を表示する際の座標の補間を実装
//観戦中にも自分のマップ上での位置が送信される問題を修正

//A317_160630
//Ogarを操作するためのリモートコンソールを実装

//A318_160701
//?localhost=1接続でリモートコンソールが機能しない問題を修正

//A319_160701
//マップでプレイヤの位置が常時2点間で飛ぶように動く不具合を修正
//botのスキンを取得しようとするのを抑止

//A320_160702
//デプロイ環境などにより、agar本家に飛んでしまう場合がある問題を改善

//A321_160702
//リーダーボードのクラン名色分けを実装

//A322_160702
//リーダーボードのクラン名追加
//ステータスサーバの人数表示実装
//クライアント,グローバル設定定義を調整

//N322_160715
//modification for NBK.io
//-Implement function connectTo()
//-Translate setting texts(in setupOption()), Japanese to English
//-Change default theme colors
//-Remove concatenation of team tag and name
//-Remove team colors in minimap
//-Remove team colors in text-label of cells
//-Change forts for English environment

//N323_160716
//-Add team separation options for Chat/Map/Skin by team tag

//N324_160716
//-Re-translate hotkey setting GUI, Japanese to English.

//N325_160718
//remove teamtag from player name

//var TargetSite = 'sao';
//var TargetSite = 'caffe';
//var TargetSite = 'dev';
//var TargetSite = 'custom';
//var TargetSite = 'packed';

var GameServerAddress = '';	//プライベートサーバーのアドレス
//var MapServerAddress = null;	//マップ/チャットデータ共有サーバのアドレス
//var StatusServerAddress = null;	//ステータスサーバのアドレス
//var CommonTeamName = '';		//チーム名
//var WebPageTitle = 'agar client';
//var LeaderBoardCaption = 'leaderboard';


//共通タグ/パーティーコード
var FixedPartyCode = "";
var CommonTeamName = "LeL";

var WebPageTitle = "NBK.io";
var LeaderBoardCaption = "Leaderboard";

var UseOgarMapImpl = true;
var RemoteConsoleEnabled = false;
var EnableLeaderboardTeamColoring = true;

var UseMapSepration = true;
var UseChatSeparation = false;
var UseSkinSepration = false;

//var UseOgarMapImpl = false;
//var Status_Server = "agar-ss.ddo.jp:88";
//var EnableLeaderboardTeamColoring = false;

/*
if(TargetSite == 'sao') {
	GameServerAddress = "ws://agar-ss.ddo.jp:2525";
	MapServerAddress = "ws://agar-ss.ddo.jp:9655";
	StatusServerAddress = "http://agar-ss.ddo.jp:88";
	CommonTeamName = "【先輩】";
	WebPageTitle = "senapi-agar.online";
	LeaderBoardCaption = "せんぱい";
	UseOgarMapImpl = false;
	EnableLeaderboardTeamColoring = true;
} else if(TargetSite == 'caffe') {
	GameServerAddress = "ws://agar-ss.ddo.jp:25250";
	StatusServerAddress = "http://agar-ss.ddo.jp:880";
	UseOgarMapImpl = true;
	//SharedDataServerAddress = "ws://agar-ss.ddo.jp:9655";
	CommonTeamName = "【先輩】";
	WebPageTitle = "caffe";
	LeaderBoardCaption = "caffe";
} else if(TargetSite == 'dev') {
	//PrivateServerAddress = "ws://agar-ss.ddo.jp:25250";
	//PrivateServerAddress = "ws://agar-ss.ddo.jp:8421";
	//GameServerAddress = "ws://localhost:8421";
	GameServerAddress = "ws://localhost:1500";
	MapServerAddress = "ws://localhost:9700";
	StatusServerAddress = "http://localhost:889";
	UseOgarMapImpl = true;
	//UseOgarMapImpl = false;
	CommonTeamName = "";
	WebPageTitle = "labo";
	LeaderBoardCaption = "debug";
	EnableLeaderboardTeamColoring = true;
} else if(TargetSite == 'custom') {
	GameServerAddress = "ws://url-for-custom-site:1234";
	MapServerAddress = "ws://url-for-custom-site:5678";
	StatusServerAddress = "http://agar-ss.ddo.jp:88";
	CommonTeamName = "";
	WebPageTitle = "agar pvp";
	LeaderBoardCaption = "Leaderboard";
	UseOgarMapImpl = false;
	RemoteConsoleEnabled = false;
	EnableLeaderboardTeamColoring = false;
} else if(TargetSite == 'packed') {
	GameServerAddress = location.origin.replace(/^http/, 'ws');
	MapServerAddress = "";
	CommonTeamName = "";
	WebPageTitle = "agar site";
	LeaderBoardCaption = "AGAR_EX";
	UseOgarMapImpl = true;
}
*/

//function makePrivateServerAddressEx() {
//	//urlのクエリ文字列によるローカル接続オプション対応
//	var uri = PrivateServerAddress;
//	var html_query_str = location.search;
//	var req_local_connection = html_query_str === "?localhost=1";
//	if(req_local_connection) {
//		var port = PrivateServerAddress.split(":")[2];
//		uri = "ws://localhost:" + port;
//	}
//	return uri;
//}

//var PrivateServerAddressEx = makePrivateServerAddressEx();

/*
//trace(location.hostname);
var gameServerPort = 2525;
var mapServerPort = 9635;
PrivateServerAddress = 'ws://' + location.hostname + gameServerPort;
SharedDataServerAddress = 'ws://' + location.hostname + mapServerPort;
*/


function connectTo(ip){
	console.log("connecting to " + ip);
	connect("ws://"+ip);
}

function initialize_game_client() {
	'use strict';

	function modifyUrlForLocalhostConnection(uri){
		var parts = uri.split(":");
		var protocol = parts[0];
		var host = parts[1];
		var port = parts[2];
		/*
		regex(url, /^([^\:]\:\/\/)([^\:])\:([0-9]+));
		var protocol = $0;
		var host = $1;
		var port = $2;
		*/

		if(location.search === "?localhost=1") {
			host = '//localhost';
			//var port = uri.split(":")[2];
			//uri = "ws://localhost:" + port;
		}
		return protocol + ':' + host + ':' + port;
	}


	class utils {
		//引数が1文字以上の文字列かどうか判定
		static CheckValidString(s) {
			return (typeof (s) == 'string' || s instanceof String) && s != '';
		}

		static ByteArrayToDataView(ar) {
			var arbuf = new Uint8Array(ar.length);
			for(var i = 0; i < ar.length; i++) {
				arbuf[i] = ar;
			}
			return new DataView(arbuf);
		}

		static ByteArrayFromDataView(view) {
			var ar = [];
			var pos = 0;
			while(pos < view.byteLength) {
				ar[pos] = view.getUint8(pos);
				pos++;
			}
			return ar;
		}

		// static ArrayBufferToArray(arbuf){
		// 	var ar = [];
		// 	for(var i = 0; i < arbuf.length; i++){
		// 		ar[i] = arbuf[i];
		// 	}
		// 	return ar;
		// }

		static vmap(val, s0, s1, d0, d1) {
			return (val - s0) * (d1 - d0) / (s1 - s0) + d0;
		}

		static clamp(val, a, b) {
			return Math.min(a, (Math.max(val, b)));
		}


		static makeColor(code) {
			//0xARGB
			var a = (code >> 12 & 0x0F) * 1.0 / 15;
			if(a == 0.0) a = 1.0;
			var r = parseInt((code >> 8 & 0x0F) * 255 / 15);
			var g = parseInt((code >> 4 & 0x0F) * 255 / 15);
			var b = parseInt((code >> 0 & 0x0F) * 255 / 15);
			return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
		}
	}

	class nums {
		static lerp(a, b, m) {
			return (1.0 - m) * a + m * b;
			//return a + m * (b - a);
		}

		static easyFilter(y, x, m){
			return y * m + (1.0 - m) * x;
		}
	}


	//サーバーの地域の設定をクリア
	//本家のサーバーに接続しようとしてプライベートサーバーから飛ばされるのを抑止
	localStorage.removeItem("location");

	//HTML調整？, 400
	{
		//var _jquery = $;
		function vb(vc, vb) {
			var vd = $('<div class="minicolors" />'),
				ve = $.minicolors['defaults'];
			vc.attr('data-opacity');
			var vf;
			vc.data('minicolors-initialized') || (vb = $.extend(1, {}, ve, vb), vd.addClass('minicolors-theme-' + vb.theme)['toggleClass']('minicolors-with-opacity', vb.opacity)['toggleClass']('minicolors-no-data-uris', 1 !== vb.dataUris), void (0) !== vb.position && $.each(vb.position['split'](' '), function() {
				vd.addClass('minicolors-position-' + this)
			}), vf = 'rgb' === vb.format ? vb.opacity ? '25' : '20' : vb.keywords ? '11' : '7', vc.addClass('minicolors-input')['data']('minicolors-initialized', 0)['data']('minicolors-settings', vb)['prop']('size', vf)['wrap'](vd)['after']('<div class="minicolors-panel minicolors-slider-' + vb.control + '"><div class="minicolors-slider minicolors-sprite"><div class="minicolors-picker"></div></div><div class="minicolors-opacity-slider minicolors-sprite"><div class="minicolors-picker"></div></div><div class="minicolors-grid minicolors-sprite"><div class="minicolors-grid-inner"></div><div class="minicolors-picker"><div></div></div></div></div>'), vb.inline || (vc.after('<span class="minicolors-swatch minicolors-sprite"><span class="minicolors-swatch-color"></span></span>'), vc.next('.minicolors-swatch')['on']('click', function(va) {
				va.preventDefault();
				vc.focus()
			})), vc.parent()['find']('.minicolors-panel')['on']('selectstart', function() {
				return 0
			})['end'](), vb.inline && vc.parent()['addClass']('minicolors-inline'), vj(vc, 0), vc.data('minicolors-initialized', 1))
		}

		function vf(va) {
			var vb = va.parent();
			va.removeData('minicolors-initialized')['removeData']('minicolors-settings')['removeProp']('size')['removeClass']('minicolors-input');
			vb.before(va)['remove']()
		}

		function vg(va) {
			var vb = va.parent(),
				vd = vb.find('.minicolors-panel'),
				ve = va.data('minicolors-settings');
			!va.data('minicolors-initialized') || va.prop('disabled') || vb.hasClass('minicolors-inline') || vb.hasClass('minicolors-focus') || (vh(), vb.addClass('minicolors-focus'), vd.stop(1, 1)['fadeIn'](ve.showSpeed, function() {
				ve.show && ve.show['call'](va.get(0))
			}))
		}

		function vh() {
			$('.minicolors-focus')['each'](function() {
				var vb = $(this),
					vd = vb.find('.minicolors-input'),
					ve = vb.find('.minicolors-panel'),
					vf = vd.data('minicolors-settings');
				ve.fadeOut(vf.hideSpeed, function() {
					vf.hide && vf.hide['call'](vd.get(0));
					vb.removeClass('minicolors-focus')
				})
			})
		}

		function vd(va, vb, vd) {
			var vf = va.parents('.minicolors')['find']('.minicolors-input'),
				vi = vf.data('minicolors-settings'),
				vj = va.find('[class$=-picker]'),
				vg = va.offset()['left'],
				vh = va.offset()['top'],
				vk = Math.round(vb.pageX - vg),
				vl = Math.round(vb.pageY - vh);
			vd = vd ? vi.animationSpeed : 0;
			var vm, vn, vo, vp;
			vb.originalEvent['changedTouches'] && (vk = vb.originalEvent['changedTouches'][0]['pageX'] - vg, vl = vb.originalEvent['changedTouches'][0]['pageY'] - vh);
			0 > vk && (vk = 0);
			0 > vl && (vl = 0);
			vk > va.width() && (vk = va.width());
			vl > va.height() && (vl = va.height());
			va.parent()['is']('.minicolors-slider-wheel') && vj.parent()['is']('.minicolors-grid') && (vm = 75 - vk, vn = 75 - vl, vo = Math.sqrt(vm * vm + vn * vn), vp = Math.atan2(vn, vm), 0 > vp && (vp += 2 * Math.PI), 75 < vo && (vo = 75, vk = 75 - 75 * Math.cos(vp), vl = 75 - 75 * Math.sin(vp)), vk = Math.round(vk), vl = Math.round(vl));
			va.is('.minicolors-grid') ? vj.stop(1)['animate']({
				top: vl + 'px',
				left: vk + 'px'
			}, vd, vi.animationEasing, function() {
				ve(vf, va)
			}) : vj.stop(1)['animate']({
				top: vl + 'px'
			}, vd, vi.animationEasing, function() {
				ve(vf, va)
			})
		}

		function ve(va, vb) {
			function vd(va, vb) {
				var vc, vf;
				return va.length && vb ? (vc = va.offset()['left'], vf = va.offset()['top'], {
					x: vc - vb.offset()['left'] + va.outerWidth() / 2,
					y: vf - vb.offset()['top'] + va.outerHeight() / 2
				}) : null
			}

			var ve, vf, vi, vj, vg, vk;
			vj = va.val();
			var vh = va.attr('data-opacity');
			vg = va.parent();
			var vm = va.data('minicolors-settings'),
				vp = vg.find('.minicolors-swatch');
			vk = vg.find('.minicolors-grid');
			var vo = vg.find('.minicolors-slider'),
				vq = vg.find('.minicolors-opacity-slider');
			vi = vk.find('[class$=-picker]');
			var vr = vo.find('[class$=-picker]'),
				vs = vq.find('[class$=-picker]');
			vi = vd(vi, vk);
			vr = vd(vr, vo);
			vs = vd(vs, vq);
			if(vb.is('.minicolors-grid, .minicolors-slider, .minicolors-opacity-slider')) {
				switch(vm.control) {
					case 'wheel':
						vj = vk.width() / 2 - vi.x;
						vg = vk.height() / 2 - vi.y;
						vk = Math.sqrt(vj * vj + vg * vg);
						vj = Math.atan2(vg, vj);
						0 > vj && (vj += 2 * Math.PI);
						75 < vk && (vk = 75, vi.x = 69 - 75 * Math.cos(vj), vi.y = 69 - 75 * Math.sin(vj));
						vf = vl(vk / 0.75, 0, 100);
						ve = vl(180 * vj / Math.PI, 0, 360);
						vi = vl(100 - Math.floor(vr.y * (100 / vo.height())), 0, 100);
						vj = v_25({
							h: ve,
							s: vf,
							b: vi
						});
						vo.css('backgroundColor', v_25({
							h: ve,
							s: vf,
							b: 100
						}));
						break;
					case 'saturation':
						ve = vl(parseInt(vi.x * (360 / vk.width()), 10), 0, 360);
						vf = vl(100 - Math.floor(vr.y * (100 / vo.height())), 0, 100);
						vi = vl(100 - Math.floor(vi.y * (100 / vk.height())), 0, 100);
						vj = v_25({
							h: ve,
							s: vf,
							b: vi
						});
						vo.css('backgroundColor', v_25({
							h: ve,
							s: 100,
							b: vi
						}));
						vg.find('.minicolors-grid-inner')['css']('opacity', vf / 100);
						break;
					case 'brightness':
						ve = vl(parseInt(vi.x * (360 / vk.width()), 10), 0, 360);
						vf = vl(100 - Math.floor(vi.y * (100 / vk.height())), 0, 100);
						vi = vl(100 - Math.floor(vr.y * (100 / vo.height())), 0, 100);
						vj = v_25({
							h: ve,
							s: vf,
							b: vi
						});
						vo.css('backgroundColor', v_25({
							h: ve,
							s: vf,
							b: 100
						}));
						vg.find('.minicolors-grid-inner')['css']('opacity', 1 - vi / 100);
						break;
					default:
						ve = vl(360 - parseInt(vr.y * (360 / vo.height()), 10), 0, 360), vf = vl(Math.floor(vi.x * (100 / vk.width())), 0, 100), vi = vl(100 - Math.floor(vi.y * (100 / vk.height())), 0, 100), vj = v_25({
							h: ve,
							s: vf,
							b: vi
						}), vk.css('backgroundColor', v_25({
							h: ve,
							s: 100,
							b: 100
						}))
				}
				;
				(vh = vm.opacity ? parseFloat(1 - vs.y / vq.height())['toFixed'](2) : 1, vm.opacity && va.attr('data-opacity', vh), 'rgb' === vm.format) ? (vo = vv(vj), vh = '' === va.attr('data-opacity') ? 1 : vl(parseFloat(va.attr('data-opacity'))['toFixed'](2), 0, 1), !isNaN(vh) && vm.opacity || (vh = 1), vf = 1 >= va.minicolors('rgbObject')['a'] && vo && vm.opacity ? 'rgba(' + vo.lb_r_strokeColor + ', ' + vo.g + ', ' + vo.b + ', ' + parseFloat(vh) + ')' : 'rgb(' + vo.lb_r_strokeColor + ', ' + vo.g + ', ' + vo.b + ')') : vf = vz(vj, vm.letterCase);
				va.val(vf)
			}
			;
			vp.find('span')['css']({
				backgroundColor: vj,
				opacity: vh
			});
			vn(va, vf, vh)
		}

		function vj(vb, vd) {
			var vf, ve, vi, vj, vk, vg, vh, vt;
			vt = vb.parent();
			var vu = vb.data('minicolors-settings'),
				vv = vt.find('.minicolors-swatch'),
				vo = vt.find('.minicolors-grid'),
				vq = vt.find('.minicolors-slider'),
				vw = vt.find('.minicolors-opacity-slider'),
				vs = vo.find('[class$=-picker]'),
				vx = vq.find('[class$=-picker]'),
				vy = vw.find('[class$=-picker]');
			switch(v_21(vb.val()) ? (vf = v_23(vb.val()), vk = vl(parseFloat(v_22(vb.val()))['toFixed'](2), 0, 1), vk && vb.attr('data-opacity', vk)) : vf = vz(vr(vb.val(), 1), vu.letterCase), vf || (vf = vz(vp(vu.defaultValue, 1), vu.letterCase)), ve = v_26(vf), vj = vu.keywords ? $.map(vu.keywords['split'](','), function(vb) {
				return $.trim(vb.toLowerCase())
			}) : [], vg = '' !== vb.val() && -1 < $.inArray(vb.val()['toLowerCase'](), vj) ? vz(vb.val()) : v_21(vb.val()) ? vm(vb.val()) : vf, vd || vb.val(vg), vu.opacity && (vi = '' === vb.attr('data-opacity') ? 1 : vl(parseFloat(vb.attr('data-opacity'))['toFixed'](2), 0, 1), isNaN(vi) && (vi = 1), vb.attr('data-opacity', vi), vv.find('span')['css']('opacity', vi), vh = vl(vw.height() - vw.height() * vi, 0, vw.height()), vy.css('top', vh + 'px')), 'transparent' === vb.val()['toLowerCase']() && vv.find('span')['css']('opacity', 0), vv.find('span')['css']('backgroundColor', vf), vu.control) {
				case 'wheel':
					vh = vl(Math.ceil(0.75 * ve.s), 0, vo.height() / 2);
					vt = ve.h * Math.PI / 180;
					vj = vl(75 - Math.cos(vt) * vh, 0, vo.width());
					vh = vl(75 - Math.sin(vt) * vh, 0, vo.height());
					vs.css({
						top: vh + 'px',
						left: vj + 'px'
					});
					vh = 150 - ve.b / (100 / vo.height());
					'' === vf && (vh = 0);
					vx.css('top', vh + 'px');
					vq.css('backgroundColor', v_25({
						h: ve.h,
						s: ve.s,
						b: 100
					}));
					break;
				case 'saturation':
					vj = vl(5 * ve.h / 12, 0, 150);
					vh = vl(vo.height() - Math.ceil(ve.b / (100 / vo.height())), 0, vo.height());
					vs.css({
						top: vh + 'px',
						left: vj + 'px'
					});
					vh = vl(vq.height() - ve.s * (vq.height() / 100), 0, vq.height());
					vx.css('top', vh + 'px');
					vq.css('backgroundColor', v_25({
						h: ve.h,
						s: 100,
						b: ve.b
					}));
					vt.find('.minicolors-grid-inner')['css']('opacity', ve.s / 100);
					break;
				case 'brightness':
					vj = vl(5 * ve.h / 12, 0, 150);
					vh = vl(vo.height() - Math.ceil(ve.s / (100 / vo.height())), 0, vo.height());
					vs.css({
						top: vh + 'px',
						left: vj + 'px'
					});
					vh = vl(vq.height() - ve.b * (vq.height() / 100), 0, vq.height());
					vx.css('top', vh + 'px');
					vq.css('backgroundColor', v_25({
						h: ve.h,
						s: ve.s,
						b: 100
					}));
					vt.find('.minicolors-grid-inner')['css']('opacity', 1 - ve.b / 100);
					break;
				default:
					vj = vl(Math.ceil(ve.s / (100 / vo.width())), 0, vo.width()), vh = vl(vo.height() - Math.ceil(ve.b / (100 / vo.height())), 0, vo.height()), vs.css({
						top: vh + 'px',
						left: vj + 'px'
					}), vh = vl(vq.height() - ve.h / (360 / vq.height()), 0, vq.height()), vx.css('top', vh + 'px'), vo.css('backgroundColor', v_25({
						h: ve.h,
						s: 100,
						b: 100
					}))
			}
			;
			vb.data('minicolors-initialized') && vn(vb, vg, vi)
		}

		function vn(va, vb, vd) {
			var ve = va.data('minicolors-settings'),
				vf = va.data('minicolors-lastChange');
			vf && vf.value === vb && vf.opacity === vd || (va.data('minicolors-lastChange', {
				value: vb,
				opacity: vd
			}), ve.change && (ve.changeDelay ? (clearTimeout(va.data('minicolors-changeTimeout')), va.data('minicolors-changeTimeout', setTimeout(function() {
				ve.change['call'](va.get(0), vb, vd)
			}, ve.changeDelay))) : ve.change['call'](va.get(0), vb, vd)), va.trigger('change')['trigger']('input'))
		}

		function vk(vb) {
			var vd = vr($(vb)['val'](), 1),
				vd = vv(vd);
			vb = $(vb)['attr']('data-opacity');
			return vd ? (void (0) !== vb && $.extend(vd, {
				a: parseFloat(vb)
			}), vd) : null
		}

		function vi(vb, vd) {
			var ve = vr($(vb)['val'](), 1),
				ve = vv(ve),
				vf = $(vb)['attr']('data-opacity');
			return ve ? (void (0) === vf && (vf = 1), vd ? 'rgba(' + ve.lb_r_strokeColor + ', ' + ve.g + ', ' + ve.b + ', ' + parseFloat(vf) + ')' : 'rgb(' + ve.lb_r_strokeColor + ', ' + ve.g + ', ' + ve.b + ')') : null
		}

		function vz(va, vb) {
			return 'uppercase' === vb ? va.toUpperCase() : va.toLowerCase()
		}

		function vr(va, vb) {
			return va = va.replace(/^#/g, ''), va.match(/^[A-F0-9]{3,6}/gi) ? 3 !== va.length && 6 !== va.length ? '' : (3 === va.length && vb && (va = va[0] + va[0] + va[1] + va[1] + va[2] + va[2]), '#' + va) : ''
		}

		function vm(va, vb) {
			var vd = va.replace(/[^\d,.]/g, '')['split'](',');
			return vd[0] = vl(parseInt(vd[0], 10), 0, 255), vd[1] = vl(parseInt(vd[1], 10), 0, 255), vd[2] = vl(parseInt(vd[2], 10), 0, 255), vd[3] && (vd[3] = vl(parseFloat(vd[3], 10), 0, 1)), vb ? {
				lb_r_strokeColor: vd[0],
				g: vd[1],
				b: vd[2],
				a: vd[3] ? vd[3] : null
			} : 'undefined' != typeof vd[3] && 1 >= vd[3] ? 'rgba(' + vd[0] + ', ' + vd[1] + ', ' + vd[2] + ', ' + vd[3] + ')' : 'rgb(' + vd[0] + ', ' + vd[1] + ', ' + vd[2] + ')'
		}

		function vp(va, vb) {
			return v_21(va) ? vm(va) : vr(va, vb)
		}

		function vl(va, vb, vd) {
			return vb > va && (va = vb), va > vd && (va = vd), va
		}

		function v_21(va) {
			return (va = va.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i)) && 4 === va.length ? 1 : 0
		}

		function v_22(va) {
			return (va = va.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+(\.\d{1,2})?|\.\d{1,2})[\s+]?/i)) && 6 === va.length ? va[4] : '1'
		}

		function v_23(va) {
			return va = va.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i), va && 4 === va.length ? '#' + ('0' + parseInt(va[1], 10).toString(16))['slice'](-2) + ('0' + parseInt(va[2], 10).toString(16))['slice'](-2) + ('0' + parseInt(va[3], 10).toString(16))['slice'](-2) : ''
		}

		function v_24(vb) {
			var vd = [vb.lb_r_strokeColor.toString(16), vb.g.toString(16), vb.b.toString(16)];
			return $.each(vd, function(va, vb) {
				1 === vb.length && (vd[va] = '0' + vb)
			}), '#' + vd.join('')
		}

		function v_25(va) {
			var vb = v_24,
				vd, ve, vf, vi = Math.round(va.h),
				vj = Math.round(255 * va.s / 100);
			va = Math.round(255 * va.b / 100);
			if(0 === vj) {
				vd = ve = vf = va
			} else {
				var vj = (255 - vj) * va / 255,
					vh = vi % 60 * (va - vj) / 60;
				360 === vi && (vi = 0);
				60 > vi ? (vd = va, vf = vj, ve = vj + vh) : 120 > vi ? (ve = va, vf = vj, vd = va - vh) : 180 > vi ? (ve = va, vd = vj, vf = vj + vh) : 240 > vi ? (vf = va, vd = vj, ve = va - vh) : 300 > vi ? (vf = va, ve = vj, vd = vj + vh) : 360 > vi ? (vd = va, ve = vj, vf = va - vh) : (vd = 0, ve = 0, vf = 0)
			}
			;
			return vb({
				lb_r_strokeColor: Math.round(vd),
				g: Math.round(ve),
				b: Math.round(vf)
			})
		}

		function v_26(va) {
			va = vv(va);
			var vb = {
				h: 0,
				s: 0,
				b: 0
			},
				vd = Math.max(va.lb_r_strokeColor, va.g, va.b),
				ve = vd - Math.min(va.lb_r_strokeColor, va.g, va.b);
			va = (vb.b = vd, vb.s = 0 !== vd ? 255 * ve / vd : 0, 0 !== vb.s ? va.lb_r_strokeColor === vd ? vb.h = (va.g - va.b) / ve : va.g === vd ? vb.h = 2 + (va.b - va.lb_r_strokeColor) / ve : vb.h = 4 + (va.lb_r_strokeColor - va.g) / ve : vb.h = -1, vb.h *= 60, 0 > vb.h && (vb.h += 360), vb.s *= 100 / 255, vb.b *= 100 / 255, vb);
			return 0 === va.s && (va.h = 360), va
		}

		function vv(va) {
			return va = parseInt(-1 < va.indexOf('#') ? va.substring(1) : va, 16), {
				lb_r_strokeColor: va >> 16,
				g: (65280 & va) >> 8,
				b: 255 & va
			}
		}

		$.minicolors = {
			defaults: {
				animationSpeed: 50,
				animationEasing: 'swing',
				change: null,
				changeDelay: 0,
				control: 'hue',
				dataUris: 1,
				defaultValue: '',
				format: 'hex',
				hide: null,
				hideSpeed: 100,
				inline: 0,
				keywords: '',
				letterCase: 'lowercase',
				opacity: 0,
				position: 'bottom left',
				show: null,
				showSpeed: 100,
				theme: 'default'
			}
		};
		$.extend($.fn, {
			minicolors: function(vd, ve) {
				switch(vd) {
					case 'destroy':
						return $(this)['each'](function() {
							vf($(this))
						}), $(this);
					case 'hide':
						return vh(), $(this);
					case 'opacity':
						return void (0) === ve ? $(this)['attr']('data-opacity') : ($(this)['each'](function() {
							vj($(this)['attr']('data-opacity', ve))
						}), $(this));
					case 'rgbObject':
						return vk($(this), 'rgbaObject' === vd);
					case 'rgbString':
						;
					case 'rgbaString':
						return vi($(this), 'rgbaString' === vd);
					case 'settings':
						return void (0) === ve ? $(this)['data']('minicolors-settings') : ($(this)['each'](function() {
							var vb = $(this)['data']('minicolors-settings') || {};
							vf($(this));
							$(this)['minicolors']($.extend(1, vb, ve))
						}), $(this));
					case 'show':
						return vg($(this)['eq'](0)), $(this);
					case 'value':
						return void (0) === ve ? $(this)['val']() : ($(this)['each'](function() {
							'object' == typeof ve ? (ve.opacity && $(this)['attr']('data-opacity', vl(ve.opacity, 0, 1)), ve.color && $(this)['val'](ve.color)) : $(this)['val'](ve);
							vj($(this))
						}), $(this));
					default:
						return 'create' !== vd && (ve = vd), $(this)['each'](function() {
							vb($(this), ve)
						}), $(this)
				}
			}
		});

		$(document)['on']('mousedown.minicolors touchstart.minicolors', function(vb) {
			$(vb.target)['parents']()['add'](vb.target)['hasClass']('minicolors') || vh()
		})['on']('mousedown.minicolors touchstart.minicolors', '.minicolors-grid, .minicolors-slider, .minicolors-opacity-slider', function(vb) {
			var ve = $(this);
			vb.preventDefault();
			$(document)['data']('minicolors-target', ve);
			vd(ve, vb, 1)
		})['on']('mousemove.minicolors touchmove.minicolors', function(vb) {
			var ve = $(document)['data']('minicolors-target');
			ve && vd(ve, vb)
		})['on']('mouseup.minicolors touchend.minicolors', function() {
			$(this)['removeData']('minicolors-target')
		})['on']('mousedown.minicolors touchstart.minicolors', '.minicolors-swatch', function(vb) {
			var vd = $(this)['parent']()['find']('.minicolors-input');
			vb.preventDefault();
			vg(vd)
		})['on']('focus.minicolors', '.minicolors-input', function() {
			var vb = $(this);
			vb.data('minicolors-initialized') && vg(vb)
		})['on']('blur.minicolors', '.minicolors-input', function() {
			var vb = $(this),
				vd = vb.data('minicolors-settings'),
				ve, vf, vi, vj, vh;
			vb.data('minicolors-initialized') && (ve = vd.keywords ? $.map(vd.keywords['split'](','), function(vb) {
				return $.trim(vb.toLowerCase())
			}) : [], '' !== vb.val() && -1 < $.inArray(vb.val()['toLowerCase'](), ve) ? vh = vb.val() : (v_21(vb.val()) ? vi = vm(vb.val(), 1) : (vf = vr(vb.val(), 1), vi = vf ? vv(vf) : null), vh = null === vi ? vd.defaultValue : 'rgb' === vd.format ? vm(vd.opacity ? 'rgba(' + vi.lb_r_strokeColor + ',' + vi.g + ',' + vi.b + ',' + vb.attr('data-opacity') + ')' : 'rgb(' + vi.lb_r_strokeColor + ',' + vi.g + ',' + vi.b + ')') : v_24(vi)), vj = vd.opacity ? vb.attr('data-opacity') : 1, 'transparent' === vh.toLowerCase() && (vj = 0), vb.closest('.minicolors')['find']('.minicolors-swatch > span')['css']('opacity', vj), vb.val(vh), '' === vb.val() && vb.val(vp(vd.defaultValue, 1)), vb.val(vz(vb.val(), vd.letterCase)))
		})['on']('keydown.minicolors', '.minicolors-input', function(vb) {
			var vd = $(this);
			if(vd.data('minicolors-initialized')) {
				switch(vb.keyCode) {
					case 9:
						vh();
						break;
					case 13:
						;
					case 27:
						vh(), vd.blur()
				}
			}
		})['on']('keyup.minicolors', '.minicolors-input', function() {
			var vb = $(this);
			vb.data('minicolors-initialized') && vj(vb, 1)
		})['on']('paste.minicolors', '.minicolors-input', function() {
			var vb = $(this);
			vb.data('minicolors-initialized') && setTimeout(function() {
				vj(vb, 1)
			}, 1)
		})
	}

	//var myApp = null;
	var gSelfMass = 100;
	var gSplitTimingTick = -1;
	var gSplitTimingDuration = 10;
	var conn2 = null;
	//var gLocalPlayerIdPerConnection = 0;  //接続するごとに乱数で決めるID
	var gPlayerSignature = '';
	var gPlayerInfoDict = {};

	var gIsPlaying = false;

	var gSelfTeamName = '';

	function checkIsTeammate(team){
		//return name.startsWith(gSelfTeamName);
		return team == gSelfTeamName;
	}

	// function setIsPlaying(val){
	// 	gIsPlaying = val;
	// 	console.log('gIsPlaying:' + gIsPlaying);
	// }

	//var extendedWebSocketDataHandlerProc = null;

	var testingVal = 29,
	//testingCount = 0,
	//testingInd = 0,
		spectateMode;

	var PRIVATE_SERVER_IP = '__';
	var i18n_lang = 'en';
	var i18n_dict = {
		en: {
			connecting: 'Connecting',
			connect_help: 'If you cannot connect to the servers, check if you have some anti virus or firewall blocking the connection.',
			play: 'Play',
			spectate: 'Spectate',
			login_and_play: 'Login and play',
			play_as_guest: 'Play as guest',
			share: 'Share',
			advertisement: 'Advertisement',
			privacy_policy: 'Privacy Policy',
			terms_of_service: 'Terms of Service',
			changelog: 'Changelog',
			instructions_mouse: 'Move your mouse to control your cell',
			instructions_space: 'Press <b>Space</b> to split',
			instructions_w: 'Press <b>W</b> to eject some mass',
			gamemode_ffa: 'FFA',
			gamemode_teams: 'Teams',
			gamemode_experimental: 'Experimental',
			region_select: ' -- Select a Region -- ',
			region_us_east: 'US East',
			region_us_west: 'US West',
			region_north_america: 'North America',
			region_south_america: 'South America',
			region_europe: 'Europe',
			region_turkey: 'Turkey',
			region_poland: 'Poland',
			region_east_asia: 'East Asia',
			region_russia: 'Russia',
			region_china: 'China',
			region_oceania: 'Oceania',
			region_australia: 'Australia',
			region_players: 'players',
			option_no_skins: 'No skins',
			option_no_names: 'No names',
			option_dark_theme: 'Dark theme',
			option_no_colors: 'No colors',
			option_show_mass: 'Show mass',
			leaderboard: 'Leaderboard',
			unnamed_cell: 'An unnamed cell',
			last_match_results: 'Last match results',
			score: 'Score',
			leaderboard_time: 'Leaderboard Time',
			mass_eaten: 'Mass Eaten',
			top_position: 'Top Position',
			position_1: 'First',
			position_2: 'Second',
			position_3: 'Third',
			position_4: 'Fourth',
			position_5: 'Fifth',
			position_6: 'Sixth',
			position_7: 'Seventh',
			position_8: 'Eighth',
			position_9: 'Ninth',
			position_10: 'Tenth',
			player_cells_eaten: 'Player Cells Eaten',
			survival_time: 'Survival Time',
			games_played: 'Games played',
			highest_mass: 'Highest mass',
			total_cells_eaten: 'Total cells eaten',
			total_mass_eaten: 'Total mass eaten',
			longest_survival: 'Longest survival',
			logout: 'Logout',
			stats: 'Stats',
			shop: 'Shop',
			party: 'Party',
			party_description: 'Play with your friends in the same map',
			create_party: 'Create',
			creating_party: 'Creating party...',
			join_party: 'Join',
			back_button: 'Back',
			joining_party: 'Joining party...',
			joined_party_instructions: 'You are now playing with this party:',
			party_join_error: 'There was a problem joining that party, please make sure the code is correct, or try creating another party',
			login_tooltip: 'Login with Facebook and get:<br/><br /><br />Start the game with more mass!<br />Level up to get even more starting mass!',
			create_party_instructions: 'Give this link to your friends:',
			join_party_instructions: 'Your friend should have given you a code, type it here:',
			"\x63\x6F\x6E\x74\x69\x6E\x75\x65": 'Continue',
			option_skip_stats: 'Skip stats',
			stats_food_eaten: 'food eaten',
			stats_highest_mass: 'highest mass',
			stats_time_alive: 'time alive',
			stats_leaderboard_time: 'leaderboard time',
			stats_cells_eaten: 'cells eaten',
			stats_top_position: 'top position',
			"": ''
		}
	};
	var i18n = i18n_dict[i18n_lang];

	var MOVING = true;
	//var myApp,
	var nodeList = [],
		chatRoom = null,
		minimap = null,
		socket = null,
		currentIP = '',
		//teamname = 'HKG',
		//defaultTeamname = 'HKG',
		//socketRetryInterval, isSocketReady = 0,
		//isChangeName = 0,
		conn = null,
		//reconnectCount = 0,
		updateLBCount = 0,
		tmpTeamname = '';

	var defaultImage = new Image;
	defaultImage.src = 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjwhLS0gR2VuZXJhdG9yOiBBZG9iZSBJbGx1c3RyYXRvciAxNi4yLjEsIFNWRyBFeHBvcnQgUGx1Zy1JbiAuIFNWRyBWZXJzaW9uOiA2LjAwIEJ1aWxkIDApICAtLT4NCjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+DQo8c3ZnIHZlcnNpb249IjEuMSIgaWQ9IkxheWVyXzEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiIHg9IjBweCIgeT0iMHB4Ig0KCSB3aWR0aD0iNTEycHgiIGhlaWdodD0iNTEycHgiIHZpZXdCb3g9IjAgMCA1MTIgNTEyIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1MTIgNTEyOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+DQo8Zz4NCgk8Zz4NCgkJPHBhdGggZD0iTTI1Niw0OEMxNDEuMSw0OCw0OCwxNDEuMSw0OCwyNTZzOTMuMSwyMDgsMjA4LDIwOGMxMTQuOSwwLDIwOC05My4xLDIwOC0yMDhTMzcwLjksNDgsMjU2LDQ4eiBNMjU2LDQ0Ni43DQoJCQljLTEwNS4xLDAtMTkwLjctODUuNS0xOTAuNy0xOTAuN2MwLTEwNS4xLDg1LjUtMTkwLjcsMTkwLjctMTkwLjdjMTA1LjEsMCwxOTAuNyw4NS41LDE5MC43LDE5MC43DQoJCQlDNDQ2LjcsMzYxLjEsMzYxLjEsNDQ2LjcsMjU2LDQ0Ni43eiIvPg0KCTwvZz4NCjwvZz4NCjxnPg0KCTxnPg0KCQk8cGF0aCBkPSJNMjU2LDk2Yy04OC40LDAtMTYwLDcxLjYtMTYwLDE2MGMwLDg4LjQsNzEuNiwxNjAsMTYwLDE2MGM4OC40LDAsMTYwLTcxLjYsMTYwLTE2MEM0MTYsMTY3LjYsMzQ0LjQsOTYsMjU2LDk2eiIvPg0KCTwvZz4NCjwvZz4NCjwvc3ZnPg0K';

	var customSkin = { "": defaultImage };

	var announcementTxt = '';
	var Action = {
		COPY: 'HKGAGARTOOLCOPY',
		IMAGE: 'HKGAGARTOOLIMAGE',
		FINISH: 'HKGAGARTOOLFINISH'
	};
	var isJoinedGame = 0,
		hotkeyConfig = {},
		hotkeyMapping = {},
		//teammateIdt = {},
		defaultHotkeyMapping = {},
		selectedHotkeyRow, chatCommand = {},
		isWindowFocus = 1,
		skinDownloadQueue = [],
		skinDownloadFail = {},
		toastQueue = [],
		defaultSkin = '';
	//gm;
	var defaultHotkeyMessageSend = {
		input_hk_send_msg1: 'Need backup!',
		input_hk_send_msg2: 'Need a teammate!',
		input_hk_send_msg3: 'Pop him!',
		input_hk_send_msg4: 'We need to run!',
		input_hk_send_msg5: 'Tricksplit!',
		input_hk_send_msg6: 'Lets bait! ',
		input_hk_send_msg7: 'Split into me!',
		input_hk_send_msg8: 'Feed me!',
		input_hk_send_msg9: 'Tank the virus!',
		input_hk_send_msg10: 'Roger that!'
	};
	var hkgIcon = {}, selected_profile_index = 0;

	var player_profile = function() {
		return [{
			name: 'Profile 1',
			team: CommonTeamName,
			skinurl: defaultSkin
		}, {
			name: 'Profile 2',
			team: CommonTeamName,
			skinurl: 'https://0314e603ee4bc70e0ea9f0c24bc13ef25b955c9d-www.googledrive.com/host/0B5_CBzj1HS4QckZxRXBGblJheEk/ring.png'
		}, {
			name: 'Profile 3',
			team: CommonTeamName,
			skinurl: 'https://0314e603ee4bc70e0ea9f0c24bc13ef25b955c9d-www.googledrive.com/host/0B5_CBzj1HS4QckZxRXBGblJheEk/circles.png'
		}, {
			name: 'Profile 4',
			team: CommonTeamName,
			skinurl: 'https://0314e603ee4bc70e0ea9f0c24bc13ef25b955c9d-www.googledrive.com/host/0B5_CBzj1HS4QckZxRXBGblJheEk/w.png'
		}, {
			name: 'Profile 5',
			team: CommonTeamName,
			skinurl: 'https://0314e603ee4bc70e0ea9f0c24bc13ef25b955c9d-www.googledrive.com/host/0B5_CBzj1HS4QckZxRXBGblJheEk/magatama.png'
		}, {
			name: 'Profile 6',
			team: CommonTeamName,
			skinurl: 'https://0314e603ee4bc70e0ea9f0c24bc13ef25b955c9d-www.googledrive.com/host/0B5_CBzj1HS4QckZxRXBGblJheEk/wolf.png'
		}, {
			name: 'Profile 7',
			team: CommonTeamName,
			skinurl: 'https://0314e603ee4bc70e0ea9f0c24bc13ef25b955c9d-www.googledrive.com/host/0B5_CBzj1HS4QckZxRXBGblJheEk/teki-Jupiter.png'
		}, {
			name: 'Profile 8',
			team: CommonTeamName,
			skinurl: 'https://0314e603ee4bc70e0ea9f0c24bc13ef25b955c9d-www.googledrive.com/host/0B5_CBzj1HS4QckZxRXBGblJheEk/teki-Venus.png'
		}, {
			name: 'Profile 9',
			team: CommonTeamName,
			skinurl: 'https://0314e603ee4bc70e0ea9f0c24bc13ef25b955c9d-www.googledrive.com/host/0B5_CBzj1HS4QckZxRXBGblJheEk/teki-earth.png'
		}, {
			name: 'Profile 10',
			team: CommonTeamName,
			skinurl: 'https://0314e603ee4bc70e0ea9f0c24bc13ef25b955c9d-www.googledrive.com/host/0B5_CBzj1HS4QckZxRXBGblJheEk/teki-sun.png'
		}];
	}();

	var escapeHtml = function() {
		var va = {
			"\x22": '&quot;',
			"\x26": '&amp;',
			"\x3C": '&lt;',
			"\x3E": '&gt;'
		};
		return function(vb) {
			return vb.replace(/[\"&<>]/g, function(vb) {
				return va[vb]
			})
		}
	}();
	function getHotkeyById(va) {
		for(var vb in hotkeyMapping) {
			if(hotkeyMapping[vb] == va) {
				return vb
			}
		}
		;
		return ''
	}


	function setIntervalEx(proc, ms){
		function intervalProc(){
			proc();
			setTimeout(intervalProc, ms);
		}
		setTimeout(intervalProc, ms);
	}


	class MapNode {
		constructor(id, name, team, xpos, ypos) {
			this.id = id;
			this.name = name;
			this.team = team;
			this.mass = 200;
			this.tick = 0;

			this.xpos0 = xpos;
			this.ypos0 = ypos;
			this.xpos1 = xpos;
			this.ypos1 = ypos;
			this.frame = 0;
			this.dead = false;
		}
	}

	var MapDrawingInterval = 33;  //ms
	var MapDataInterval = 1000; //ms

	class Minimap2 {
		constructor(sz) {
			this.mapNodesDict = {};

			$('body')['append']("<canvas id='minimapNode'>");
			$('body')['append']("<canvas id='minimap' >");
			var canvas = document.getElementById('minimap');
			var ctx = canvas.getContext('2d');
			canvas.width = sz;
			canvas.height = sz;
			ctx.scale(1, 1);
			ctx.strokeStyle = '#333';
			ctx.fillStyle = '#000000';
			ctx.globalAlpha = 0.5;
			ctx.lineWidth = 2;
			ctx.strokeRect(0, 0, canvas.width, canvas.height);
			ctx.fillRect(0, 0, canvas.width, canvas.height);
			ctx.textAlign = 'center';
			ctx.textBaseline = 'middle';
			ctx.globalAlpha = 0.2;
			ctx.font = '18px Verdana';
			ctx.fillStyle = '#FFFFFF';
			var width = canvas.width;
			var height = canvas.height;
			var csz = sz / 5 / 2;
			for(var i = 0; i < 25; i++) {
				var ix = parseInt(i / 5);
				var iy = i % 5;
				var label = String.fromCharCode('A'.charCodeAt(0) + iy) + (ix + 1);
				ctx.fillText(label, csz * (ix * 2 + 1), csz * (iy * 2 + 1));
			}
			var canvas2 = document.getElementById('minimapNode');
			ctx = canvas2.getContext('2d');
			canvas2.width = sz;
			canvas2.height = sz;
			ctx.globalAlpha = 1;
			ctx.scale(1, 1);
			ctx.textAlign = 'center';
			ctx.textBaseline = 'middle';
			ctx.font = 'bold 12px Ubuntu';
			this.hide();

			this.canvas = canvas;
			this.canvas2 = canvas2;
			this.ctx = ctx;

			this.playerActive = false;
		}

		start(){
			//var self = this;
			/*
			setIntervalEx(function(){
				self.drawNodes();
				self.updateNodesInFrame();
			}, MapDrawingInterval);
			*/
			setIntervalEx(this.updateFrame.bind(this), MapDrawingInterval);
			setIntervalEx(this.uploadSelfPosition.bind(this), MapDataInterval);

			/*
			function minimapDrawTimerProc() {
				self.drawNodes();
				self.updateNodesInFrame();
				setTimeout(minimapDrawTimerProc, MapDrawingInterval);
			}
			minimapDrawTimerProc();

			function uploadSelfPositionTimerProc() {
				self.uploadSelfPosition();
				setTimeout(uploadSelfPositionTimerProc, MapDataInterval);  //1E3)
			}
			uploadSelfPositionTimerProc();
			*/
		}

		updateFrame(){
			this.drawNodes();
			this.updateNodesInFrame();
		}

		updateNodesInFrame() {
			var delKeys = [];

			for(var k in this.mapNodesDict) {
				var node = this.mapNodesDict[k];
				node.tick++;
				node.frame++;
				var D = 0.96;
				node.xpos0 = nums.easyFilter(node.xpos0, node.xpos1, D);
				node.ypos0 = nums.easyFilter(node.ypos0, node.ypos1, D);

				if(node.tick > 80) {
					node.dead = true;
				}

				if(node.dead){
				// 	//console.log('teammate connection broken');
				 //var deleted =
					delete this.mapNodesDict[k];
					//console.log(deleted);
					//delKeys.push(k);
				}
			}
/*
			for(var i in delKeys){
				var key = delKeys[i];
				delete this.mapNodes[key];
			}*/

			//this.mapNodesDict = this.mapNodesDict.filter(function(x){ return !x.dead});
		}

		posToShortVal(a) {
			var D = 14142.0 / 2;
			return parseInt(utils.vmap(a, -D, D, 0, 65535));
		}

		posFromShortVal(a) {
			var D = 14142.0 / 2;
			return utils.vmap(a, 0, 65535, -D, D)
		}

		uploadSelfPosition() {
			var dying = this.playerActive && !gIsPlaying;
			this.playerActive = gIsPlaying;
			//if(dying) console.log('dying');

			if(this.playerActive || dying){
				//console.log(gPlayerSignature);  //'up');
				var mass = gSelfMass;
				//var id = gLocalPlayerIdPerConnection;
				var id = gPlayerSignature;
				var name = myApp.getNameEx();
				var team = myApp.getTeamName();
				var cx = getCurrentX();
				var cy = getCurrentY();
				if(cx != 0 && cy != 0) {
					var xpos = this.posToShortVal(cx);
					var ypos = this.posToShortVal(cy);
					//trace(getCurrentX() + ',' + getCurrentY());
					//trace(xpos + ',' + ypos);
					conn2.sendCoord(id, name, team, xpos, ypos, mass, dying);
				}
			//}
			}
		}

		updateNode(id, name, team, _xpos, _ypos, mass, dead) {
			/*
			if(dead){
				if(this.mapNodesDict[id]){
					delete this.mapNodesDict[id];
					console.log('teammate died');
					return;
				}
			}*/

			var newXpos = this.posFromShortVal(_xpos);
			var newYpos = this.posFromShortVal(_ypos);
			if(!this.mapNodesDict[id] && !dead) {
				this.mapNodesDict[id] = new MapNode(id, name, team, newXpos, newYpos);
			}
			//trace(xpos + ',' + ypos);

			var node = this.mapNodesDict[id];
			node.name = name;
			node.team = team;
			//node.xpos0 = node.xpos1;
			//node.ypos0 = node.ypos1;
			node.xpos1 = newXpos;
			node.ypos1 = newYpos;
			node.mass = mass;
			node.tick = 0;
			node.frame = 0;
			node.dead = dead;
		}

		drawNodes() {
			var ctx = this.ctx;
			var canvas2 = this.canvas2;
			ctx.save();
			ctx.clearRect(0, 0, canvas2.width, canvas2.height);

			for(var i in this.mapNodesDict) {
				var node = this.mapNodesDict[i];

				var fullName = node.name;

				if(UseMapSepration && !checkIsTeammate(node.team)) continue;

				var col = 'rgba(25, 25, 112, 1)';
				var txt_col = 'rgba(255, 105, 180, 1)';

				/*
				//var col = utils.makeColor(0xF00);
				var col = 'rgba(160, 160, 160, 0.8)';
				var txt_col = 'rgba(192, 192, 192, 1)';

				if(fullName.startsWith('【先輩】')) {
					col = 'rgba(0,160,255,0.8)';
					//col = 'rgba(0,160,255,0.8)';
					txt_col = 'rgba(160, 192, 255, 1)';
				}

				if(fullName.startsWith('【敵】')) {
					col = 'rgba(255,0,128,0.8)';
					txt_col = 'rgba(255, 160, 192, 1)';
				}
				*/

				var mass = node.mass;
				var radius = 4;
				if(radius < 3) radius = 3;
				var D = 14142.0 / 2;

				var frameMax = parseInt(MapDataInterval / MapDrawingInterval);
				//var xpos = utils.vmap(node.frame, 0, frameMax, node.xpos0, node.xpos1);
				//var ypos = utils.vmap(node.frame, 0, frameMax, node.ypos0, node.ypos1);
				var xpos = node.xpos0;
				var ypos = node.ypos0;
				var px = utils.vmap(xpos, -D, D, 0, canvas2.width);
				var py = utils.vmap(ypos, -D, D, 0, canvas2.height);
				ctx.font = '14px Ubuntu';
				ctx.fillStyle = col;
				ctx.beginPath();
				ctx.arc(px, py, radius, 0, 2 * Math.PI, false);
				ctx.strokeStyle = 'rgba(51,51,51,0.5)';
				ctx.lineWidth = 1;
				ctx.fill();
				ctx.stroke();

				ctx.fillStyle = txt_col;
				ctx.fillText(fullName, px, py - 10);

				if(i == gPlayerSignature) {
					ctx.strokeStyle = "#FFFF00";
					ctx.lineWidth = 1;
					ctx.beginPath();
					ctx.arc(px, py, radius + 4, 0, 2 * Math.PI, false);
					ctx.stroke();
				}
			}

			ctx.restore();
		}

		hide() {
			$('#minimap')['hide']();
			$('#minimapNode')['hide']()
		}

		show() {
			$('#minimap')['show']();
			$('#minimapNode')['show']()
		}

		setDeadPosition(va) {
			//vn = va ? va : {}
		}
	}

	function Connection_Dummy() {
		this.connect = function() { }
		this.emit = function(sig, data) { }
		this.joinRoom = function(_id) { }
		this.leaveRoom = function(_id) { }
		this.uploadCoords = function(data) { }
		this.sendMessage = function(data) { }
	}

	//チャット/マップ共有用サーバとのコネクション, 200
	function Connection() {
		/*
		 //フレームフォーマット

		 //プレイヤ参加情報
		 //送信
		 playerEntered
		 {
		 displayName,// player name
		 action,		//'join' or 'spectate'
		 socketRoom, //room signature, team name + party token
		 identifier,	//player signature, player name + color
		 url,	//skin url
		 nick, 	//player name
		 team, 	//team name
		 token, 	//party token
		 }
		 //受信, 受信したあと条件により再送信する場合がある？
		 playerUpdated
		 {
		 displayName,
		 action,		//'update'
		 socketRoom,
		 identifier,
		 url,
		 nick,
		 team,
		 token,
		 }

		 //座標データ
		 //送信
		 coords
		 {
		 x,
		 y
		 name, //player name
		 serverAddress,	//party code
		 timeStamp,
		 socketRoom, //room signature
		 }
		 //受信
		 updateCoords
		 ｛
		 name, //player name
		 id,  //player id?
		 x,
		 y,
		 }

		 //チャットメッセージ
		 //送信
		 sendMessage
		 {
		 serder,	//player name
		 msg,	//message
		 socketRoom	//room signature
		 }
		 //受信
		 receiveMessage
		 {
		 sender,	//player name
		 msg,	//message
		 }

		 //参加
		 //play or spectate
		 //送信
		 joinRoom{
		 p,	//room signature
		 a	//1, fixed value
		 }

		 //退去
		 //送信
		 leaveRoom{
		 id,	//room signature
		 }
		 */

		var self = this;
		var room_signature = null; //チャット/マップを共有するグループのシグニチャ, team name + party token
		//var joined = false;

		//接続
		self.connect = function() {

			var uri = MapServerAddress;

			//urlのクエリ文字列によるローカル接続オプション対応
			var html_query_str = location.search;
			var req_local_connection = html_query_str === "?localhost=1";
			if(req_local_connection) {
				var port = uri.split(":")[2];
				uri = "ws://localhost:" + port;
			}


			trace("connecting to shared data server, " + uri);
			socket = io(uri, {
				transports: ['websocket']
			});

			socket.on('connect', function() {
				trace('map connect');
				self.alive = true;
			});

			socket.on('disconnect', function() {
				trace('map disconnect');
				self.alive = false;
			});

			//マップ座標受信
			socket.on('updateCoords', function(data) {
				minimap.updateNode(data)
			});
			//メッセージ受信
			socket.on('receiveMessage', function(data) {
				chatRoom.receiveMessage(data.sender, data.msg)
			})
		};

		//フレーム送信
		self.emit = function(sig, data) {
			socket.emit(sig, data)
		};

		var check_cnt = 0;

		//ルームに参加
		self.joinRoom = function(_id) {
			if(_id == '') _id = 'NOTAG';
			//var serverUrl = myApp.getCurrentIP();
			//var req_local_connection = location.search === "?localhost=1";
			//if(req_local_connection) {
			//	serverUrl = PrivateServerAddress;
			//}
			var serverUrl = GameServerAddress;
			var mode = 0;
			if(mode == -1) {
				room_signature && self.leaveRoom(room_signature);
				(self.emit('joinRoom', {
					p: _id,
					a: 1
				}), room_signature = _id)

			} else if(mode == 0) {
				if(check_cnt % 50 == 0 && self.alive) {
					//元のコード, 定常的にjoin/leaveを繰り返す問題あり？
					room_signature && self.leaveRoom(room_signature);

					//'' != $('.partyToken')['val']() &&
					(self.emit('joinRoom', {
						p: _id,
						a: 1,
						gs: serverUrl
					}), room_signature = _id);
				}
				check_cnt++;

			} else {
				if(room_signature != _id) {
					if(room_signature != null) {
						self.leaveRoom(room_signature);
						room_signature = null;
					}

					var token = $('.partyToken')['val']();
					if(token != '') {
						self.emit('joinRoom', { p: _id, a: 1, gs: serverUrl });
						room_signature = _id;
					}
				}
			}
		};

		//ルームから退去
		self.leaveRoom = function(_id) {
			if(_id == '') _id = 'NOTAG';
			//self.emit('leaveRoom', { p: _id, gs: 'myApp.getCurrentIP()'});
			self.emit('leaveRoom', { p: _id });
		};

		//座標を送信
		self.uploadCoords = function(data) {
			data.team = myApp.getTeamName();
			data.name = myApp.getName();
			data.serverAddress = myApp.getCurrentPartyCode();
			data.timeStamp = Date.now();
			data.socketRoom = room_signature;
			self.emit('coords', data)
		};

		//メッセージを送信
		self.sendMessage = function(data) {
			data.socketRoom = room_signature;
			//'' != $('.partyToken')['val']() &&
			self.emit('sendMessage', data)
		}
	}

	class DataFrameWriter {
		constructor() {
			this.bytes = [];
		}

		writeUint8(val) {
			this.bytes.push(val);
		}

		writeUint16(val) {
			this.bytes.push(val & 0xFF);
			this.bytes.push(val >> 8 & 0xFF);
		}

		writeUint32(val) {
			this.bytes.push(val & 0xFF);
			this.bytes.push(val >> 8 & 0xFF);
			this.bytes.push(val >> 16 & 0xFF);
			this.bytes.push(val >> 24 & 0xFF);
		}

		// writeString(str){
		// 	for(var i = 0; i < str.length; i++){
		// 		this.writeUint16(str.charCodeAt(i));
		// 	}
		// }

		writeStringEx(str) {
			this.writeUint16(str.length);
			for(var i = 0; i < str.length; i++) {
				this.writeUint16(str.charCodeAt(i));
			}
		}

		// writeCode(s){
		// 	this.writeUint8(s.charCodeAt(0));
		// }

		getBuffer() {
			return this.bytes;
		}

		// getArrayBuffer(){
		// 	return new Uint8Array(this.buf).buffer;
		// }

		/*
		 getDataView(){
		 var ar = getArrayBuffer();
		 var view = new DataView(ar.length);
		 for(var i = 0; i < len; i++){

		 }
		 }*/
	}

	class DataFrameReader {
		constructor(buf) {
			this.bytes = buf;
			this.pos = 0;
		}

		readUint8() {
			return this.bytes[this.pos++];
		}

		readUint16() {
			var a = this.readUint8();
			var b = this.readUint8();
			return a | b << 8;
		}

		readUint32() {
			var a = this.readUint8();
			var b = this.readUint8();
			var c = this.readUint8();
			var d = this.readUint8();
			return d << 24 | c << 16 | b << 8 | a;
		}

		readStringEx() {
			var len = this.readUint16();
			var str = '';
			for(var i = 0; i < len; i++) {
				str += String.fromCharCode(this.readUint16());
			}
			return str;
		}

		// readCode(){
		// 	var c = readUint8();
		// 	return String.fromCharCode(c);
		// }
	}

	class ConnectionHub_OgarMap {
		constructor() {

		}

		sendWebSocketData(bytes) {
			var socket = window.webSocket;
			if(socket && socket.readyState == 1) {
				socket.send(new Uint8Array(bytes).buffer);
			}
		}

		setChatListenerProc(proc) {
			this.chatListenerProc = proc;
		}

		setMapListenerProc(proc) {
			this.mapListenerProc = proc;
		}

		setSkinListenerProc(proc) {
			this.skinListenerProc = proc;
		}

		setSkinRequestedProc(proc) {
			this.skinRequestedProc = proc;
		}

		sendSkin(player_id, name, team, skin_url) {
			var fb = new DataFrameWriter();
			//var opcode = 130; //is_respond ? 131 : 130;
			fb.writeUint8(130);
			fb.writeStringEx(player_id);
			//fb.writeUint32(player_id);
			//fb.writeStringEx(live_id);
			fb.writeStringEx(name);
			fb.writeStringEx(team);
			fb.writeStringEx(skin_url);
			this.sendWebSocketData(fb.getBuffer());
		}

		requestBroadcastSkins() {
			var fb = new DataFrameWriter();
			fb.writeUint8(132);
			this.sendWebSocketData(fb.getBuffer());
		}

		sendCoord(player_id, name, team, x, y, mass, dead) {
			var fb = new DataFrameWriter();
			fb.writeUint8(129);
			//fb.writeUint32(player_id);
			fb.writeStringEx(player_id);
			fb.writeStringEx(name);
			fb.writeStringEx(team);
			fb.writeUint16(x);
			fb.writeUint16(y);
			fb.writeUint16(mass);
			fb.writeUint8(dead ? 1 : 0);
			this.sendWebSocketData(fb.getBuffer());
			//trace('coord send');
		}

		sendChatMessage(sender, message) {
			if(utils.CheckValidString(message) && message.length < 80) {
				var fb = new DataFrameWriter();
				fb.writeUint8(128);	//opcode
				fb.writeStringEx(sender);
				fb.writeStringEx(message);
				this.sendWebSocketData(fb.getBuffer());
				//console.log('sending chat message');
			}
		}

		decodeMessage(view) {
			var ar = utils.ByteArrayFromDataView(view);
			var bb = new DataFrameReader(ar);
			var opcode = bb.readUint8();
			switch(opcode) {
				case 128:
					//チャットメッセージを受信
					//console.log("chat message received");
					var sender = bb.readStringEx();
					var message = bb.readStringEx();
					this.chatListenerProc(sender, message);
					break;
				case 129:
					//他のプレイヤの座標情報を受信
					//var player_id = bb.readUint32();
					var player_id = bb.readStringEx();
					var name = bb.readStringEx();
					var team = bb.readStringEx();
					var x = bb.readUint16();
					var y = bb.readUint16();
					var mass = bb.readUint16();
					var dead = bb.readUint8() == 1;
					this.mapListenerProc(player_id, name, team, x, y, mass, dead);
					break;
				case 130:
					//他のプレイヤのスキンURLを受信
					//var player_id = bb.readUint32();
					//var live_id = bb.readStringEx();
					var player_id = bb.readStringEx();
					var name = bb.readStringEx();
					var team = bb.readStringEx();
					var skin_url = bb.readStringEx();
					var respond_req = opcode == 130;
					this.skinListenerProc(player_id, name, team, skin_url);
					break;
				case 132:
					//他のプレイヤからのスキン要求
					this.skinRequestedProc();
					break;
				case 133:
					//サーバからのデバッグメッセージ
					//var message = bb.readStringEx();
					//console.log(message);
					break;
			}
		}
	}
	conn2 = new ConnectionHub_OgarMap();

	class SkinProvider {
		constructor() {

		}

		receiveSkinInfo(player_id, name, team, skin_url) {
			//trace('received ' +player_id + "'s skin")
			gPlayerInfoDict[player_id] = {
				name: name,
				team: team,
				skinUrl: skin_url
			};
		}

		skinRequested() {
			//trace('skin requested');
			this.sendSkinInfo();
		}

		sendSkinInfo() {
			//var player_id = gLocalPlayerIdPerConnection;
			var name = myApp.getNameEx();
			var team = myApp.getTeamName();
			var skin_url = myApp.getCustomSkinUrl();
			var player_id = gPlayerSignature;
			gPlayerInfoDict[player_id] = {
				name: name,
				team: team,
				skinUrl: skin_url
			};  //自分のスキンをリストに格納

			//trace('sending my skin');
			conn2.sendSkin(player_id, name, team, skin_url);
		}

		requestBroadcastSkins() {
			//trace('request other players skins')
			conn2.requestBroadcastSkins();
		}

	}
	var skinProvider = new SkinProvider();

	//チャット表示, 150
	function ChatRoom() {
		this.container = '';
		this.isShow = 1;
		this.lastMsg = '';
		this.width = 340;
		this.height = 350;
		var va = this,
			vb = 0;

		this.createChatBox = function() {

			$(this.container)['append']("<div id='chatroom'></div>");
			$('#overlays2')['append']("<div id='chatboxArea2'><input id='input_box2' type='text'></input></div>");
			this.hide();
			$('#chatboxArea2')['hide']();
			$('#chatroom')['mouseup'](function() {
				va.resize()
			})
		};
		va.resize = function() {
			($('#chatroom')['width']() != this.width || $('#chatroom')['height']() != this.height) && $('#chatroom')['perfectScrollbar'] && $('#chatroom')['perfectScrollbar']('update')
		};
		this.setContainer = function(va) {
			this.container = va
		};

		//メッセージを送信
		this.sendMessage = function(str) {
			if(!UseOgarMapImpl) {
				!(str = str.trim()) || 2E3 > Date.now() - vb && 50 > str.length || (conn.sendMessage({
					sender: myApp.getNameEx(),
					msg: str
				}), this.lastMsg = str, vb = Date.now())
			} else {
				conn2.sendChatMessage(myApp.getNameEx(), str);
			}
		};

		/*
		 this.decodeMessage = function(view) {
		 //console.log("chat message received");
		 var ar = Utils.ByteArrayFromDataView(view);
		 var bb = new DataFrameReader(ar);
		 bb.readUint8();	//opcode
		 var sender = bb.readStringEx();
		 var message = bb.readStringEx();
		 this.receiveMessage(sender, message);
		 };
		 */

		this.enter = function() {
			this.isFocus() ? (this.sendMessage($('#input_box2')['val']()), $('#input_box2')['val'](''), $('#input_box2')['blur'](), $('#chatboxArea2')['hide']()) : this.focus()
		};
		this.popup = function(va) {
			myApp.isEnableChatpopup && !this.isShow && ($['toast'] ? $['toast'](va) : toastQueue.push(va))
		};
		this.popupInfo = function(va) {
			this.popup({
				text: escapeHtml(va),
				showHideTransition: 'slide',
				icon: 'info',
				bgColor: 'rgba(10, 10, 10, 0.8)',
				allowToastClose: 0,
				hideAfter: 15E3,
				stack: 10
			})
		};
		this.popupWarning = function(va) {
			this.popup({
				text: escapeHtml(va),
				showHideTransition: 'slide',
				icon: 'warning',
				bgColor: 'rgba(10, 10, 10, 0.8)',
				allowToastClose: 0,
				hideAfter: 15E3,
				stack: 10
			})
		};
		this.popupChat = function(va, vb) {
			var vh = escapeHtml(va),
				vd = this.replaceHKGIcon(escapeHtml(vb));
			'荳咲蕗蜷・[slick]' == va && (vh = this.replaceHKGIcon(vh));
			this.popup({
				heading: '<span class="toast_sender">' + vh + ': </span>',
				text: '<span class="toast_chatmsg">' + vd + '</span>',
				showHideTransition: 'fade',
				bgColor: 'rgba(10, 10, 10, 0.8)',
				allowToastClose: 0,
				hideAfter: 15E3,
				stack: 10
			})
		};
		this.showSystemMessage = function(va) {
			this.showSystemMessageImpl(va);
			this.popupInfo(va)
		};
		this.showSystemWarning = function(va) {
			this.showSystemMessageImpl(va);
			this.popupWarning(va)
		};
		this.showSystemMessageImpl = function(va) {
			myApp.showSystemMessage() && ($('#chatroom')['append']($('<div/>')['append']($("<span class='system'/>")['text'](this.getTimeStr() + va))), this.scrollDown())
		};
		this.getTimeStr = function() {
			var va = new Date,
				vb = va.getMinutes(),
				vb = 10 > vb ? '0' + vb : vb;
			return va.getHours() + ':' + vb + ' '
		};

		//メッセージを受信したときのハンドラ
		this.receiveMessage = function(sender_name, message) {
			//if(UseChatSeparation && !checkIsTeammate(sender_name)) return;

			//chats are global
			var vh = $('<div/>'),
				vd = $("<span class='time'>")['text'](this.getTimeStr()),
				ve = $("<span class='sender'>")['text'](sender_name + ' : ');
			'荳咲蕗蜷・[slick]' == sender_name && ve.html(this.replaceHKGIcon(ve.html()));
			vh.append(vd);
			vh.append(ve);
			vd = $("<span class='msg'>")['text'](message);
			vd.html(this.replaceHKGIcon(vd.html()));
			vh.append(vd);
			$('#chatroom')['append'](vh);
			this.scrollDown();
			this.popupChat(sender_name, message)
		};

		this.replaceHKGIcon = function(va) {
			for(var vb in hkgIcon) {
				va = va.replace(new RegExp(escapeRegex(vb), 'g'), '<img alt="$1" src="' + hkgIcon[vb] + '">')
			};
			for(var vh = $('img[alt="$1"]'), vd = 0; vd < vh.length; vd++) {
				for(vb in hkgIcon) {
					if(vh[vd]['src'] == hkgIcon[vb]) {
						$(vh[vd])['attr']('alt', vb);
						break
					}
				}
			};
			return va
		};
		this.scrollDown = function() {
			$('#chatroom')['perfectScrollbar'] && ($('#chatroom')['scrollTop']($('#chatroom')['prop']('scrollHeight')), $('#chatroom')['perfectScrollbar']('update'))
		};
		this.show = function() {
			$('#chatroom')['show']();
			this.isShow = 1;
			this.scrollDown()
		};
		this.hide = function() {
			$('#chatroom')['hide']();
			this.isShow = 0
		};
		this.isFocus = function() {
			return $('#input_box2')['is'](':focus')
		};
		this.focus = function() {
			$('#chatboxArea2')['show']();
			$('#input_box2')['focus']()
		};
		this.createScrollBar = function() {
			$('#chatroom')['perfectScrollbar']({
				minScrollbarLength: 50,
				suppressScrollX: 0
			})
		}
	}

	//アプリケーション本体, 1200
	function MyApp() {

		//console.log("SAO_160518_A100");


		function onNicknameChanged() {
			$('#nick')['val'](myApp.getName());
			if(nodeList[0][1] == myApp.getName()) {
				return 0
			};
			nodeList[0][1] = myApp.getName();
			setLocalStorage('nick', $('#nick')['val']());
			player_profile[selected_profile_index]['name'] = myApp.getName();
			storePlayerProfile();
			return 1
		}

		function onTreamNameChanged() {
			var teamName = myApp.getTeamName();
			$('#team_name')['val'](teamName);
			if(tmpTeamname == teamName) {
				return 0
			};
			nodeList[0][15] = teamName;
			setLocalStorage('opt_teamname', teamName);
			player_profile[selected_profile_index]['team'] = teamName;
			storePlayerProfile();
			return 1
		}

		function vf() {
			setLocalStorage('selected_profile', selected_profile_index);
			tmpTeamname = myApp.getTeamName();
			$('#nick')['val'](player_profile[selected_profile_index]['name']);
			$('#team_name')['val'](player_profile[selected_profile_index]['team']);
			$('#skin_url')['val'](player_profile[selected_profile_index]['skinurl'])['trigger']('change');
			onTreamNameChanged() ? (nodeList[0][1] = myApp.getName(), setLocalStorage('nick', myApp.getName())) : onNicknameChanged()
		}

		function storePlayerProfile() {
			setLocalStorage('player_profile', player_profile)
		}
		this.version = 'v_2.0.0';
		var vh = 0.88;
		this.getZoomSpeed = function() {
			return vh
		};
		this.getZoomLimit = function() {
			return 0.05
		};
		this.isEnableHideFood = this.isEnableGridline = this.isEnableBorder = this.isEnableMapGrid = this.isEnableCursorLine = this.isEnableZoom = this.isStopMovement = this.isShowBallTotal = this.isShowSTE = this.isShowScroll = 0;
		this.isEnableShowAllMass = 1;
		this.isEnableSimpleDrawing = 0;
		this.isEnableAutoStart = 1;
		this.isEnableMouseW = 0;
		this.isEnableLockZoom = this.isEnableCustomSkin = 1;
		this.isEnableAttackRange = 0;
		this.isEnableTeammateIndicator = 1;
		this.isEnableChatpopup = 0;
		this.attackRangeRadius = 655;
		this.cellColor = '';
		this.cellColorAry = 'red #76FF03 blue yellow #8207ff #2196F3 '['split'](' ');
		this.doubleSpace = this.quickSpace = this.autoW = 0;
		this.doubleSpaceCount = this.quickSpaceCount = 0;
		this.lockZoomG;
		this.teammateIndicatorPosition = 40;
		this.teammateIndicatorSize = 50;
		this.teammateIndicatorShowSize = 200;
		this.teammateIndicator;
		this.specTeammate;
		this.isSpecTeammate = 0;
		this.massTextSize = 0.8;
		this.isSpectating = 0;
		this.isSameColorFood = 1;
		this.isEnableSplitInd = this.isShowTextStrokeLine = this.isAutoHideName = this.isAutoHideMass = this.isShowFPS = this.isTransparentCell = 0;
		//this.isEnableOtherSkinSupport = 1;
		this.isEnableOtherSkinSupport = 0;
		this.isShowPacketIO = this.isEnableShareFb = this.isEnableSound = this.isHideSelfName = this.testing = 0;

		this.isHideSelfName = 0;

		this.isEnableMouseControl = 0;
		this.swapMouseButtonsLR = 0;
		this.showChatAtBottom = 0;
		//this.showCenterCrosshair = 0;
		this.showSplitOrderMarker = 0;
		this.showCursorCrosshair = 0;
		//init
		this.init = function() {
			//console.log("A106")

			$('body')['append']("<canvas id='canvas'>");
			$('body')['append']('<link id="favicon" rel="icon" type="image/png">');
			//document.title = 'Agarplus.io';
			$('body')['append']("<div id = 'overlays2'></div>");
			$('#overlays2')['append']("<div id = 'div_lb'><div class='header'>" + LeaderBoardCaption + "</div></div>");
			$('#div_lb')['append']("<div id='lb_detail'></div>");
			$('#overlays2')['append']("<div id = 'div_score'></div>");
			$('#overlays2')['append']("<div id = 'pinfo'></div>");
			
			var va = document.getElementById('canvas');
			va.getContext('2d');
			va.mozOpaque = 1;
			window.setLocalStorage = function(va, vb) {
				'string' == typeof vb ? localStorage.setItem(va, vb) : localStorage.setItem(va, JSON.stringify(vb))
			};
			window.getLocalStorage = function(va) {
				return localStorage.getItem(va)
			};
			getLocalStorage('selected_profile') && (selected_profile_index = getLocalStorage('selected_profile'));
			getLocalStorage('player_profile') ? player_profile = JSON.parse(getLocalStorage('player_profile')) : (getLocalStorage('nick') && (player_profile[selected_profile_index]['name'] = getLocalStorage('nick')), getLocalStorage('opt_teamname') && (player_profile[selected_profile_index]['team'] = getLocalStorage('opt_teamname')), getLocalStorage('skin_url') && (player_profile[selected_profile_index]['skinurl'] = getLocalStorage('skin_url')));

			for(va = 0; va < player_profile.length; va++) {
				window.postMessage({
					action: Action.IMAGE,
					data: player_profile[va]['skinurl']
				}, '*')
			};
			$('body')['attr']('oncontextmenu', 'return false;');
			$('#overlays2')['append']("<div id='teammate_menu'></div>");
			$('#teammate_menu')['hide']();
			$('#teammate_menu')['click'](function(va) {
				va.stopPropagation()
			});
			$('#overlays2')['click'](function() {
				$('#teammate_menu')['hide']()
			});
			nodeList[0] = ['me', getLocalStorage('nick'), null, null, 'yellow'];
			nodeList[1] = ['top1', '', null, null, 'white'];
			nodeList[0][8] = Date.now();
			nodeList[1][8] = Date.now();

			//チャット初期化
			chatRoom = new ChatRoom;
			chatRoom.setContainer('#overlays2');
			chatRoom.createChatBox();
			$('#btn_connect')['click'](function() {
				$('#btn_connect')['text']('Connecting');
				$('#connect_error_div')['hide']()
			});

			//マップ初期化
			if(!UseOgarMapImpl) {
				minimap = new Minimap();
				minimap.createMap(200);
			} else {
				minimap = new Minimap2(200);
			}
			var va = document.createElement('canvas'),
				vb = va.getContext('2d');
			vb.beginPath();
			vb.lineWidth = 10;
			vb.moveTo(0, 0);
			vb.lineTo(100, 0);
			vb.lineTo(50, 50);
			vb.closePath();
			vb.strokeStyle = 'white';
			vb.fillStyle = 'white';
			vb.stroke();
			vb.fill();
			this.teammateIndicator = va;

			if(!UseOgarMapImpl) {
				//チャット/マップの共有サーバへの接続
				conn = new Connection();
			} else {
				conn = new Connection_Dummy();
			}
			conn.connect()

		};
		this.newGame = function() {
			$('#nick')['prop']('disabled', 1);
			$('.btn-spectate')['prop']('disabled', 1);
			isJoinedGame = 1;
			myApp.isStopMovement = 0;
			myApp.isSpectating = 0;
			myApp.cellColor = '';
			myApp.newGameImpl();
			spectateMode = 0;
			nodeList[1][2] = null;
			nodeList[1][3] = null
		};
		this.afterGameLogicLoaded = function() {
			myApp.setupOption();
			myApp.setupHotKey();
			myApp.restoreSetting();
			myApp.setUpHotKeyConfigPage();
			myApp.replaceTos();
			myApp.setupHints();
			myApp.checkVersion();
			myApp.downloadSkin();
			$('#btn_info')['click'](function() {
				myApp.showAnnouncement()
			});
			$('#game_info')['click'](function() {
				myApp.copyGameInfo()
			});
			$('#nick')['change'](function() {
				onNicknameChanged()
			});
			$('#team_name')['change'](function() {
				onTreamNameChanged()
			})['focus'](function() {
				tmpTeamname = myApp.getTeamName()
			});

			//$("skin_url").change
			$('#skin_url')['change'](function() {
				var va = getLocalStorage('skin_url'),
					vb = myApp.getCustomSkinUrl();
				$('#skin_url')['val'](vb);
				va != vb && (va = /^(?:(?:https?|ftp):\/\/)(?:\S+(?::\S*)?@)?(?:(?!10(?:\.\d{1,3}){3})(?!127(?:\.\d{1,3}){3})(?!169\.254(?:\.\d{1,3}){2})(?!192\.168(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]+-?)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]+-?)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/[^\s]*)?$/i, 'DEFAULT' == vb || va.test(vb) ? (setLocalStorage('skin_url', vb), nodeList[0][5] = vb, player_profile[selected_profile_index]['skinurl'] = myApp.getCustomSkinUrl(), storePlayerProfile(), customSkin[vb] ? myApp.changePreviewImage(customSkin[vb]['src']) : skinDownloadQueue.push(vb)) : (console.log('Not valid URL'), $('#skin_url')['val']('')))
			});
			$('.nav2.arrow-left')['click'](function() {
				selected_profile_index = (player_profile.length + selected_profile_index - 1) % player_profile.length;
				vf()
			});
			$('.nav2.arrow-right')['click'](function() {

				selected_profile_index = (selected_profile_index + 1) % player_profile.length;
				vf()
			});
			storePlayerProfile()
		};
		this.spectate = function(va) {
			conn.joinRoom(myApp.getRoom());
			va && 0 != va.length || (myApp.isSpectating = 1)
		};
		this.newGameImpl = function() {
			//trace('newGameImpl');
			var va = 1,
				vb = getCell();
			vb && 0 != vb.length || (va = 0);
			va ? (nodeList[0][6] = vb[0]['color'], conn.joinRoom(myApp.getRoom())) : setTimeout(myApp.newGameImpl, 100)
			gIsPlaying = true;
		};
		this.onDead = function() {
			//trace('onDead');
			isJoinedGame = 0;
			$('.btn-spectate')['prop']('disabled', 0);
			$('#nick')['prop']('disabled', 0);
			$('.nav')['show']();
			conn.leaveRoom(myApp.getRoom());
			gIsPlaying = false;
		};
		this.afterGameLoaded = function() {
			myApp.isSpectating = 0;
			updateLBCount = -1;
			$('#nick')['prop']('disabled', 0);
			$('#current_ip')['text']('Server: ' + myApp.getCurrentIP());
			$('#ip_info')['text']('Server: ' + myApp.getCurrentIP());
			$('#region_info')['text']('Region: ' + $('#region option:selected')['text']()['split'](' ')[0]);
			$('#gamemode_info')['text']('Mode: ' + $('#gamemode option:selected')['text']());
			$('#party_code_info')['text']('Party: ' + myApp.getCurrentPartyCode());
			$('#btn_connect')['text']('Connect');
			moveTo(null, null);
			myApp.specTeammate = null;
			myApp.isStopMovement = 0;
			minimap.setDeadPosition(null);
			conn.joinRoom(myApp.getRoom())
		};

		//room signatureを取得
		//team name + server ip or
		//team name + party code
		this.getRoom = function() {
			//return 'N/A' == myApp.getCurrentPartyCode() ? myApp.getTeamName() + myApp.getCurrentIP() : myApp.getTeamName() + myApp.getCurrentPartyCode()
			return myApp.getTeamName();
		};
		this.restoreSetting = function() {
			if(getLocalStorage('opt_teamname') == null && getLocalStorage('nick') == null) {
				//初回起動時,名前/チーム名のリソースがない場合, Profile1を設定
				var pp = player_profile[0];
				setLocalStorage('opt_teamname', pp.team);
				setLocalStorage('nick', pp.name);
				setLocalStorage('skin_url', pp.skinurl);
			}

			getLocalStorage('opt_teamname') && $('#team_name')['val'](getLocalStorage('opt_teamname'));
			getLocalStorage('nick') && '' != getLocalStorage('nick')['trim']() ? $('#nick')['val'](getLocalStorage('nick', myApp.getName())) : ($('#nick')['val'](myApp.getName()), setLocalStorage('nick', myApp.getName()));
			nodeList[0][1] = myApp.getName();
			nodeList[0][15] = myApp.getTeamName();
			getLocalStorage('opt_zoom_speed') && (vh = getLocalStorage('opt_zoom_speed'), $('#opt_zoom_speed')['val'](vh), $('#txt_zoom_speed')['text'](vh));
			var va = getLocalStorage('skin_url');
			va && '' != va || (setLocalStorage('skin_url', defaultSkin), va = defaultSkin);
			va && '' != va && ($('#skin_url')['val'](getLocalStorage('skin_url')), nodeList[0][5] = va, customSkin[va] ? myApp.changePreviewImage(customSkin[va]['src']) : skinDownloadQueue.push(getLocalStorage('skin_url')));
			if(getLocalStorage('hotkeyMapping')) {
				hotkeyMapping = JSON.parse(getLocalStorage('hotkeyMapping'))
			} else {
				for(var cfg in hotkeyConfig) {
					hotkeyConfig[cfg]['defaultHotkey'] && '' != hotkeyConfig[cfg]['defaultHotkey'] && (hotkeyMapping[hotkeyConfig[cfg]['defaultHotkey']] = cfg)
				};
				setLocalStorage('hotkeyMapping', hotkeyMapping)
			};
			getLocalStorage('chatCommand') ? chatCommand = JSON.parse(getLocalStorage('chatCommand')) : (chatCommand = defaultHotkeyMessageSend, setLocalStorage('chatCommand', chatCommand))
		};
		this.replaceTos = function() {
			$('.tosBox')['remove']()
		};

		/*
		this.setupOption = function() {
			var optNum0 = 13;
			var optNum1 = 12;

			var options = {


				opt_hzoom: {
					text: '高速ズーム',
					"\x64\x65\x66\x61\x75\x6C\x74": 0,
					handler: function(va) {
						if(va) {
							setLocalStorage('opt_zoom_speed', vh = 0.82);
						} else {
							setLocalStorage('opt_zoom_speed', vh = 0.94);
						}
					}
				},

				opt_self_name: {
					text: '自分の名前を隠す',
					"\x64\x65\x66\x61\x75\x6C\x74": 0,
					handler: function(va) {
						myApp.isHideSelfName = va
					}
				},
				opt_name: {
					text: '名前を隠す',
					handler: function(va) {
						setNames(!va)
					}
				},
				opt_color: {
					text: 'blobの色を隠す',
					handler: function(va) {
						setColors(va)
					}
				},
				opt_mass: {
					text: '質量を表示',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						setShowMass(va)
					}
				},
				opt_stats: {
					text: 'Skip stats',
					disabled: 1,
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						setSkipStats(va)
					}
				},
				opt_mapgrid: {
					text: 'エリア座標を表示',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isEnableMapGrid = va
					}
				},
				opt_cursorline: {
					text: 'カーソルラインを表示',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isEnableCursorLine = va
					}
				},
				opt_zoom: {
					text: 'ズーム',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isEnableZoom = va
					}
				},
				opt_food: {
					text: 'ペレットを隠す',
					handler: function(va) {
						myApp.isEnableHideFood = va
					}
				},
				opt_gridline: {
					text: 'グリッドライン',
					handler: function(va) {
						myApp.isEnableGridline = va
					}
				},
				opt_simple_drawing: {
					text: 'アニメーションなし',
					"\x64\x65\x66\x61\x75\x6C\x74": 0,
					handler: function(va) {
						myApp.isEnableSimpleDrawing = va
					}
				},
				opt_score: {
					text: 'スコア',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isShowScroll = va
					}
				},
				opt_ste: {
					text: 'STE',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isShowSTE = va
					}
				},
				opt_ball_total: {
					text: '[n/16]',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isShowBallTotal = va
					}
				},
				opt_minimap: {
					text: 'ミニマップ',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						va ? minimap.show() : minimap.hide()
					}
				},
				//opt_mousew: {
				//	text: 'マウスで餌',
				//	disabled: 1,
				//	handler: function (va) {
				//		myApp.isEnableMouseW = va
				//	}
				//},
				opt_same_food_color: {
					text: '虹色表示',
					handler: function(va) {
						myApp.isSameColorFood = !va
					}
				},
				opt_transparent_cell: {
					text: 'blobを透過',
					handler: function(va) {
						myApp.isTransparentCell = va
					}
				},
				opt_fps: {
					text: 'フレームレート',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isShowFPS = va
					}
				},
				opt_packetIO: {
					text: 'Packets I/O',
					disabled: 1,
					handler: function(va) {
						myApp.isShowPacketIO = va
					}
				},
				opt_auto_hide_mass: {
					text: '質量を自動で隠す',
					"\x64\x65\x66\x61\x75\x6C\x74": 0,
					handler: function(va) {
						myApp.isAutoHideMass = va
					}
				},
				opt_auto_hide_name: {
					text: '名前を自動で隠す',
					"\x64\x65\x66\x61\x75\x6C\x74": 0,
					handler: function(va) {
						myApp.isAutoHideName = va
					}
				},
				opt_show_text_stroke_line: {
					text: 'テキストの影を表示',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isShowTextStrokeLine = va
					}
				},
				opt_lock_zoom: {
					text: '自動ズーム',
					handler: function(va) {
						myApp.isEnableLockZoom = !va
					}
				},
				opt_split_ind: {
					text: 'スプリットインジケータ',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isEnableSplitInd = va
					}
				},
				opt_custom_skin: {
					text: 'カスタムスキン',
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isEnableCustomSkin = va
					}
				},
				opt_other_skin: {
					text: 'Yin Skins',
					disabled: 1,
					handler: function(va) {
						myApp.isEnableOtherSkinSupport = va
					}
				},
				opt_chatbox: {
					text: 'チャットボックス',
					disabled: 0,
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						va ? chatRoom.show() : chatRoom.hide()
					}
				},
				opt_chatpopup: {
					text: 'チャットポップアップ',
					disabled: 1,
					"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(va) {
						myApp.isEnableChatpopup = va
					}
				},

				opt_mousecontrol: {
					text: 'マウスボタンによる操作',
					//"\x64\x65\x66\x61\x75\x6C\x74": 1,
					handler: function(s) {
						myApp.isEnableMouseControl = s;
					}
				},

				opt_mouse_button_swap: {
					text: '左右ボタンの機能を入れ替える',
					handler: function(s) {
						myApp.swapMouseButtonsLR = s;
					}
				},

				opt_chatbox_location: {
					text: 'チャットを下に表示',
					handler: function(s) {
						myApp.showChatAtBottom = s;
					}
				},

				opt_split_order_marker: {
					text: '分裂セルマーカー',
					"\x64\x65\x66\x61\x75\x6C\x74": 0,
					handler: function(s) {
						myApp.showSplitOrderMarker = s;
					}
				},

				opt_show_cursor_crosshair: {
					text: 'AIMクロスヘア',
					//disabled: 1,
					"\x64\x65\x66\x61\x75\x6C\x74": 0,
					handler: function(s) {
						myApp.showCursorCrosshair = s;
					}
				},


			};
			*/


			this.setupOption = function() {
				var optNum0 = 12;
				var optNum1 = 12;

				var options = {
					opt_self_name: {
						text: 'Hide my name',
						default: 0,
						handler: function(va) {
							myApp.isHideSelfName = va
						}
					},
					opt_name: {
						text: 'Hide Names',
						handler: function(va) {
							setNames(!va)
						}
					},
					opt_color: {
						text: 'Hide blob colors',
						handler: function(va) {
							setColors(va)
						}
					},
					opt_mass: {
						text: 'Show mass',
						default: 1,
						handler: function(va) {
							setShowMass(va)
						}
					},
					opt_stats: {
						text: 'Skip stats',
						disabled: !0,
						default: 1,
						handler: function(va) {
							setSkipStats(va)
						}
					},
					opt_mapgrid: {
						text: 'Grid Locations',
						default: 0,
						handler: function(va) {
							myApp.isEnableMapGrid = va
						}
					},
					opt_cursorline: {
						text: 'Cursor Line',
						default: 1,
						handler: function(va) {
							myApp.isEnableCursorLine = va
						}
					},
					opt_zoom: {
						text: 'Zoom',
						default: 1,
						handler: function(va) {
							myApp.isEnableZoom = va
						}
					},
					opt_food: {
						text: 'Hide Pellets',
						handler: function(va) {
							myApp.isEnableHideFood = va
						}
					},
					opt_gridline: {
						text: 'Gridlines',
						default: 1,
						handler: function(va) {
							myApp.isEnableGridline = va
						}
					},
					/*opt_simple_drawing: {
					 text: 'No Animations',
					 default: 0,
					 handler: function(va) {
					 myApp.isEnableSimpleDrawing = va
					 }
					 },*/
					opt_score: {
						text: 'Score',
						default: 1,
						handler: function(va) {
							myApp.isShowScroll = va
						}
					},
					opt_ste: {
						text: 'STE',
						default: 1,
						handler: function(va) {
							myApp.isShowSTE = va
						}
					},
					opt_ball_total: {
						text: '[n/16]',
						default: 1,
						handler: function(va) {
							myApp.isShowBallTotal = va
						}
					},
					opt_minimap: {
						text: 'Minimap',
						default: 1,
						handler: function(va) {
							va ? minimap.show() : minimap.hide()
						}
					},
					//opt_mousew: {
					//	text: 'Mouse Feed',
					//	disabled: 1,
					//	handler: function (va) {
					//		myApp.isEnableMouseW = va
					//	}
					//},
					opt_same_food_color: {
						text: 'Rainbow Color',
						handler: function(va) {
							myApp.isSameColorFood = !va
						}
					},
					opt_transparent_cell: {
						text: 'Transparent Blobs',
						handler: function(va) {
							myApp.isTransparentCell = va
						}
					},
					opt_fps: {
						text: 'FPS',
						default: 1,
						handler: function(va) {
							myApp.isShowFPS = va
						}
					},
					opt_packetIO: {
						text: 'Packets I/O',
						disabled: 1,
						handler: function(va) {
							myApp.isShowPacketIO = va
						}
					},
					opt_auto_hide_mass: {
						text: 'Auto Hide Mass',
						default: 0,
						handler: function(va) {
							myApp.isAutoHideMass = va
						}
					},
					opt_auto_hide_name: {
						text: 'Auto Hide Names',
						default: 0,
						handler: function(va) {
							myApp.isAutoHideName = va
						}
					},
					opt_show_text_stroke_line: {
						text: 'Text Shadows',
						default: 1,
						handler: function(va) {
							myApp.isShowTextStrokeLine = va
						}
					},
					opt_lock_zoom: {
						text: 'Auto Zoom',
						handler: function(va) {
							myApp.isEnableLockZoom = !va
						}
					},
					opt_split_ind: {
						text: 'Split Indicators',
						default: 1,
						handler: function(va) {
							myApp.isEnableSplitInd = va
						}
					},
					opt_custom_skin: {
						text: 'Custom Skins',
						default: 1,
						handler: function(va) {
							myApp.isEnableCustomSkin = va
						}
					},
					opt_other_skin: {
						text: 'Yin Skins',
						disabled: 1,
						handler: function(va) {
							myApp.isEnableOtherSkinSupport = va
						}
					},
					opt_chatbox: {
						text: 'Chatbox',
						disabled: 0,
						default: 1,
						handler: function(va) {
							va ? chatRoom.show() : chatRoom.hide()
						}
					},
					opt_chatpopup: {
						text: 'Chat Popup',
						disabled: 0,
						default: 1,
						handler: function(va) {
							myApp.isEnableChatpopup = va
						}
					},

					opt_mousecontrol: {
						text: 'Enable Mouse Control',
						handler: function(s) {
							myApp.isEnableMouseControl = s;
						}
					},

					opt_mouse_button_swap: {
						text: 'Invert Mouse Buttons',
						handler: function(s) {
							myApp.swapMouseButtonsLR = s;
						}
					},

					opt_chatbox_location: {
						text: 'Chat Box Location',
						handler: function(s) {
							myApp.showChatAtBottom = s;
						}
					},

					opt_split_order_marker: {
						text: 'Split Order Marker',
						"\x64\x65\x66\x61\x75\x6C\x74": 0,
						handler: function(s) {
							myApp.showSplitOrderMarker = s;
						}
					},

					opt_show_cursor_crosshair: {
						text: 'Aim Crosshair',
						//disabled: 1,
						"\x64\x65\x66\x61\x75\x6C\x74": 0,
						handler: function(s) {
							myApp.showCursorCrosshair = s;
						}
					},


				};



			window.setYinSkinSupport = function(vb) {
				options.opt_other_skin['handler'](vb);
				setLocalStorage('opt_other_skin', vb)
			};
			var configs = [],
				vf;
			for(vf in options) {
				options[vf]['disabled'] || configs.push('<input id="' + vf + '" type="checkbox"> ' + options[vf]['text'] + '<br>')
			};

			var cfg0 = configs.splice(0, optNum0);
			for(var i = 0; i < cfg0.length; i++) {
				$('.firstSettings')['append'](cfg0[i])
			};

			var cfg1 = configs.splice(0, optNum1);
			for(i = 0; i < cfg1.length; i++) {
				$('.secondSettings')['append'](cfg1[i])
			};

			var cfg2 = configs;	//['splice'](0, 1);
			for(i = 0; i < cfg2.length; i++) {
				$('.extraSettings')['append'](cfg2[i])
			};

			$('input:checkbox')['change'](function() {
				var vb = $(this)['prop']('checked'),
					ve = $(this)['prop']('id');
				setLocalStorage(ve, vb);
				options[ve] && options[ve]['handler'](vb)
			});
			for(vf in options) {
				getLocalStorage(vf) ? 'true' == getLocalStorage(vf) && ('opt_other_skin' == vf ? setYinSkinSupport(1) : $('#' + vf)['click']()) : options[vf]['default'] && $('#' + vf)['click']()
			};


			/*
			 $('.zoomSpeed')['append']('Zoom Speed: <span id="txt_zoom_speed">0.97</span></div><input oninput="$(#txt_zoom_speed).text(this.value);" style="width:100%;" type="range" id="opt_zoom_speed" name="opt_zoom_speed" min="0.88" max="0.99" step="0.01" value="0.9">');
			 $('#opt_zoom_speed')['change'](function () {
			 vh = $('#opt_zoom_speed')['val']();
			 setLocalStorage('opt_zoom_speed', vh)
			 })*/
		};
		this.scoreInfo = function(va) {
			if(!va || !va.length) {
				return ''
			};
			var vb = '';
			myApp.isShowSTE && (vb += '   STE: ' + this.getSTE(va));
			myApp.isShowBallTotal && (vb += '   [' + va.length + '/16]');
			return vb
		};
		this.scoreTxt = function(va) {
			return myApp.isShowScroll ? va : ''
		};
		this.isShowScoreInfo = function() {
			return myApp.isShowScroll || myApp.isShowSTE || myApp.isShowBallTotal
		};
		this.showSystemMessage = function() {
			return 0
		};
		this.getSTE = function(va) {
			for(var vb = 0, vf = 0; vf < va.length; vf++) {
				va[vf] && va[vf]['I'] && va[vf]['I']['lb_w_text'] && va[vf]['I']['lb_w_text'] > vb && (vb = va[vf]['I']['lb_w_text'])
			};
			return ~~(0.375 * vb)
		};
		this.createGameInfoBox = function() {
			$('.gameinfo')['prepend']("<div id='game_info' class='agario-panel'><p id='ip_info'></p><p id='region_info'></p><p id='gamemode_info'></p><p id='party_code_info'></p><p id='lb_info'></p></div>");
			$('#game_info')['append']('<button id ="btn_copy_gameinfo" class="btn btn-warning btn-hotkeys" type="button">Copy</button>')
		};
		this.updateLBInfo = function() {
			var va = '',
				vb = myApp.getLeaderBoard();
			if(vb) {
				for(var vf = 0; vf < vb.length; vf++) {
					va += '<div>' + (vf + 1) + '.  ' + escapeHtml(vb[vf]) + '</div>'
				}
			};
			$('#lb_info')['html'](va)
		};
		this.isPrivateServer = function() {
			return PRIVATE_SERVER_IP == currentIP
		};
		this.getCurrentIP = function() {
			return this.isPrivateServer() ? '----------' : currentIP.substring(5, currentIP.length)
		};
		this.getRegion = function() {
			return $('#region option:selected')['text']()['split'](' ')[0]
		};
		this.getGameMode = function() {
			return this.isPrivateServer() ? '----------' : $('#gamemode option:selected')['text']()
		};
		this.getTeamName = function() {
			return ('' == $('#team_name')['val']() ? '' : $('#team_name')['val']())['trim']()
			//return '';
		};
		this.getCustomSkinUrl = function() {
			var va = ($('#skin_url')['val']() + '')['trim']();
			return '' == va ? '' : va
		};
		this.getCurrentPartyCode = function() {
			return $('.partyToken')['val']()
		};
		this.showMessage = function(va, vb) {
			0 == $('#message_dialog')['length'] && myApp.createMessageDialog();
			$('#message_dialog_title')['text'](va);
			$('#message_dialog_content')['html'](vb);
			$('#message_dialog')['modal']({
				show: 'true'
			})
		};
		this.getName = function() {
			var name = $('#nick')['val']()['trim'](); -1 != name.indexOf() && (name = '');
			return /*this.getTeamName() + */'' == name ? '' : name
		};
		this.getNameEx = function() {
			//return this.getTeamName() + this.getName();
			return this.getName();
		}
		this.getLeaderBoard = function() {
			var va = [],
				entries = getLB();
			if(entries) {
				for(var vf = 0; vf < entries.length; vf++) {
					va[va.length] = '' == entries[vf].name ? 'An unnamed cell' : escapeHtml(entries[vf].name)
				}
			};
			return va
		};
		this.setupHotKey = function() {
			hotkeyConfig = {
				hk_start_new_game: {
					defaultHotkey: 'N',
					name: 'Start new game',
					keyDown: function() {
						//var team = document.getElementById('team_name').value;
						setNick(myApp.getName(), myApp.getTeamName())
					},
					type: 'NORMAL'
				},
				hk_cheatw: {
					defaultHotkey: 'E',
					name: 'Macro W',
					keyDown: function() {
						myApp.autoW = 1;
						handleQuickW()
					},
					keyUp: function() {
						myApp.autoW = 0
					},
					type: 'NORMAL'
				},
				hk_quick_space: {
					defaultHotkey: 'T',
					name: 'Quick space',
					keyDown: function() {
						myApp.quickSpace || (myApp.quickSpace = 1, quickSpace())
					},
					keyUp: function() {
						myApp.quickSpace = 0
					},
					type: 'NORMAL'
				},
				hk_double_space: {
					defaultHotkey: 'G',
					name: 'Double space',
					keyDown: function() {
						myApp.doubleSpace || (myApp.doubleSpace = 1, doubleSpace())
						trace("double Space");
					},
					keyUp: function() {
						myApp.doubleSpace = 0
					},
					type: 'NORMAL'
				},
				hk_stop_movement_toggle: {
					defaultHotkey: 'ALT_S',
					name: 'Stop movement(Toggle)',
					keyDown: function() {
						myApp.isStopMovement = !myApp.isStopMovement;
						myApp.specTeammate = null
						//trace("isStopMovement:" + myApp.isStopMovement);
						MOVING = !MOVING;
					},
					type: 'NORMAL'
				},
				hk_stop_movement: {
					defaultHotkey: 'S',
					name: 'Stop movement(Temporary)',
					keyDown: function() {
						myApp.isStopMovement = 1;
						myApp.specTeammate = null;
						moveTo(null, null)
						//trace("isStopMovement:" + myApp.isStopMovement);
						MOVING = false;

					},
					keyUp: function() {
						myApp.isStopMovement = 0
						//trace("isStopMovement:" + myApp.isStopMovement);
						MOVING = true;
					},
					type: 'NORMAL'
				},
				hk_split_ind: {
					defaultHotkey: 'I',
					name: 'On/off split indicator',
					keyDown: function() {
						$('#opt_split_ind')['click']()
					},
					type: 'NORMAL'
				},
				hk_lock_zoom: {
					defaultHotkey: 'L',
					name: 'On/off auto zoom',
					keyDown: function() {
						$('#opt_lock_zoom')['click']()
					},
					type: 'NORMAL'
				},
				hk_attack_range: {
					defaultHotkey: 'A',
					name: 'Show attack range(Temporary)',
					keyDown: function() {
						myApp.isEnableAttackRange = 1
					},
					keyUp: function() {
						myApp.isEnableAttackRange = 0
					},
					type: 'NORMAL'
				},
				hk_attack_range_toggle: {
					defaultHotkey: 'ALT_A',
					name: 'Show attack range(Toggle)',
					keyDown: function() {
						myApp.isEnableAttackRange = !myApp.isEnableAttackRange
					},
					type: 'NORMAL'
				},
				hk_spec_teammate: {
					defaultHotkey: 'V',
					name: 'Spectate teammate',
					keyDown: function() { },
					type: 'NORMAL'
				},
				hk_custom_skin: {
					defaultHotkey: '',
					name: 'On/off custom skin',
					keyDown: function() {
						$('#opt_custom_skin')['click']()
					},
					type: 'NORMAL'
				},
				hk_skin: {
					defaultHotkey: '',
					name: 'Show/hide skins',
					keyDown: function() {
						$('#opt_skin')['click']()
					},
					type: 'NORMAL'
				},
				hk_same_food_color: {
					defaultHotkey: '',
					name: 'On/off rainbow color',
					keyDown: function() {
						$('#opt_same_food_color')['click']()
					},
					type: 'NORMAL'
				},
				hk_transparent_cell: {
					defaultHotkey: '',
					name: 'On/off transparent cell',
					keyDown: function() {
						$('#opt_transparent_cell')['click']()
					},
					type: 'NORMAL'
				},
				hk_fps: {
					defaultHotkey: '',
					name: 'Show/Hide FPS counter',
					keyDown: function() {
						$('#opt_fps')['click']()
					},
					type: 'NORMAL'
				},
				hk_zoom_a: {
					defaultHotkey: '1',
					name: 'Zoom level 1',
					keyDown: function() {
						myApp.isEnableLockZoom || hotkeyConfig.hk_lock_zoom['keyDown']();
						setZoomLevel(0.75)
					},
					type: 'NORMAL'
				},
				hk_zoom_b: {
					defaultHotkey: '2',
					name: 'Zoom level 2',
					keyDown: function() {
						myApp.isEnableLockZoom || hotkeyConfig.hk_lock_zoom['keyDown']();
						setZoomLevel(0.3)
					},
					type: 'NORMAL'
				},
				hk_zoom_c: {
					defaultHotkey: '3',
					name: 'Zoom level 3',
					keyDown: function() {
						myApp.isEnableLockZoom || hotkeyConfig.hk_lock_zoom['keyDown']();
						setZoomLevel(0.15)
					},
					type: 'NORMAL'
				},
				hk_zoom_d: {
					defaultHotkey: '4',
					name: 'Zoom level 4',
					keyDown: function() {
						myApp.isEnableLockZoom || hotkeyConfig.hk_lock_zoom['keyDown']();
						setZoomLevel(0.08)
					},
					type: 'NORMAL'
				},
				hk_zoom_e: {
					defaultHotkey: '5',
					name: 'Zoom level 5',
					keyDown: function() {
						myApp.isEnableLockZoom || hotkeyConfig.hk_lock_zoom['keyDown']();
						setZoomLevel(0.05)
					},
					type: 'NORMAL'
				},
				hk_name: {
					defaultHotkey: 'ALT_N',
					name: 'Show/hide names',
					keyDown: function() {
						$('#opt_name')['click']()
					},
					type: 'NORMAL'
				},
				hk_self_name: {
					defaultHotkey: '',
					name: 'Show/hide own name',
					keyDown: function() {
						$('#opt_self_name')['click']()
					},
					type: 'NORMAL'
				},
				hk_color: {
					defaultHotkey: '',
					name: 'Show/hide colors',
					keyDown: function() {
						$('#opt_color')['click']()
					},
					type: 'NORMAL'
				},
				hk_mass: {
					defaultHotkey: '',
					name: 'Show/hide mass',
					keyDown: function() {
						$('#opt_mass')['click']()
					},
					type: 'NORMAL'
				},
				hk_stat: {
					defaultHotkey: '',
					name: 'On/off Skip stats',
					keyDown: function() {
						$('#opt_stats')['click']()
					},
					type: 'NORMAL'
				},
				hk_zoom: {
					defaultHotkey: 'ALT_Z',
					name: 'On/off Zoom',
					keyDown: function() {
						$('#opt_zoom')['click']()
					},
					type: 'NORMAL'
				},
				hk_food: {
					defaultHotkey: 'F',
					name: 'Show/hide Pellets',
					keyDown: function() {
						$('#opt_food')['click']()
					},
					type: 'NORMAL'
				},
				hk_gridline: {
					defaultHotkey: 'ALT_G',
					name: 'Show/hide Gridline',
					keyDown: function() {
						$('#opt_gridline')['click']()
					},
					type: 'NORMAL'
				},
				hk_border: {
					defaultHotkey: 'go_B',
					name: 'Reset Border',
					keyDown: function() { },
					type: 'NORMAL'
				},
				hk_simple_draw: {
					defaultHotkey: '',
					name: 'On/off Simple draw',
					keyDown: function() {
						$('#opt_simple_drawing')['click']()
					},
					type: 'NORMAL'
				},
				hk_score: {
					defaultHotkey: '',
					name: 'Show/hide Score',
					keyDown: function() {
						$('#opt_score')['click']()
					},
					type: 'NORMAL'
				},
				hk_ste: {
					defaultHotkey: '',
					name: 'Show/hide STE',
					keyDown: function() {
						$('#opt_ste')['click']()
					},
					type: 'NORMAL'
				},
				hk_n16: {
					defaultHotkey: '',
					name: 'Show/hide [n/16]',
					keyDown: function() {
						$('#opt_ball_total')['click']()
					},
					type: 'NORMAL'
				},
				hk_auto_hide_mass: {
					defaultHotkey: '',
					name: 'On/off Auto hide mass',
					keyDown: function() {
						$('#opt_auto_hide_mass')['click']()
					},
					type: 'NORMAL'
				},
				hk_auto_hide_name: {
					defaultHotkey: '',
					name: 'On/off Auto hide name',
					keyDown: function() {
						$('#opt_auto_hide_name')['click']()
					},
					type: 'NORMAL'
				},
				hk_show_text_stroke_line: {
					defaultHotkey: '',
					name: 'Show/hide Text shadow',
					keyDown: function() {
						$('#opt_show_text_stroke_line')['click']()
					},
					type: 'NORMAL'
				},
				hk_minimap: {
					defaultHotkey: 'ALT_M',
					name: 'Show/hide Minimap',
					keyDown: function() {
						$('#opt_minimap')['click']()
					},
					type: 'NORMAL'
				},
				//hk_mousew: {
				//	defaultHotkey: '',
				//	name: 'マウスでのwをon/off',
				//	keyDown: function () {
				//		$('#opt_mousew')['click']()
				//	},
				//	type: 'NORMAL'
				//},
				hk_send_msg: {
					defaultHotkey: 'ENTER',
					name: 'Chatbox send message',
					keyDown: function() {
						chatRoom.enter()
					},
					type: 'NORMAL'
				},
				hk_send_msg1: {
					defaultHotkey: 'ALT_1',
					name: 'Chatbox send message 1',
					keyDown: function() {
						console.log('CHAT MESSAGE');
						chatRoom.sendMessage(chatCommand.input_hk_send_msg1)
					},
					type: 'TEXT'
				},
				hk_send_msg2: {
					defaultHotkey: 'ALT_2',
					name: 'Chatbox send message 2',
					keyDown: function() {
						chatRoom.sendMessage(chatCommand.input_hk_send_msg2)
					},
					type: 'TEXT'
				},
				hk_send_msg3: {
					defaultHotkey: 'ALT_3',
					name: 'Chatbox send message 3',
					keyDown: function() {
						chatRoom.sendMessage(chatCommand.input_hk_send_msg3)
					},
					type: 'TEXT'
				},
				hk_send_msg4: {
					defaultHotkey: 'ALT_4',
					name: 'Chatbox send message 4',
					keyDown: function() {
						chatRoom.sendMessage(chatCommand.input_hk_send_msg4)
					},
					type: 'TEXT'
				},
				hk_send_msg5: {
					defaultHotkey: 'ALT_5',
					name: 'Chatbox send message 5',
					keyDown: function() {
						chatRoom.sendMessage(chatCommand.input_hk_send_msg5)
					},
					type: 'TEXT'
				},
				hk_send_msg6: {
					defaultHotkey: 'ALT_6',
					name: 'Chatbox send message 6',
					keyDown: function() {
						chatRoom.sendMessage(chatCommand.input_hk_send_msg6)
					},
					type: 'TEXT'
				},
				hk_send_msg7: {
					defaultHotkey: 'ALT_7',
					name: 'Chatbox send message 7',
					keyDown: function() {
						chatRoom.sendMessage(chatCommand.input_hk_send_msg7)
					},
					type: 'TEXT'
				},
				hk_send_msg8: {
					defaultHotkey: 'ALT_8',
					name: 'Chatbox send message 8',
					keyDown: function() {
						chatRoom.sendMessage(chatCommand.input_hk_send_msg8)
					},
					type: 'TEXT'
				},
				hk_send_msg9: {
					defaultHotkey: 'ALT_9',
					name: 'Chatbox send message 9',
					keyDown: function() {
						chatRoom.sendMessage(chatCommand.input_hk_send_msg9)
					},
					type: 'TEXT'
				},
				hk_send_msg10: {
					defaultHotkey: 'ALT_0',
					name: 'Chatbox send message 10',
					keyDown: function() {
						chatRoom.sendMessage(chatCommand.input_hk_send_msg10)
					},
					type: 'TEXT'
				}
			}
		};

		//this.setupMouseConfig = function() {
		//	mouseConfig = {
		//		mk_enable_mouse_control: {


		//		}

		//	}
		//}

		this.createMessageDialog = function() {
			var va, vb;
			vb = $("<div class='modal-footer'>");
			vb.append("<button type='button' class='btn btn-default' data-dismiss='modal'>OK</button>");
			va = $("<div class='modal-content'/>");
			va.append($("<div class='modal-header'/>")['append']("<button type='button' class='close' data-dismiss='modal'>&times;</button><h4 id='message_dialog_title' class='modal-title'></h4>"));
			va.append($("<div id='message_dialog_content' class='modal-body'>"));
			va.append(vb);
			va = $("<div id='message_dialog' class='modal fade' role='dialog'/>")['append']("<div class='modal-dialog'/>")['append'](va);
			$('body')['append'](va);
			$('#message_dialog')['modal']({
				backdrop: 'static',
				keyboard: 0
			});
			$(document)['on']('shown.bs.modal', '#message_dialog', function() {
				var va = $('#message_dialog>.modal-content')['outerHeight'](),
					vb = $(document)['outerHeight']();
				va > vb ? $('#message_dialog')['css']('overflow', 'auto') : $('#message_dialog')['css']('margin-top', vb / 2 - va / 2 - 40)
			});
			$(document)['on']('hide.bs.modal', '#message_dialog', function() { })
		};
		this.setUpHotKeyConfigPage = function() {
			$('.left-side > div:nth-child(2)')['after']('<div class="agario-panel agario-side-panel agarioProfilePanel level" style="display: block !important;text-align:center"><button type="button" class="btn btn-success btn-hotkey" data-toggle="modal" data-target="#hotkeys_setting">Hotkeys</button></div>');
			var va, vb;
			vb = $('<div class="modal-footer" style="background: #222;">');
			vb.append("<button onclick='resetDefaultHotkey();' type='button' class='btn btn-blue' style='float:left;'>Reset to Default</button>");
			vb.append("<button type='button' class='btn btn-red' data-dismiss='modal'>Cancel</button>");
			vb.append("<button id='btn_save_hotkey' onclick='saveHotkeys();' type='button' class='btn btn-green' data-dismiss='modal'>Save</button>");
			va = $("<div class='modal-content' style='background: #222;'/>");
			va.append($("<div class='modal-header'/>")['append']("<button type='button' class='close' data-dismiss='modal'>&times;</button><h4 class='modal-title'>Hotkey Setup</h4>"));
			va.append($("<div id='hotkey_modal_body' class='modal-body'>")['append'](myApp.getHotkeyDivHtml()));
			va.append(vb);
			va = $("<div id='hotkeys_setting' class='modal fade' role='dialog'/>")['append']("<div class='modal-dialog'/>")['append'](va);
			$('body')['append'](va);
			$(document)['on']('hide.bs.modal', '#hotkeys_setting', function() {
				selectedHotkeyRow && selectedHotkeyRow.removeClass('table-row-selected');
				selectedHotkeyRow = null;
				myApp.refreshHotkeySettingPage()
			});
			$('#hotkey_table .row')['not']('.header')['click'](function() {
				selectedHotkeyRow && selectedHotkeyRow.removeClass('table-row-selected');
				selectedHotkeyRow = $(this);
				selectedHotkeyRow.addClass('table-row-selected')
			})
		};
		window.saveHotkeys = function() {
			var va = $('.hotkey');
			hotkeyMapping = {};
			for(var vb = 0; vb < va.length; vb++) {
				hotkeyMapping[$(va[vb])['text']()] = $(va[vb])['attr']('data-hotkeyid')
			};
			setLocalStorage('hotkeyMapping', hotkeyMapping);
			for(var vf in chatCommand) {
				chatCommand[vf] = $('#' + vf)['val']()
			};
			setLocalStorage('chatCommand', chatCommand)
		};
		this.copyGameInfo = function() {
			var va;
			va = 'Current IP = ' + myApp.getCurrentIP();
			va += '\nRegion : ' + $('#region option:selected')['text']()['split'](' ')[0];
			va += '\nGame mode : ' + $('#gamemode option:selected')['text']();
			va += '\nParty Code : ' + myApp.getCurrentPartyCode();
			var vb = myApp.getLeaderBoard();
			if(vb && 0 != vb.length) {
				for(var vf = 0; vf < vb.length; vf++) {
					va += '\n' + (vf + 1) + '.  ' + vb[vf]
				}
			};
			copyToClipboard(va)
		};
		window.resetDefaultHotkey = function() {
			var va;
			va = hotkeyMapping;
			defaultHotkeyMapping = {};
			for(var vb in hotkeyConfig) {
				hotkeyConfig[vb]['defaultHotkey'] && '' != hotkeyConfig[vb]['defaultHotkey'] && (defaultHotkeyMapping[hotkeyConfig[vb]['defaultHotkey']] = vb)
			};
			hotkeyMapping = defaultHotkeyMapping;
			myApp.refreshHotkeySettingPage();
			hotkeyMapping = va;
			defaultHotkeyMapping = null;
			for(var vf in defaultHotkeyMessageSend) {
				$('#' + vf)['val'](defaultHotkeyMessageSend[vf])
			}
		};
		this.refreshHotkeySettingPage = function() {
			for(var va = $('.hotkey'), vb = 0; vb < va.length; vb++) {
				$(va[vb])['text'](' ')
			};
			for(var vf in hotkeyMapping) {
				$('[data-hotkeyid=' + hotkeyMapping[vf] + ']')['text'](vf)
			};
			for(var vg in chatCommand) {
				$('#' + vg)['val'](chatCommand[vg])
			}
		};
		this.getHotkeyDivHtml = function() {
			var va = '',
				vb = $("<div id='hotkey_setting'></div>"),
				vf = $("<div id='hotkey_table' class='table'></div>"),
				vg = $("<div class='row header'></div>");
			vg.append($("<div class='cell' style='width:170px;'>HotKey/div>"));
			vg.append($("<div class='cell' style='width:222px;'>Function</div>"));
			vg.append($("<div class='cell'>Message</div>"));
			vf.append(vg);
			var vg = null,
				vh;
			for(vh in hotkeyConfig) {
				vg = $("<div class='row'></div>"), vg.append($("<div data-hotkeyId='" + vh + "' class='cell hotkey'>" + getHotkeyById(vh) + '</div>')), vg.append($("<div class='cell'>" + hotkeyConfig[vh]['name'] + '</div>')), 'TEXT' == hotkeyConfig[vh]['type'] ? vg.append($("<div class='cell'><input id='input_" + vh + "' maxlength='200' style='width:100%;color:black;' type='text' value='" + chatCommand['input_' + vh] + "'></input></div>")) : vg.append($("<div class='cell'> / </div>")), vf.append(vg)
			};
			vb.append(vf);
			va += $('<p>Step 1: Click on the function item</p>')[0]['outerHTML'];
			va += $('<p>Step 2: Press wanted hotkey to modify</p>')[0]['outerHTML'];
			va += $('<p>Press [DEL] key to remove selected hotkey</p>')[0]['outerHTML'];
			va += $('<p>Allowed hotkey combinations: [CTRL] + [ALT] + 0-9, a-z, [TAB], [ENTER]</p>')[0]['outerHTML'];
			va += $('<br></br>')[0]['outerHTML'];
			va += vb[0]['outerHTML'];
			return $('<div/>')['append'](va)['html']()
		};
		this.checkVersion = function() {
			var va = getLocalStorage('lastestVersion');
			va && va == myApp.version || (myApp.applyNewUpdate(), setLocalStorage('lastestVersion', myApp.version))
		};
		this.showAnnouncement = function() { };
		this.applyNewUpdate = function() { };
		this.setupHints = function() { };
		this.setupHintsImpl = function(va, vb) {
			va.addClass('hint--bottom hint--rounded');
			va.attr('data-hint', vb)
		};
		this.ajax = function(va, vb, vf, vg) {
			vg = null;
			var vh;
			try {
				vh = new XMLHttpRequest
			} catch(l) {
				try {
					vh = new ActiveXObject('Msxml2.XMLHTTP')
				} catch(L) {
					try {
						vh = new ActiveXObject('Microsoft.XMLHTTP')
					} catch(B) {
						return alert('Your browser does not support Ajax.'), 0
					}
				}
			};
			vh.onreadystatechange = function() {
				4 == vh.readyState && vf(vh)
			};
			vh.open(vb, va, 1);
			vh.send(vg);
			return vh
		};
		this.getSkinImage = function(va) {
			if(!va || '' == va) {
				return null
			};
			if(customSkin[va]) {
				return customSkin[va]
			}; -1 == skinDownloadQueue.indexOf(va) && skinDownloadQueue.push(va);
			return null
		};
		this.downloadSkin = function() {
			if(0 != skinDownloadQueue.length) {
				var va = skinDownloadQueue.shift();
				customSkin[va] || (skinDownloadFail[va] && 5 < skinDownloadFail[va] ? myApp.getCustomSkinUrl() === va && $('#skin_url')['val']('')['trigger']('change') : window.postMessage({
					action: Action.IMAGE,
					data: va
				}, '*'))
			};
			setTimeout(myApp.downloadSkin, 2E3)
		};
		this.changePreviewImage = function(va) {
			$('#preview-img')['fadeOut'](315, function() {
				$(this)['attr']('src', va)['bind']('onreadystatechange load', function() {
					this.complete && $(this)['fadeIn'](315)
				})
			})
		}
	}

	var myApp = new MyApp();
	myApp.init();

	var playerDetailsByIdentifier = {},
		playerDetailsByNick = {},
		announcementSent = 0;

	//全体エントリ, 2000G
	function loadGameCore(_win, _jquery) {

		/*
		 var gameobject_index = 0;
		 function next_go_index(obj){
		 gameobject_index++;
		 console.log('gameobject_index:' + gameobject_index);
		 obj.go_index = gameobject_index;
		 }*/

		//GameObject
		function GameObject(_idx, _x, _y, _size, _col, _name) {
			this.id = _idx;
			this.o = this.x = _x;
			this.p = this.y = _y;
			this.n = this.size = _size;
			this.prevSize = _size;
			this.color = _col;
			this.a = [];
			this.go_Q();
			this.setGameObjectName(_name)

			//gameobject_index++;
			//this.go_index = gameobject_index;
			//next_go_index(this);
			this.debug_val = -1;
			this.can_split = false;
		}
		GameObject.prototype = {
			id: 0,	//index?
			a: null,
			name: null,
			k: null,
			I: null,
			x: 0,
			y: 0,
			size: 0,
			o: 0,
			p: 0,
			n: 0,
			go_C_x: 0,	//x
			go_C_y: 0,	//y
			m: 0,
			T: 0,
			K: 0,
			W: 0,
			A: 0,
			f: 0,		//isVirus?
			j: 0,
			L: 1,
			go_S_frameTick: 0,	//frameTick
			V: null,
			go_index: 0,
			debug_val: -1,
			can_split: false,
			go_R_remove: function() {
				//remove?
				var va;
				for(va = 0; va < gameObjects.length; va++) {
					if(gameObjects[va] == this) {
						gameObjects.splice(va, 1);
						break
					}
				};
				delete v_74[this.id];
				va = selfOwnedCells.indexOf(this); -1 != va && (v_8d = 1, selfOwnedCells.splice(va, 1));
				va = v_72.indexOf(this.id); -1 != va && v_72.splice(va, 1);
				this.A = 1
			},
			go_i: function() {
				//getTextSize
				//return Math.max(~~(0.3 * this.size), 24)
				return Math.max(~~(0.35 * this.size), 24)
				//return Math.max(~~(0.4 * this.size), 24);
			},
			getTextColor: function() {
				if(this.f) {
					return "#FFFFFF";//棘
				}
				var name = this.name;
				var textCol = "#FFFFFF";
				/*
				//if(name.startsWith('【先輩】')) textCol = "#88CCFF";
				//if(name.startsWith('【先輩】')) textCol = "#F0F0FF";
				if(name.startsWith('【先輩】')) textCol = "#FFFFFF";
				//if(name.startsWith('【敵】')) textCol = "#FF6666";
				if(name.startsWith('【敵】')) textCol = "#FF8866";
				*/
				return textCol;
			},

			setGameObjectName: function(name) {
				//makeNameLabel

				//var textCol = "#888888";
				//if(name.startsWith('【先輩】')) textCol = "#6666FF";
				//if(name.startsWith('【敵】')) textCol = "#FF4444";

				//var edgeCol = "#FFFFFF";
				//var edgeCol = "#000000";

				var vb = name.match(/\u0001([\u0002-\uffff]|[\u0002-\uffff]\uffff)$/g),
					vd = 0;
				vb && (vd = vb[0]['split']('')[1], 1 < vd.length && (this.img = vd.charCodeAt(0) + 65534));
				if(this.name = name) {
					var textCol = this.getTextColor();
					null == this.k ? (this.k = new DrawingLabel(this.go_i(), textCol, 1, "#000000"), this.k['v'] = Math.ceil(10 * v_88) / 10) : this.k.G(this.go_i()), this.k.lb_u_setText(this.name)
				}
			},
			go_Q: function() {
				for(var va = this.go_B() ; this.a['length'] > va;) {
					var vb = ~~(Math.random() * this.a['length']);
					this.a['splice'](vb, 1)
				};
				for(0 == this.a['length'] && 0 < va && this.a['push'](new VWWWW(this, this.x, this.y, this.size, Math.random() - 0.5)) ; this.a['length'] < va;) {
					vb = ~~(Math.random() * this.a['length']), vb = this.a[vb], this.a['push'](new VWWWW(this, vb.x, vb.y, vb.g, vb.b))
				}
			},
			go_B: function() {
				var va = 10;
				20 > this.size && (va = 0);
				this.f && (va = 30);
				var vb = this.size;
				this.f || (vb *= v_88);
				vb *= v_ba;
				this.T & 32 && (vb *= 0.25);
				return ~~Math.max(vb, va)
			},
			go_da: function() {
				this.go_Q();
				for(var va = this.a, vb = va.length, vd = 0; vd < vb; ++vd) {
					var ve = va[(vd - 1 + vb) % vb]['b'],
						vf = va[(vd + 1) % vb]['b'];
					va[vd]['b'] += (Math.random() - 0.5) * (this.j ? 3 : 1);
					va[vd]['b'] *= 0.7;
					10 < va[vd]['b'] && (va[vd]['b'] = 10); -10 > va[vd]['b'] && (va[vd]['b'] = -10);
					va[vd]['b'] = (ve + vf + 8 * va[vd]['b']) / 10
				};
				for(var vi = this, vj = this.f ? 0 : (this.id / 1E3 + v_7d / 1E4) % (2 * Math.PI), vd = 0; vd < vb; ++vd) {
					var vh = va[vd]['g'],
						ve = va[(vd - 1 + vb) % vb]['g'],
						vf = va[(vd + 1) % vb]['g'];
					if(15 < this.size && null != v_6e && 20 < this.size * v_88 && 0 < this.id) {
						var vg = 0,
							vk = va[vd]['x'],
							vl = va[vd]['y'];
						v_6e.ea(vk - 5, vl - 5, 10, 10, function(va) {
							va.P != vi && 25 > (vk - va.x) * (vk - va.x) + (vl - va.y) * (vl - va.y) && (vg = 1)
						});
						!vg && (va[vd]['x'] < fieldLeft || va[vd]['y'] < fieldTop || va[vd]['x'] > fieldRight || va[vd]['y'] > fieldBottom) && (vg = 1);
						vg && (0 < va[vd]['b'] && (va[vd]['b'] = 0), --va[vd]['b'])
					};
					vh += va[vd]['b'];
					0 > vh && (vh = 0);
					vh = this.j ? (19 * vh + this.size) / 20 : (12 * vh + this.size) / 13;
					va[vd]['g'] = (ve + vf + 8 * vh) / 10;
					ve = 2 * Math.PI / vb;
					vf = this.a[vd]['g'];
					this.f && 0 == vd % 2 && (vf += 5);
					va[vd]['x'] = this.x + Math.cos(ve * vd + vj) * vf;
					va[vd]['y'] = this.y + Math.sin(ve * vd + vj) * vf
				}
			},
			go_J: function() {
				if(0 >= this.id) {
					return 1
				};
				var d;
				d = (v_7d - this.K) / 120;
				d = 0 > d ? 0 : 1 < d ? 1 : d;
				var vb = 0 > d ? 0 : 1 < d ? 1 : d;
				this.go_i();
				if(this.A && 1 <= vb) {
					var vd = v_76.indexOf(this); -1 != vd && v_76.splice(vd, 1)
				};
				this.x = d * (this.go_C_x - this.o) + this.o;
				this.y = d * (this.go_C_y - this.p) + this.p;
				this.size = vb * (this.m - this.n) + this.n;
				return vb
			},
			go_H: function() {
				return 0 >= this.id ? 1 : this.x + this.size + 40 < v_70 - _screenCenterX / 2 / v_88 || this.y + this.size + 40 < v_71 - _screenCenterY / 2 / v_88 || this.x - this.size - 40 > v_70 + _screenCenterX / 2 / v_88 || this.y - this.size - 40 > v_71 + _screenCenterY / 2 / v_88 ? 0 : 1
			},
			drawGameObject: function(ctx) {
				//draw
				if(this.go_H()) {
					var vb = myApp.isEnableSimpleDrawing;
					if(15 > this.size) {
						myApp.isEnableHideFood || (myApp.isSameColorFood ? v_af.push({
							x: this.x,
							y: this.y,
							size: this.size
						}) : (ctx.beginPath(), ctx.fillStyle = this.color, ctx.arc(this.x, this.y, this.size + 5, 0, 2 * Math.PI, 0), ctx.fill()))
					} else {
						++this.go_S_frameTick;
						var vd = 0 < this.id && !this.f && !this.j && 0.4 > v_88;
						5 > this.go_B() && 0 < this.id && (vd = 1);
						if (this.L && !vd) {
							for (var ve = 0; ve < this.a['length']; ve++) {
								this.a[ve]['g'] = this.size
							}
						}
						;
						this.L = vd;
						ctx.save();
						this.W = v_7d;
						ve = this.go_J();
						this.A && (ctx.globalAlpha *= 1 - ve);
						ctx.lineWidth = 10;
						ctx.lineCap = 'round';
						ctx.lineJoin = this.f ? 'miter' : 'round';
						var ve = !this.f && 0 < this.id && 15 <= this.size && !this.j ? 1 : 0,
							vf = 0,
							_skin = null,
							_va;
						_va = this.name + this.color;
						_va = _va in playerDetailsByIdentifier ? playerDetailsByIdentifier[_va] : void (0);
						if (ve) {
							myApp.isTransparentCell && (ctx.globalAlpha = 0.8);
							for (var vj = 0; vj < v_72.length; vj++) {
								this.id === v_72[vj] && (vf = 1)
							}
							;

							if (vf) {
								//myApp.isEnableCursorLine && (ctx.save(), ctx.strokeStyle = this.can_split ? '#0066FF' : '#E3F2FD', ctx.lineWidth = this.can_split ? 12 : 4, ctx.lineCap = 'round', ctx.lineJoin = 'round', ctx.globalAlpha = 0.8, ctx.beginPath(), ctx.moveTo(this.x, this.y), ctx.lineTo(refPositionX, refPositionY), ctx.stroke(), ctx.restore());
								myApp.isEnableAttackRange && (ctx.beginPath(), ctx.strokeStyle = v_8f ? 'white' : 'black', ctx.arc(this.x, this.y, this.size + myApp.attackRangeRadius, 0, 2 * Math.PI, 0), ctx.stroke(), ctx.closePath());
								myApp.isEnableCustomSkin && (_skin = myApp.getSkinImage(nodeList[0][5]));
							}
						}
						;
						v_8c ? (ctx.fillStyle = '#FFFFFF', ctx.strokeStyle = '#AAAAAA') : (ctx.fillStyle = this.color, ctx.strokeStyle = this.color);
						vb && this.f && (ctx.fillStyle = '#6e6e6e', ctx.globalAlpha = 0.8, ctx.lineWidth = 10, ctx.strokeStyle = '#FFFFFF');
						if (vb || vd) {
							ctx.beginPath(), ctx.arc(this.x, this.y, this.size + 5, 0, 2 * Math.PI, 0), myApp.isEnableSplitInd && ve && !vf && (this.name || 38 < this.size) && extraCellsPosSizes.push({
								x: this.x,
								y: this.y,
								size: this.size
							})
						} else {
							this.go_da();
							ctx.beginPath();
							var label = this.go_B();
							ctx.moveTo(this.a[0]['x'], this.a[0]['y']);
							for (ve = 1; ve <= label; ++ve) {
								vj = ve % label, ctx.lineTo(this.a[vj]['x'], this.a[vj]['y'])
							}
						}
						;
						ctx.closePath();

						// ve = this.name['toLowerCase']();
						// vj = this.img ? 'http://upload.happyfor.me/getimg.php?id=' + this.img + '&_t=' + Math.random() : 'skins/' + ve + '.png';
						// _skin || this.j || !v_8a && !myApp.isEnableOtherSkinSupport || ':teams' == v_94 ? label = null : (label = this.V, null == label ? label = null : ':' == label[0] ? (v_bf.hasOwnProperty(label) || (v_bf[label] = new Image, v_bf[label]['src'] = label.slice(1)), label = 0 != v_bf[label]['width'] && v_bf[label]['complete'] ? v_bf[label] : null) : label = null, label || (-1 != v_bd.indexOf(ve) && v_8a || this.img ? ($['hasOwnProperty'](ve) || ($[ve] = new Image, $[ve]['src'] = vj), label = 0 != $[ve]['width'] && $[ve]['complete'] ? $[ve] : null) : label = null));
						// vj = label;
						// vd || !vb || !this.f || ctx.stroke();
						//ctx.stroke();
						ctx.fill();

						var __skin__;
						/*
						var team = '';
						if (UseOgarMapImpl) {
							var _va0 = this.name + this.color;
								__skin__ = _va0 ? gPlayerInfoDict[_va0] : null; //OgarMap
							team = g
						} else {
							//_va0 = va;
							__skin__ = _va ? _va.url : null; //ZT
						}
*/

						var sig = this.name + this.color;
						var info = gPlayerInfoDict[sig];
						var team = '';
						if(info){
							__skin__ = info.skinUrl;
							team = info.team;
						}

						if(UseSkinSepration && !checkIsTeammate(team)){
							__skin__ = null;
						}

						if(myApp.isEnableCustomSkin &&
							//(label = null, _skin = 0, _va && (_skin = _va.url),
							(label = null, _skin = 0, __skin__ && (_skin = __skin__), //gPlayerInfoDict[_va0]),
							_skin && (v_bc.hasOwnProperty(_skin) ||
							(_va = new Image, _va.src = _skin, v_bc[_skin] = _va),
							v_bc[_skin]['width'] && v_bc[_skin]['complete'] && (label = v_bc[_skin])), vj = label, null != vj)) {
							var vk = Math.min(vj.width, vj.height),
								vl = (vj.width - vk) / 2,
								vm = (vj.height - vk) / 2,
								v_53 = this.size + 5
						};
						null != vj && (ctx.save(), ctx.clip(), ctx.drawImage(vj, vl, vm, vk, vk, this.x - v_53, this.y - v_53, 2 * v_53, 2 * v_53), ctx.restore());
						vb || ((v_8c || 15 < this.size) && !vd && (ctx.strokeStyle = '#000000', ctx.globalAlpha *= 0.1, ctx.stroke()), ctx.globalAlpha = 1);
						label = -1 != selfOwnedCells.indexOf(this);
						vd = ~~this.y;
						vb = this.f || 315 < this.size || 18 < this.size * v_88;
						if(!(vf && myApp.isHideSelfName || myApp.isAutoHideName && !vb) && 0 != this.id && (v_8b || label) && this.name && this.k && (null == vj || -1 == v_be.indexOf(ve))) {
							vj = this.k;
							vj.lb_u_setText(this.name);
							vj.G(this.go_i() / 0.9);
							ve = 0 >= this.id ? 1 : Math.ceil(10 * v_88) / 10;
							vj.U(ve);
							var vj = vj.lb_F_render(),
								vn = ~~(vj.width / ve),
								vo = ~~(vj.height / ve);
							ctx.drawImage(vj, ~~this.x - ~~(vn / 2), vd - ~~(vo / 2), vn, vo);
							vd += vj.height / 2 / ve + 4
						};

						var mass = (this.size * this.size / 100);

						//this.debug_val = this.id;

						var textCol = this.getTextColor();
						myApp.isAutoHideMass && !vb || !myApp.isEnableShowAllMass ||
						0 < this.id && v_90 && 38 < this.size &&
						(null == this.I && (this.I = new DrawingLabel(this.go_i() / 2, textCol, 1, '#000000')),
							label = this.I, label.G(this.go_i() / 0.8),
							label.lb_u_setText(~~(this.size * this.size / 100)),
						//label.lb_u_setText(~~this.debug_val),	//debug
							ve = Math.ceil(10 * v_88) / 10, label.U(ve), vj = label.lb_F_render(), vn = ~~(vj.width / ve), vo = ~~(vj.height / ve),
							ctx.drawImage(vj, ~~this.x - ~~(vn / 2), vd - ~~(vo / 2.7), vn, vo));
						ctx.restore()
					}
				}
			}
		};

		//DrawingLabel
		function DrawingLabel(va, col, vd, ve) {
			va && (this.lb_q_size = va);	//size?
			col && (this.lb_M_fillColor = col);	//fillColor
			this.O = !!vd;
			ve && (this.lb_r_strokeColor = ve)	//strokeColor
		}
		DrawingLabel.prototype = {
			lb_w_text: '',
			lb_M_fillColor: '#000000',
			O: 0,
			lb_r_strokeColor: '#000000',
			lb_q_size: 16,
			l: null,
			N: null,
			h: 0,
			v: 1,
			G: function(va) {
				5 < Math.abs(va - this.lb_q_size) && this.lb_q_size != va && (this.lb_q_size = va, this.h = 1)
			},
			U: function(va) {
				this.v != va && (this.v = va, this.h = 1)
			},
			setStrokeColor: function(va) {
				this.lb_r_strokeColor != va && (this.lb_r_strokeColor = va, this.h = 1)
			},
			lb_u_setText: function(va) {
				//setText?
				var vb;
				!isNaN(va) && !isNaN(this.lb_w_text) && 0 != this.lb_w_text && 0 != va && this.lb_w_text != va && 0.012 > Math.abs((va - this.lb_w_text) / this.lb_w_text) && (vb = this.lb_w_text, this.lb_w_text = va);
				va != this.lb_w_text && (this.lb_w_text = va, this.h = 1);
				vb && (this.lb_w_text = vb)
			},
			lb_F_render: function() {
				null == this.l && (this.l = document.createElement('canvas'), this.N = this.l['getContext']('2d'));
				if(this.h) {
					this.h = 0;
					var canvas = this.l,
						ctx = this.N,
						text = this.lb_w_text,
						ve = this.v,
						size = this.lb_q_size,
					//vi = 'bold ' + vf + 'px Ubuntu';
					vi = 'bold ' + size + 'px Ubuntu';
					// vi = 'bolder ' + (size * 0.8) + 'px Ubuntu';
					ctx.font = vi;
					var vj = ~~(0.2 * size);
					//var vj = ~~(0.2 * size);
					canvas.width = (ctx.measureText(text)['width'] + 6) * ve;
					canvas.height = (size + vj) * ve;
					ctx.font = vi;
					ctx.scale(ve, ve);
					ctx.globalAlpha = 1;
					ctx.fillStyle = this.lb_M_fillColor;

					//ctx.fillStyle = '#FF00FF';
					myApp.isShowTextStrokeLine && (ctx.lineWidth = Math.max(size * 0.12, 5), ctx.strokeStyle = this.lb_r_strokeColor, this.O && ctx.strokeText(text, 3, size - vj / 2));
					ctx.fillText(text, 3, size - vj / 2);	//draw label
				};
				return this.l
			}
		};

		function VWWWW(va, vb, vd, ve, vf) {
			this.P = va;
			this.x = vb;
			this.y = vd;
			this.g = ve;
			this.b = vf
		}
		VWWWW.prototype = {
			P: null,
			x: 0,
			y: 0,
			g: 0,
			b: 0
		};


		function vf() {
			v_96 = 1;
			vj();
			setInterval(vj, 18E4);
			v_6b = v_6a = document.getElementById('canvas');
			document.getElementById('overlays2')['onmousemove'] = function(v_4f) {
				clientMouseX = v_4f.clientX;
				clientMouseY = v_4f.clientY;
				onClientMousePositionChanged()
				//trace("mx:" + clientMouseX);
				//trace("my:" + clientMouseY);
			};
			ctx = v_6b.getContext('2d');
			document.body['onmousewheel'] = vg;

			var keySpace = 32;
			var keyQ = 81;
			var keyW = 87;

			var holdSpace = 0;
			var holdQ = 0;
			var holdW = 0;

			_win.onkeydown = function(e) {
				var key = e.keyCode;

				//keySpace != e.keyCode || chatRoom.isFocus() || v_4f || (_MOVE(), v_58(17), v_4f = 1);
				if(key == keySpace && !chatRoom.isFocus() && !holdSpace) {
					_MOVE();
					SendPlayerAction(17);
					holdSpace = 1;
					if(selfOwnedCells.length < 16) {
						gSplitTimingTick = gSplitTimingDuration;
					}
				}

				//keyQ != e.keyCode || vd || (v_58(18), vd = 1);
				if(key == keyQ && !holdQ) {
					SendPlayerAction(18);
					holdQ = 1;
				}

				//keyW != e.keyCode || chatRoom.isFocus() || v_50 || (_MOVE(), v_58(21), v_50 = 1);

				if(key == keyW && !chatRoom.isFocus() && !holdW) {
					//MOVING = true;
					if(MOVING) {
						_MOVE();
						SendPlayerAction(21);
					} else {
						//静止中の餌だし
						MOVING = true;
						_MOVE(true);
						SendPlayerAction(21);
						//  setTimeout(function () {
						//  	SendPlayerAction(21);
						//  	MOVING = false;
						//  }, 1);
					}

					holdW = 1;
					//trace("w");

				}


				/*
							if (key == keyW && !chatRoom.isFocus() && !holdW) {
								_MOVE();
								SendPlayerAction(21);
								holdW = 1;
							}
				*/
				isJoinedGame && !$('#overlays')['is'](':visible') || spectateMode ? 27 == e.keyCode && (e.preventDefault(), vi(300)) : 27 == e.keyCode && (e.preventDefault(), $('.btn-play')['trigger']('click'))
			};
			_win.onkeyup = function(e) {
				var key = e.keyCode;

				//keySpace == e.keyCode && (v_4f = 0);
				if(key == keySpace) holdSpace = 0;

				//keyQ == e.keyCode && (v_50 = 0);
				if(key == keyQ) holdQ = 0;

				//keyW == e.keyCode && vd && (v_58(19), vd = 0)
				if(key == keyW && holdW) {
					SendPlayerAction(19);
					holdW = 0;
				}

			};
			_win.onblur = function() {
				SendPlayerAction(19);
				holdW = holdQ = holdSpace = 0
			};
			_win.onresize = windowOnResize;
			_win.requestAnimationFrame(animationFrameFuncRoot);

			//setInterval(_MOVE, 42);

			function moveProc() {
				_MOVE();
				setTimeout(moveProc, 42);
			}
			setTimeout(moveProc, 42);

			v_89 && _jquery('#region')['val'](v_89);
			vr();
			vk(_jquery('#region')['val']());
			0 == v_a4 && v_89 && vl();
			vi(0);
			windowOnResize();
			_win.location['hash'] && 6 <= _win.location['hash']['length'] && v_62(_win.location['hash'])
		}

		function vg(v_4f) {
			myApp.isEnableZoom && (v_a1 *= Math.pow(myApp.getZoomSpeed(), v_4f.wheelDelta / -120 || v_4f.detail || 0), myApp.getZoomLimit() > v_a1 && (v_a1 = myApp.getZoomLimit()), v_a1 > 1 / v_88 && (v_a1 = 1 / v_88))
		}

		function CreatePlayerEntryData(_action) {
			var id = null;
			0 < v_68.playerCells()['length'] && (id = v_68.playerCells()[0], id = id.name + id.color);
			var vd = _jquery('#skin_url')['val']();
			if(-1 != vd.indexOf('!!')) {
				try {
					atob(vd.slice(2))
				} catch(ve) { }
			};
			return {
				displayName: _jquery('#nick')['val'](),
				action: _action,
				socketRoom: myApp.getRoom(),
				identifier: id,
				url: myApp.getCustomSkinUrl(),
				nick: _jquery('#nick')['val'](),
				team: _jquery('#team_name')['val'](),
				token: myApp.getCurrentPartyCode()
			}
		}

		function EnterPlayer() {
			if(!announcementSent) {
				if(0 < v_68.playerCells()['length']) {
					announcementSent = 1;

					if(!UseOgarMapImpl) {
						var data = CreatePlayerEntryData('join');
						playerDetailsByIdentifier[data.identifier] = data;
						playerDetailsByNick[data.nick] = data;
						conn.emit('playerEntered', data);
					} else {
						var cell = v_68.playerCells()[0];
						gPlayerSignature = cell.name + cell.color;  //cell.id + cell.name;
						skinProvider.sendSkinInfo();
						skinProvider.requestBroadcastSkins();
					}
				} else {
					setTimeout(EnterPlayer, 100)
				}
			}
		}

		function onClientMousePositionChanged() {
			//フィールド上でのカーソル座標
			refPositionX = (clientMouseX - _screenCenterX / 2) / v_88 + v_70;
			refPositionY = (clientMouseY - _screenCenterY / 2) / v_88 + v_71;
			/*
		if (myApp.isStopMovement) {
			refPositionX = stopPositionX;
			refPositionY = stopPositionY;

			//trace("refPositionX:" + refPositionX);

		} else {

		}
	*/
			//trace("LR:" + fieldLeft + "," + fieldRight);
			//trace("refPositionX:" + refPositionX);
		}

		function vj() {
			null == v_b2 && (v_b2 = {}, _jquery('#region')['children']()['each'](function() {
				var v_4f = _jquery(this),
					va = v_4f.val();
				va && (v_b2[va] = v_4f.text())
			}));

			//http://m.gar.io/infoから情報取得
			//vb.get('http://m.agar.io/info', function(v_4f) {
			//	var va = {},
			//		vd;
			//	for(vd in v_4f.regions) {
			//		var ve = vd.split(':')[0];
			//		va[ve] = va[ve] || 0;
			//		va[ve] += v_4f.regions[vd]['numPlayers']
			//	};
			//	for(vd in va) {
			//		vb('#region option[value="' + vd + '"]')['text'](v_b2[vd] + ' (' + va[vd] + ' players)')
			//	}
			//}, 'json')
		}

		function vn() {
			_jquery('#overlays')['hide']();
			_jquery('#stats')['hide']();
			v_c6 = v_a3 = 0;
			vr()
		}

		function vk(v_4f) {
			'gathering' == _jquery('#region')['val']() ? connect(PRIVATE_SERVER_IP, '') : v_4f && v_4f != v_89 && (_jquery('#region')['val']() != v_4f && _jquery('#region')['val'](v_4f), v_89 = _win.localStorage['location'] = v_4f, _jquery('.region-message')['hide'](), _jquery('.region-message.' + v_4f)['show'](), _jquery('.btn-needs-server')['prop']('disabled', 0), v_96 && vl())
		}

		function vi(v_4f) {
			v_a3 || v_c6 || (game_playername_sending = null, 1E3 > v_4f && (v_a2 = 1), v_a3 = 1, _jquery('#mainPanel')['show'](), _jquery('#overlays')['show']())
		}

		function vz(v_4f) {
			_jquery('#helloContainer')['attr']('data-gamemode', v_4f);
			v_94 = v_4f;
			_jquery('#gamemode')['val'](v_4f)
		}

		function vr() {
			_jquery('#region')['val']() ? _win.localStorage['location'] = _jquery('#region')['val']() : _win.localStorage['location'] && _jquery('#region')['val'](_win.localStorage['location']);
			_jquery('#region')['val']() ? _jquery('#locationKnown')['append'](_jquery('#region')) : _jquery('#locationUnknown')['append'](_jquery('#region'))
		}

		function vm(v_4f) {
			return _win.i18n[v_4f] || _win.i18n_dict['en'][v_4f] || v_4f
		}

		function vp() {
			var v_4f = ++v_a4;
			console.log('Find ' + v_89 + v_94);
			_jquery.ajax('http://m.agar.io/findServer', {
				error: function() {
					setTimeout(vp, 1E3)
				},
				success: function(va) {
					'' != v_a6 && va.ip != v_a6 ? vp() : v_4f == v_a4 && (va.alert && alert(va.alert), connectToGameServer('ws://' + va.ip, va.token))
				},
				dataType: 'json',
				method: 'POST',
				cache: 0,
				crossDomain: 1,
				data: (v_89 + v_94 || '?') + '\n154669603'
			})
		}

		function vl() {
			v_96 && v_89 && (_jquery('#connecting')['show'](), vp())
		}

		function connectToGameServer(v_4f, va) {
			currentIP = v_4f;
			if(webSocket) {
				webSocket.onopen = null;
				webSocket.onmessage = null;
				webSocket.onclose = null;
				try {
					webSocket.close()
				} catch(vb) { };
				webSocket = null
			};
			v_a5.ip && (v_4f = 'ws://' + v_a5.ip);
			if(null != v_b3) {
				var vd = v_b3;
				v_b3 = function() {
					vd(va)
				}
			};
			/*
			if(v_69) {
				var ve = v_4f.split(':');
				v_4f = ve[0] + 's://ip-' + ve[1]['replace'](/\./g, '-')['replace'](/\//g, '') + '.tech.agar.io:' + (+ve[2] + 2E3)
			};
			*/
			v_72 = [];
			selfOwnedCells = [];
			v_74 = {};
			gameObjects = [];
			v_76 = [];
			leaderBoardList = [];
			v_b9 = v_95 = null;
			highest_score = 0;
			v_9f = 0;
			console.log('connecting to game server,' + v_4f);
			webSocket = new WebSocket(v_4f);
			window.webSocket = webSocket;
			webSocket.binaryType = 'arraybuffer';
			webSocket.onopen = function() {

				//gLocalPlayerIdPerConnection = Math.floor(Math.random() * 65535);
				//trace("local_id:" + gLocalPlayerIdPerConnection);
				var msg;
				console.log('socket open');
				msg = CreateDataView(5);
				msg.setUint8(0, 254);
				msg.setUint32(1, 5, 1);
				SendDataFrame(msg);
				msg = CreateDataView(5);
				msg.setUint8(0, 255);
				msg.setUint32(1, 154669603, 1);
				SendDataFrame(msg);


				//UserToken周り,プラベ鯖ではUserTokenを扱っていないためエラー？
				//.lengthが定義されていないというエラーが出るのを回避
				//v_4f = CreateDataView(1 + va.length);
				//v_4f.setUint8(0, 80);
				//for (var vb = 0; vb < va.length; ++vb) {
				//	v_4f.setUint8(vb + 1, va.charCodeAt(vb))
				//};
				//SendDataFrame(v_4f);

				//v_59();
				//4 < va.length && 6 >= va.length ? v_63('/#' + va) : v_63('/');
				//if (void (0) !== window.userToken) {
				//	for (var vb = [8, 1, 18, userToken.length + 25, 1, 8, 10, 82, userToken.length + 20, 1, 10, 13, 8, 5, 18, 5, 49, 46, 52, 46, 57, 24, 0, 32, 0, 16, 2, 26, userToken.length, 1], vd = 0; vd <= userToken.length - 1; vd++) {
				//		vb.push(userToken.charCodeAt(vd))
				//	};
				//	v_4f = new DataView(new ArrayBuffer(1 + vb.length));
				//	v_4f.setUint8(0, 102);
				//	for (vd = 0; vd < vb.length; vd++) {
				//		v_4f.setUint8(1 + vd, vb[vd])
				//	};
				//	webSocket.send(v_4f.buffer)
				//} else {
				//	setTimeout(function () {
				//		for (var v_4f = [8, 1, 18, userToken.length + 25, 1, 8, 10, 82, userToken.length + 20, 1, 10, 13, 8, 5, 18, 5, 49, 46, 52, 46, 57, 24, 0, 32, 0, 16, 2, 26, userToken.length, 1], va = 0; va <= userToken.length - 1; va++) {
				//			v_4f.push(userToken.charCodeAt(va))
				//		};
				//		var vb = new DataView(new ArrayBuffer(1 + v_4f.length));
				//		vb.setUint8(0, 102);
				//		for (va = 0; va < v_4f.length; va++) {
				//			vb.setUint8(1 + va, v_4f[va])
				//		};
				//		webSocket.send(vb.buffer)
				//	}, 5E3)
				//}
			};
			webSocket.onmessage = onMessage;
			webSocket.onclose = onClose;
			webSocket.onerror = function() {
				console.log('socket error')
			}
		}

		function CreateDataView(n) {
			return new DataView(new ArrayBuffer(n))
		}

		function SendDataFrame(msg) {
			frameSendQueueCount++;
			webSocket.send(msg.buffer)
			//ws.send(msg.buffer);
		}

		function onClose() {
			v_9f && (v_b4 = 500);
			console.log('socket close');
			setTimeout(vl, v_b4);
			v_b4 *= 2
		}

		function onMessage(v_4f) {
			var view = new DataView(v_4f.data);
			decodeMessage(view)
			conn2.decodeMessage(view);
		}

		function decodeMessage(msg) {
			function getString() {
				for(var vd = ''; ;) {
					var v_51 = msg.getUint16(vb, 1);
					vb += 2;
					if(0 == v_51) {
						break
					};
					vd += String.fromCharCode(v_51)
				};
				return vd
			}
			v_ab++;
			var vb = 0;
			240 == msg.getUint8(vb) && (vb += 5);
			switch(msg.getUint8(vb++)) {
				case 16:
					updateBlobInfo(msg, vb);
					break;
				case 17:
					stopPositionX = msg.getFloat32(vb, 1);
					vb += 4;
					stopPositionY = msg.getFloat32(vb, 1);
					var vb = vb + 4,
						num = msg.getFloat32(vb, 1);
					v_aa = num;
					myApp.isEnableLockZoom || (v_93 = num);
					vb += 4;
					break;
				case 18:
					v_72 = [];
					selfOwnedCells = [];
					v_74 = {};
					gameObjects = [];
					break;
				case 20:
					selfOwnedCells = [];
					v_72 = [];
					break;
				case 21:
					v_98 = msg.getInt16(vb, 1);
					vb += 2;
					v_99 = msg.getInt16(vb, 1);
					vb += 2;
					v_97 || (v_97 = 1, v_9a = v_98, v_9b = v_99);
					break;
				case 32:
					v_72.push(msg.getUint32(vb, 1));
					vb += 4;
					break;
				case 49:
					if(null != v_95) {
						break
					};
					num = msg.getUint32(vb, 1);
					vb += 4;
					leaderBoardList = [];
					for(var i = 0; i < num; ++i) {
						var _id = msg.getUint32(vb, 1),
							vb = vb + 4;
						leaderBoardList.push({
							id: _id,
							name: getString()
						})
					};
					break;
				case 50:
					v_95 = [];
					num = msg.getUint32(vb, 1);
					vb += 4;
					for(i = 0; i < num; ++i) {
						v_95.push(msg.getFloat32(vb, 1)), vb += 4
					};
					vq();
					break;
				case 64:
					var num = msg.getFloat64(vb, 1),
						vb = vb + 8,
						i = msg.getFloat64(vb, 1),
						vb = vb + 8,
						_id = msg.getFloat64(vb, 1),
						vb = vb + 8,
						vi = msg.getFloat64(vb, 1),
						vb = vb + 8;
					//v_55(vf - vd, vi - ve) ? (fieldLeft = vd, fieldTop = ve, fieldRight = vf, fieldBottom = vi) : (v_55(vd, v_84) && (0.01 < vf - v_86 || -0.01 > vf - v_86) && (fieldLeft = vd, fieldRight = vd + 14142.135623730952), (0.01 < vd - v_84 || -0.01 > vd - v_84) && v_55(vf, v_86) && (fieldRight = vf, fieldLeft = vf - 14142.135623730952), (0.01 < ve - v_85 || -0.01 > ve - v_85) && v_55(vi, v_87) && (fieldBottom = vi, fieldTop = vi - 14142.135623730952), v_55(ve, v_85) && (0.01 < vi - v_87 || -0.01 > vi - v_87) && (fieldTop = ve, fieldBottom = ve + 14142.135623730952), vd < fieldLeft && (fieldLeft = vd, fieldRight = vd + 14142.135623730952), vf > fieldRight && (fieldRight = vf, fieldLeft = vf - 14142.135623730952), ve < fieldTop && (fieldTop = ve, fieldBottom = ve + 14142.135623730952), vi > fieldBottom && (fieldBottom = vi, fieldTop = vi - 14142.135623730952), v_84 = vd, v_85 = ve, v_87 = vi, v_86 = vf);
					fieldLeft = 0;
					fieldTop = 0;
					fieldRight = 14142.13562373095;
					fieldBottom = 14142.13562373095;
					myApp.afterGameLoaded();
					break;
				case 81:
					var vj = msg.getUint32(vb, 1),
						vb = vb + 4,
						vh = msg.getUint32(vb, 1),
						vb = vb + 4,
						vk = msg.getUint32(vb, 1),
						vb = vb + 4;
					setTimeout(function() {
						v_5e({
							d: vj,
							e: vh,
							c: vk
						})
					}, 1200);
					break;
					// case 128:
					// 	chatRoom.decodeMessage(msg);
					// 	break;
			}
		}

		function updateBlobInfo(data, pos) {
			//blob情報更新？
			function getStringU() {
				for(var vb = ''; ;) {
					var ve = data.getUint16(pos, 1);
					pos += 2;
					if(0 == ve) {
						break
					};
					vb += String.fromCharCode(ve)
				};
				return vb
			}

			function getStringB() {

				for(var vb = ''; ;) {
					var vd = data.getUint8(pos++);
					if(0 == vd) {
						break
					};
					vb += String.fromCharCode(vd)
				};
				return vb
			}
			v_a0 = v_7d = Date.now();
			v_9f || (v_9f = 1, vc());
			v_8d = 0;
			var vf = data.getUint16(pos, 1);
			pos += 2;
			for(var vj = 0; vj < vf; ++vj) {
				var vh = v_74[data.getUint32(pos, 1)],
					v_52 = v_74[data.getUint32(pos + 4, 1)];
				pos += 8;
				vh && v_52 && (v_52.go_R_remove(), v_52.o = v_52.x, v_52.p = v_52.y, v_52.n = v_52.size, v_52.go_C_x = vh.x, v_52.go_C_y = vh.y, v_52.m = v_52.size, v_52.K = v_7d, v_64(vh, v_52))
			};
			for(vj = 0; ;) {
				vf = data.getUint32(pos, 1);
				pos += 4;
				if(0 == vf) {
					break
				};
				++vj;
				var vk, vh = data.getInt32(pos, 1);
				pos += 4;
				v_52 = data.getInt32(pos, 1);
				pos += 4;
				vk = data.getInt16(pos, 1);
				pos += 2;
				var obj = data.getUint8(pos++),
					vl = data.getUint8(pos++),
					vm = data.getUint8(pos++),
					vl = vx(obj << 16 | vl << 8 | vm),
					vm = data.getUint8(pos++),
					v_53 = !!(vm & 1),
					vn = !!(vm & 16),
					vo = null;
				vm & 2 && (pos += 4 + data.getUint32(pos, 1));
				vm & 4 && (vo = getStringB());
				var _name = getStringU(),
					obj = null;
				v_74.hasOwnProperty(vf) ? (obj = v_74[vf], obj.go_J(), obj.o = obj.x, obj.p = obj.y, obj.n = obj.size, obj.color = vl) : (obj = new GameObject(vf, vh, v_52, vk, vl, _name), gameObjects.push(obj), v_74[vf] = obj, obj.ia = vh, obj.ja = v_52);
				/*
				if(obj.size <= obj.prevSize * 0.9){
					next_go_index(obj);
				}
				obj.prevSize = obj.size;
				*/
				obj.f = v_53;
				obj.j = vn;
				obj.go_C_x = vh;
				obj.go_C_y = v_52;
				obj.m = vk;
				obj.K = v_7d;
				obj.T = vm;
				vo && (obj.V = vo);
				_name && obj.setGameObjectName(_name); -1 != v_72.indexOf(vf) && -1 == selfOwnedCells.indexOf(obj) && (selfOwnedCells.push(obj), 1 == selfOwnedCells.length && (v_70 = obj.x, v_71 = obj.y, onWindowLoadedJQ(), document.getElementById('overlays')['style']['display'] = 'none', v_c3 = [], v_c4 = 0, v_c5 = selfOwnedCells[0]['color'], v_c7 = 1, v_c8 = Date.now(), v_cc = v_cb = v_ca = 0))
			};
			vh = data.getUint32(pos, 1);
			pos += 4;
			for(vj = 0; vj < vh; vj++) {
				vf = data.getUint32(pos, 1), pos += 4, obj = v_74[vf], null != obj && obj.go_R_remove()
			};
			v_8d && 0 == selfOwnedCells.length && (myApp.onDead(), 1) && (v_c9 = Date.now(), v_c7 = 0, v_a3 || v_c6 || (v_cd ? (v_67(), v_c6 = 1, _jquery('#overlays')['show'](), _jquery('#stats')['show']()) : vi(1500)))
		}

		function vc() {
			v_a6 = '';
			_jquery('#connecting')['hide']();
			SendGameNickName();
			v_b3 && (v_b3(), v_b3 = null);
			null != v_b5 && clearTimeout(v_b5);
			v_b5 = setTimeout(function() {
				_win.ga && (++v_b6, _win.ga('set', 'dimension2', v_b6))
			}, 1E4)
		}

		function SendAimPoint(px, py) {
			if(!IsDocumentReady()) return;
			var msg = CreateDataView(13);
			msg.setUint8(0, 16);
			msg.setInt32(1, px, 1);
			msg.setInt32(5, py, 1);
			msg.setUint32(9, 0, 1);
			SendDataFrame(msg);
		}

		function SendAimCursor() {
			SendAimPoint(refPositionX, refPositionY);
		}

		function SendAimCenter() {
			SendAimPoint(stopPositionX, stopPositionY);
		}

		function _MOVE(forceAim) {
			try {
				if(forceAim == null) {
					forceAim = false;
				}

				//trace("_MOVE");

				/*
						if (!myApp.isStopMovement && IsDocumentReady()) {
							//trace("Moving");
							//var px = clientMouseX - _screenCenterX / 2;
							//var py = clientMouseY - _screenCenterY / 2;

							//var isNear = px * px + py * py < 64;
							//var diffX = Math.abs(bPositionX - refPositionX);
							//var diffY = Math.abs(bPositionY - refPositionY);
							//var th = 0.01;
							//var xNear = Math.abs(bPositionX - refPositionX) < 0.01;
							//var yNear = Math.abs(bPositionY - refPositionY) < 0.01;


							//&&, ||
							// (64 > px * px + py * py) || (0.01 > Math.abs(bPositionX - refPositionX) && 0.01 > Math.abs(bPositionY - refPositionY))
							//  || (bPositionX = refPositionX, bPositionY = refPositionY,
							//  px = v_22(13), px.setUint8(0, 16), px.setInt32(1, refPositionX, 1), px.setInt32(5, refPositionY, 1), px.setUint32(9, 0, 1), v_23(px))

							//if(isNear){
							//		(diffX < th && diffY < th)){
							//var msg = "";

							//var A = 64 > px * px + py * py;
							//var go_B = (0.01 > Math.abs(bPositionX - refPositionX) && (0.01 > Math.abs(bPositionY - refPositionY)));
							//if(A || go_B){

							bPositionX = refPositionX;
							bPositionY = refPositionY;

							var msg 　= v_22(13);
							msg.setUint8(0, 16);
							msg.setInt32(1, refPositionX, 1);
							msg.setInt32(5, refPositionY, 1);
							msg.setUint32(9, 0, 1);
							v_23(msg);
							//};

						}
				*/

				//SendAimCursor();


				if(MOVING || forceAim) {
					//SendAimPoint(refPositionX, refPositionY);
					SendAimCursor();
				} else {
					//SendAimPoint(stopPositionX, stopPositionY);
					SendAimCenter();
				}



				/*
				//var moving = !myApp.isStopMovement;
				var moving = MOVING;

				var px = refPositionX;
				var py = refPositionY;

				if (!MOVING) {
					px = stopPositionX;
					py = stopPositionY;
				}
		*/
				/*
				bPositionX = px;
				bPositionY = py;
			} else {
				px = bPositionX;
				py = bPositionY;
			}
		*/

				//SendAimPoint(px, py);
				//}

				//trace("moving:" + moving);
				//}
			} catch(e) {
				console.log(e);
			}
		}

		function v_55(v_4f, va) {
			return 0.01 > v_4f - va && -0.01 < v_4f - va
		}

		function SendGameNickName() {
			if(IsDocumentReady() && v_9f && null != game_playername_sending) {
				var msg = CreateDataView(1 + 2 * game_playername_sending.length);
				msg.setUint8(0, 0);
				for(var va = 0; va < game_playername_sending.length; ++va) {
					msg.setUint16(1 + 2 * va, game_playername_sending.charCodeAt(va), 1)
				};
				SendDataFrame(msg);
				game_playername_sending = null
			}
		}

		function IsDocumentReady() {
			return null != webSocket && webSocket.readyState == webSocket.OPEN
		}

		function SendPlayerAction(v_4f) {
			if(IsDocumentReady()) {
				var msg = CreateDataView(1);
				msg.setUint8(0, v_4f);
				SendDataFrame(msg)
			}
		}

		function v_59() {
			if(IsDocumentReady() && null != window.userToken) {
				var msg = CreateDataView(2 + userToken.length);
				msg.setUint8(0, 82);
				msg.setUint8(1, 1);
				for(var vb = 0; vb < window.userToken['length']; ++vb) {
					msg.setUint8(vb + 2, window.userToken['charCodeAt'](vb))
				};
				SendDataFrame(msg)
			}
		}

		function windowOnResize() {
			_screenCenterX = 1 * _win.innerWidth;
			_screenCenterY = 1 * _win.innerHeight;
			v_6a.width = v_6b.width = _screenCenterX;
			v_6a.height = v_6b.height = _screenCenterY;
			var v_4f = _jquery('#helloContainer');
			v_4f.css('transform', 'none');
			var vd = v_4f.height(),
				ve = _win.innerHeight;
			vd > ve / 1.1 ? v_4f.css('transform', 'translate(-50%, -50%) scale(' + ve / vd / 1.1 + ')') : v_4f.css('transform', 'translate(-50%, -50%)');
			updateFrame()
		}

		function v_5b() {
			return 1 * Math.max(_screenCenterY / 1080, _screenCenterX / 1920) * v_a1
		}

		function vt() {
			if(0 != selfOwnedCells.length) {
				if(myApp.isEnableLockZoom) {
					va = v_5b()
				} else {
					for(var va = 0, i = 0; i < selfOwnedCells.length; i++) {
						va += selfOwnedCells[i]['size']
					};
					va = Math.pow(Math.min(64 / va, 1), 0.4) * v_5b()
				};
				v_88 = (9 * v_88 + va) / 10
			}
		}

		function updateFrame() {
			var va, vb = Date.now();
			++v_7c;
			v_7d = vb;
			if(0 < selfOwnedCells.length) {
				vt();
				for(var vd = va = 0, vf = 0; vf < selfOwnedCells.length; vf++) {
					selfOwnedCells[vf].go_J(), va += selfOwnedCells[vf]['x'] / selfOwnedCells.length, vd += selfOwnedCells[vf]['y'] / selfOwnedCells.length
				};
				stopPositionX = va;
				stopPositionY = vd;
				v_93 = v_88;
				myApp.testing ? (v_70 = (testingVal * v_70 + stopPositionX) / (testingVal + 1), v_71 = (testingVal * v_71 + stopPositionY) / (testingVal + 1), console.log(testingVal + 1)) : (v_70 = (v_70 + va) / 2, v_71 = (v_71 + vd) / 2)
			} else {
				v_70 = (29 * v_70 + stopPositionX) / 30, v_71 = (29 * v_71 + stopPositionY) / 30, v_88 = (9 * v_88 + v_93 * v_5b()) / 10
			};

			//セルの分裂可能判定
			var sortedCells = selfOwnedCells.concat();
			sortedCells.sort(function(a, b) {
				return a.id - b.id;
			});
			var num_splitable = Math.min(8, (8 - sortedCells.length / 2) * 2);
			for(var i = 0; i < sortedCells.length; i++) {
				var cell = sortedCells[i];
				cell.can_split = i < num_splitable && (cell.size * cell.size * 0.01 >= 36);
			}

			v_6e = null;
			onClientMousePositionChanged();
			v_9e || ctx.clearRect(0, 0, _screenCenterX, _screenCenterY);
			v_9e ? (ctx.fillStyle = v_8f ? '#111111' : '#F2FBFF', ctx.globalAlpha = 0.05, ctx.fillRect(0, 0, _screenCenterX, _screenCenterY), ctx.globalAlpha = 1) : v_5c();
			gameObjects.sort(function(va, player) {
				return va.size == player.size ? va.id - player.id : va.size - player.size
			});
			ctx.save();
			ctx.translate(_screenCenterX / 2, _screenCenterY / 2);
			ctx.scale(v_88, v_88);
			ctx.translate(-v_70, -v_71);
			va = [fieldLeft, fieldTop, fieldRight, fieldBottom];
			v_60(va, ctx);
			myApp.isEnableMapGrid && v_61(va, ctx);

			for(vf = 0; vf < v_76.length; vf++) {
				v_76[vf].drawGameObject(ctx)
			};
			for(vf = 0; vf < gameObjects.length; vf++) {
				gameObjects[vf].drawGameObject(ctx);	//draw player object
			};
			if(0 < v_af.length) {
				ctx.fillStyle = $('#pelletColor')['minicolors']('value');
				ctx.beginPath();
				for(va = 0; va < v_af.length; va++) {
					vd = v_af[va], ctx.moveTo(vd.x, vd.y), ctx.arc(vd.x, vd.y, vd.size + 5, 0, TWO_PI, 0)
				};
				ctx.fill();
				v_af = []
			};
			if(selfOwnedCells.length && myApp.isEnableSplitInd) {
				ctx.globalAlpha = 0.7;
				vd = ~~Math.min(5 / v_88, 50);
				ctx.lineWidth = vd;
				vf = [];
				for(va = 0; va < selfOwnedCells.length; va++) {
					vf.push({
						x: selfOwnedCells[va]['x'],
						y: selfOwnedCells[va]['y'],
						size: selfOwnedCells[va]['size']
					})
				};
				vf.sort(function(va, v_4f) {
					return va.size - v_4f.size
				});
				for(va = 0; va < extraCellsPosSizes.length; va++) {
					for(var vi = extraCellsPosSizes[va]['size'] * extraCellsPosSizes[va]['size'], vj = 0; vj < vf.length; vj++) {
						var vh = vf[vj]['size'] * vf[vj]['size'],
							vg = Math.sqrt(Math.pow(vf[vj]['x'] - extraCellsPosSizes[va]['x'], 2) + Math.pow(vf[vj]['y'] - extraCellsPosSizes[va]['y'], 2)),
							vk = vf[vj]['size'] + 655,
							vl = extraCellsPosSizes[va]['size'] + 655;
						if(4 >= vf.length && 0.375 * vh * 0.37 > vi && 2 * vk - 10 > vg) {
							extraCellsPosSizes[va]['type'] = 4;
							break
						};
						if(8 >= vf.length && 0.37 * vh > vi && vk > vg) {
							extraCellsPosSizes[va]['type'] = 2;
							break
						};
						if(0.73 * vh > vi && vk > vg) {
							extraCellsPosSizes[va]['type'] = 1;
							break
						};
						if(0.37 * vi > vh && vl > vg) {
							extraCellsPosSizes[va]['type'] = -2;
							break
						};
						if(0.73 * vi > vh && vl > vg) {
							extraCellsPosSizes[va]['type'] = -1;
							break
						}
					}
				};
				for(vf = 0; vf < splitIndicatorColors.length; vf++) {
					ctx.strokeStyle = splitIndicatorColors[vf]['color'];
					ctx.beginPath();
					for(va = 0; va < extraCellsPosSizes.length; va++) {
						extraCellsPosSizes[va]['type'] && extraCellsPosSizes[va]['type'] == splitIndicatorColors[vf]['type'] && (vi = extraCellsPosSizes[va]['size'] + vd + 8 + 2 / v_88, ctx.moveTo(extraCellsPosSizes[va]['x'] + vi, extraCellsPosSizes[va]['y']), ctx.arc(extraCellsPosSizes[va]['x'], extraCellsPosSizes[va]['y'], vi, 0, TWO_PI, 0))
					};
					ctx.stroke()
				}
			};

			//分裂セルマーカー
			//if (true) {
			if(myApp.showSplitOrderMarker) {
				//ctx.save();
				ctx.globalAlpha = 0.6;
				for(var i = 0; i < selfOwnedCells.length; i++) {
					var cell = selfOwnedCells[i];

					ctx.strokeStyle = cell.can_split ? 'rgba(0, 255, 0, 1)' : 'rgba(255, 255, 255, 1)';
					//ctx.strokeStyle = cell.can_split ? 'rgba(0, 96, 255, 1)' : 'rgba(255, 255, 255, 1)';
					//if(cell.can_split){
					//var alpha = Math.max(1.0 - i / 5.0, 0.0);


					//var vd = ~~(Math.min(5 / v_88, 50) * 1.8);
					//var vd = ~~(5 / v_88 * 1.8);
					//ctx.lineWidth = vd;
					//var vi = cell.size + vd + 8 + 2 / v_88;
					var lw = cell.size * 0.16;
					//var lw = cell.size * 0.13;
					//var lw = cell.size * 0.08;
					ctx.lineWidth = lw;
					ctx.beginPath();
					//ctx.moveTo(cell.x + vi, cell.y);
					ctx.arc(cell.x, cell.y, cell.size - lw/2, 0, TWO_PI, 0);
					ctx.stroke();
					//}
				}
				//ctx.restore();
			}


			extraCellsPosSizes = [];

			//v_97 = 1;
			//if (v_97) {
			// カーソルライン
			if(myApp.isEnableCursorLine) {
				//v_9a = (3 * v_9a + v_98) / 4;
				//v_9b = (3 * v_9b + v_99) / 4;
				var px = refPositionX;
				var py = refPositionY;
				//ctx.save();
				ctx.strokeStyle = '#FFAAAA';
				ctx.lineCap = 'round';
				ctx.lineJoin = 'round';
				ctx.globalAlpha = 0.6;
				//trace({x: px, y:py});
				if(false) {
					//if(myApp.showSplitOrderMarker) {
					ctx.lineWidth = 4;
					ctx.strokeStyle = "rgba(255, 255, 255, 0.5)";//	""#CCCCCC";
					ctx.beginPath();
					for(vf = 0; vf < selfOwnedCells.length; vf++) {
						var cell = selfOwnedCells[vf];
						if(!cell.can_split) {
							ctx.moveTo(cell.x, cell.y), ctx.lineTo(px, py);
						}
					}
					ctx.stroke();

					ctx.lineWidth = 4;
					ctx.strokeStyle = "#0044FF";
					ctx.beginPath();
					for(vf = 0; vf < selfOwnedCells.length; vf++) {
						var cell = selfOwnedCells[vf];
						if(cell.can_split) {
							ctx.moveTo(cell.x, cell.y), ctx.lineTo(px, py);
						}
					}
					ctx.stroke();
				} else {
					ctx.lineWidth = 4;
					ctx.strokeStyle = "rgba(255, 255, 255, 0.8)";//	""#CCCCCC";
					ctx.beginPath();
					for(vf = 0; vf < selfOwnedCells.length; vf++) {
						var cell = selfOwnedCells[vf];
						ctx.moveTo(cell.x, cell.y), ctx.lineTo(refPositionX, refPositionY);
					}
					ctx.stroke();
				}
				//ctx.restore()
			}

			if(gSplitTimingTick > 0) {
				gSplitTimingTick--;
			}

			//AIMクロスヘア
			if(myApp.showCursorCrosshair) {
				var px = refPositionX;
				var py = refPositionY;
				ctx.strokeStyle = (gSplitTimingTick > 0) ? '#FF8800' : '#00FF00';
				ctx.lineCap = 'round';
				ctx.lineJoin = 'round';
				ctx.lineWidth = 4;
				ctx.globalAlpha = 0.6;
				ctx.beginPath();
				var R1 = 120;
				var R2 = 200;
				ctx.arc(px, py, R1, 0, TWO_PI, 0);
				ctx.moveTo(px - R2, py); ctx.lineTo(px + R2, py);
				ctx.moveTo(px, py - R2); ctx.lineTo(px, py + R2);
				ctx.stroke();
			}

			ctx.restore();

			//中心線
			if(myApp.showCursorCrosshair) {
				var scx = _screenCenterX / 2;
				var scy = _screenCenterY / 2;

				ctx.save();
				ctx.lineWidth = 1;
				ctx.globalAlpha = 0.2;
				ctx.strokeStyle = "#999999";	//rgba(192, 192, 192, 0.4)";//	""#CCCCCC";
				ctx.beginPath();
				ctx.moveTo(scx, 0); ctx.lineTo(scx, scy * 2);
				ctx.moveTo(0, scy); ctx.lineTo(scx * 2, scy);
				ctx.stroke();
				ctx.restore();
			}



			':teams' == v_94 && v_b9 && v_b9.width && ctx.drawImage(v_b9, _screenCenterX - v_b9.width - 10, 10);
			highest_score = Math.max(highest_score, calcCurrentScore());
			vb = Date.now() - vb;
			vb > 1E3 / 60 ? v_ba -= 0.01 : vb < 1E3 / 65 && (v_ba += 0.01);
			0.4 > v_ba && (v_ba = 0.4);
			1 < v_ba && (v_ba = 1);
			vb = v_7d - v_7e;
			!IsDocumentReady() || v_a3 || v_c6 ? (v_a2 += vb / 2E3, 1 < v_a2 && (v_a2 = 1)) : (v_a2 -= vb / 300, 0 > v_a2 && (v_a2 = 0));
			v_7e = v_7d

			gSelfMass = calcCurrentScore() / 100;
			//v53 = null;
			//delete v53;
		}

		function v_5c() {
			if(myApp.isEnableGridline) {
				ctx.save();
				ctx.strokeStyle = v_8f ? '#AAAAAA' : '#000000';
				ctx.globalAlpha = 0.2 * v_88;
				ctx.beginPath();
				for(var va = _screenCenterX / v_88, vb = _screenCenterY / v_88, vd = (-v_70 + va / 2) % 50; vd < va; vd += 50) {
					ctx.moveTo(vd * v_88 - 0.5, 0), ctx.lineTo(vd * v_88 - 0.5, vb * v_88)
				};
				for(vd = (-v_71 + vb / 2) % 50; vd < vb; vd += 50) {
					ctx.moveTo(0, vd * v_88 - 0.5), ctx.lineTo(va * v_88, vd * v_88 - 0.5)
				};
				ctx.stroke();
				ctx.restore()
			}
		}

		function calcCurrentScore() {
			for(var va = 0, i = 0; i < selfOwnedCells.length; i++) {
				va += selfOwnedCells[i]['m'] * selfOwnedCells[i]['m']
			};
			//console.log(selfOwnedCells.length);
			return va;
		}

		function vq() {
			v_b9 = null;
			if(null != v_95 || 0 != leaderBoardList.length) {
				if(null != v_95 || v_8b) {
					v_b9 = document.createElement('canvas');
					var ctx = v_b9.getContext('2d'),
						vb = 60,
						vb = null == v_95 ? vb + 24 * leaderBoardList.length : vb + 180,
						vd = Math.min(200, 0.3 * _screenCenterX) / 200;
					v_b9.width = 200 * vd;
					v_b9.height = vb * vd;
					ctx.scale(vd, vd);
					ctx.globalAlpha = 0.4;
					ctx.fillStyle = '#000000';
					ctx.fillRect(0, 0, 200, vb);
					ctx.globalAlpha = 1;
					ctx.fillStyle = '#FFFFFF';
					vd = vm('leaderboard');
					ctx.font = '30px Ubuntu';
					ctx.fillText(vd, 100 - ctx.measureText(vd)['width'] / 2, 40);
					if(null == v_95) {
						for(ctx.font = '20px Ubuntu', vb = 0; vb < leaderBoardList.length; ++vb) {
							vd = leaderBoardList[vb]['name'] || vm('unnamed_cell'), v_8b || (vd = vm('unnamed_cell')), -1 != v_72.indexOf(leaderBoardList[vb]['id']) ? (selfOwnedCells[0]['name'] && (vd = selfOwnedCells[0]['name']), ctx.fillStyle = '#FFAAAA') : ctx.fillStyle = '#FFFFFF', vd = vb + 1 + '. ' + vd, ctx.fillText(vd, 100 - ctx.measureText(vd)['width'] / 2, 70 + 24 * vb)
						}
					} else {
						for(vb = vd = 0; vb < v_95.length; ++vb) {
							var ve = vd + v_95[vb] * Math.PI * 2;
							ctx.fillStyle = lb_colors[vb + 1];
							ctx.beginPath();
							ctx.moveTo(100, 140);
							ctx.arc(100, 140, 80, vd, ve, 0);
							ctx.fill();
							vd = ve
						}
					}
				}
			}
		}



		function vx(va) {
			for(va = va.toString(16) ; 6 > va.length;) {
				va = '0' + va
			};
			return '#' + va
		}



		function v_5d(va) {
			for(var vb = va.length, vd, ve; 0 < vb;) {
				ve = Math.floor(Math.random() * vb), vb--, vd = va[vb], va[vb] = va[ve], va[ve] = vd
			}
		}

		function v_5e(v_4f, vd) {
			console.log(v_4f);
			console.log('b: ' + vd);
			var ve = '1' == _jquery('#helloContainer')['attr']('data-has-account-data');
			_jquery('#helloContainer')['attr']('data-has-account-data', '1');
			if(null == vd && _win.localStorage[v_c1]) {
				var vf = JSON.parse(_win.localStorage[v_c1]);
				vf.xp = v_4f.e;
				vf.xpNeeded = v_4f.c;
				vf.level = v_4f.d;
				_win.localStorage[v_c1] = JSON.stringify(vf)
			};
			if(ve) {
				var vi = +_jquery('.agario-exp-bar .progress-bar-text')['first']()['text']()['split']('/')[0],
					ve = +_jquery('.agario-exp-bar .progress-bar-text')['first']()['text']()['split']('/')[1]['split'](' ')[0],
					vf = _jquery('.agario-profile-panel .progress-bar-star')['first']()['text']();
				if(vf != v_4f.d) {
					v_5e({
						e: ve,
						c: ve,
						d: vf
					}, function() {
						_jquery('.agario-profile-panel .progress-bar-star')['text'](v_4f.d);
						_jquery('.agario-exp-bar .progress-bar')['css']('width', '100%');
						_jquery('.progress-bar-star')['addClass']('animated tada')['one']('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() {
							_jquery('.progress-bar-star')['removeClass']('animated tada')
						});
						setTimeout(function() {
							_jquery('.agario-exp-bar .progress-bar-text')['text'](v_4f.c + '/' + v_4f.c + ' XP');
							v_5e({
								e: 0,
								c: v_4f.c,
								d: v_4f.d
							}, function() {
								v_5e(v_4f, vd)
							})
						}, 1E3)
					})
				} else {
					var vj = Date.now(),
						vh = function() {
							var ve;
							ve = (Date.now() - vj) / 1E3;
							ve = 0 > ve ? 0 : 1 < ve ? 1 : ve;
							ve = ve * ve * (3 - 2 * ve);
							_jquery('.agario-exp-bar .progress-bar-text')['text'](~~(vi + (v_4f.e - vi) * ve) + '/' + v_4f.c + ' XP');
							_jquery('.agario-exp-bar .progress-bar')['css']('width', (88 * (vi + (v_4f.e - vi) * ve) / v_4f.c)['toFixed'](2) + '%');
							1 > ve ? _win.requestAnimationFrame(vh) : vd && vd()
						};
					_win.requestAnimationFrame(vh)
				}
			} else {
				_jquery('.agario-profile-panel .progress-bar-star')['text'](v_4f.d), _jquery('.agario-exp-bar .progress-bar-text')['text'](v_4f.e + '/' + v_4f.c + ' XP'), _jquery('.agario-exp-bar .progress-bar')['css']('width', (88 * v_4f.e / v_4f.c)['toFixed'](2) + '%'), vd && vd()
			}
		}

		function v_5f(v_4f) {
			'connected' == v_4f.status && (window.userToken = v_4f.authResponse['accessToken'], v_59(), _win.FB['api']('/me/picture?width=180&height=180', function(v_4f) {
				_win.localStorage['fbPictureCache'] = v_4f.data['url'];
				_jquery('.agario-profile-picture')['attr']('src', v_4f.data['url'])
			}), _jquery('#helloContainer')['attr']('data-logged-in', '1'))
		}

		function v_60(va, vb) {
			vb.save();
			vb.beginPath();
			vb.strokeStyle = $('#borderColor')['minicolors']('value');
			var vd = vb.lineWidth = 40;
			vb.strokeRect(va[0] - vd / 2, va[1] - vd / 2, va[2] - va[0] + vd, va[3] - va[1] + vd);
			vb.restore()
		}

		function v_61(va, vb) {
			var vd = Math.round(va[0]) + 40,
				ve = Math.round(va[1]) + 40,
				vf = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'['split'](''),
				vi = (Math.round(va[2]) - 40 - vd) / 5,
				vj = (Math.round(va[3]) - 40 - ve) / 5;
			vb.save();
			vb.beginPath();
			vb.lineWidth = 20;
			vb.textAlign = 'center';
			vb.textBaseline = 'middle';
			vb.font = 0.6 * vi + 'px Ubuntu';
			vb.fillStyle = '#1A1A1A';
			for(var vh = 0; 5 > vh; vh++) {
				for(var vg = 0; 5 > vg; vg++) {
					vb.fillText(vf[vh] + (vg + 1), vd + vi * vg + vi / 2, ve + vj * vh + vj / 2)
				}
			};
			vb.lineWidth = 100;
			vb.strokeStyle = '#1A1A1A';
			for(vh = 0; 5 > vh; vh++) {
				for(vg = 0; 5 > vg; vg++) {
					vb.strokeRect(vd + vi * vg, ve + vj * vh, vi, vj)
				}
			};
			vb.stroke();
			vb.restore()
		}

		function v_62(v_4f) {
			vz(':party');
			_jquery('#helloContainer')['attr']('data-party-state', '4');
			v_4f = decodeURIComponent(v_4f)['replace'](/.*#/gim, '');
			v_63('#' + _win.encodeURIComponent(v_4f));
			_jquery.ajax('http://m.agar.io/getToken', {
				error: function() {
					_jquery('#helloContainer')['attr']('data-party-state', '6');
					_jquery('#connect_error_div')['show']()
				},
				success: function(vd) {
					vd = vd.split('\n');
					_jquery('.partyToken')['val'](_win.encodeURIComponent(v_4f));
					_jquery('#helloContainer')['attr']('data-party-state', '5');
					vz(':party');
					connectToGameServer('ws://' + vd[0], v_4f);
					isJoinedGame = 0
				},
				dataType: 'text',
				method: 'POST',
				cache: 0,
				crossDomain: 1,
				data: v_4f
			});
			$('.btn-spectate')['prop']('disabled', 0)
		}

		function v_63(vb) {
			_win.history && _win.history['replaceState'] && _win.history['replaceState']({}, _win.document['title'], vb)
		}

		function v_64(va, vb) {
			var vd = -1 != v_72.indexOf(va.id),
				ve = -1 != v_72.indexOf(vb.id),
				vf = 30 > vb.size;
			vd && vf && ++v_c4;
			vf || !vd || ve || ++v_cb
		}

		function v_65(va) {
			va = ~~va;
			var vb = (va % 60).toString();
			va = (~~(va / 60)).toString();
			2 > vb.length && (vb = '0' + vb);
			return va + ':' + vb
		}

		function v_66() {
			if(null == leaderBoardList) {
				return 0
			};
			for(var va = 0; va < leaderBoardList.length; ++va) {
				if(-1 != v_72.indexOf(leaderBoardList[va]['id'])) {
					return va + 1
				}
			};
			return 0
		}

		function v_67() {
			_jquery('.stats-food-eaten')['text'](v_c4);
			_jquery('.stats-time-alive')['text'](v_65((v_c9 - v_c8) / 1E3));
			_jquery('.stats-leaderboard-time')['text'](v_65(v_ca));
			_jquery('.stats-highest-mass')['text'](~~(highest_score / 100));
			_jquery('.stats-cells-eaten')['text'](v_cb);
			_jquery('.stats-top-position')['text'](0 == v_cc ? ':(' : v_cc);
			var va = document.getElementById('statsGraph');
			if(va) {
				var vd = va.getContext('2d'),
					ve = va.width,
					va = va.height;
				vd.clearRect(0, 0, ve, va);
				if(2 < v_c3.length) {
					for(var vf = 200, vi = 0; vi < v_c3.length; vi++) {
						vf = Math.max(v_c3[vi], vf)
					};
					vd.lineWidth = 3;
					vd.lineCap = 'round';
					vd.lineJoin = 'round';
					vd.strokeStyle = v_c5;
					vd.fillStyle = v_c5;
					vd.beginPath();
					vd.moveTo(0, va - v_c3[0] / vf * (va - 10) + 10);
					for(vi = 1; vi < v_c3.length; vi += Math.max(~~(v_c3.length / ve), 1)) {
						for(var vj = vi / (v_c3.length - 1) * ve, vh = [], vg = -20; 20 >= vg; ++vg) {
							0 > vi + vg || vi + vg >= v_c3.length || vh.push(v_c3[vi + vg])
						};
						vh = vh.reduce(function(va, vb) {
							return va + vb
						}) / vh.length / vf;
						vd.lineTo(vj, va - vh * (va - 10) + 10)
					};
					vd.stroke();
					vd.globalAlpha = 0.5;
					vd.lineTo(ve, va);
					vd.lineTo(0, va);
					vd.fill();
					vd.globalAlpha = 1
				}
			}
		}
		var v_68 = {
			context: function() {
				return g_context
			},
			playerCellIds: function() {
				return g_playerCellIds
			},
			playerCells: function() {
				return selfOwnedCells
			},
			cellsById: function() {
				return g_cellsById
			},
			cells: function() {
				return g_cells
			}
		};

		if(!UseOgarMapImpl) {
			//他のプレイヤー情報を受け取るハンドラ
			socket.on('playerUpdated', function(data) {
				//actionがupdateでない場合再送信
				('join' == data.action || 'spectate' == data.action) && 0 < v_68.playerCells()['length'] && conn.emit('playerUpdated', CreatePlayerEntryData('update'));

				//辞書にプレイヤー情報を格納
				data.identifier && (playerDetailsByIdentifier[data.identifier] = data, playerDetailsByNick[data.nick] = data)
			});
		} else {

		}

		//移動？
		_win.moveTo = function(va, vb) {
			//va && vb && (myApp.isStopMovement = 1)
		};

		_win.setPosition = function(va, vb) {
			if(IsDocumentReady()) {
				var vd = CreateDataView(13);
				vd.setUint8(0, 16);
				vd.setInt32(1, va, 1);
				vd.setInt32(5, vb, 1);
				vd.setUint32(9, 0, 1);
				SendDataFrame(vd)
			}
		};
		window.handleQuickW = function() {
			if(myApp.autoW) {
				var va = CreateDataView(1);
				va.setUint8(0, 21);
				SendDataFrame(va);
				setTimeout(handleQuickW, 142)
			}
		};
		if(!_win.agarioNoInit) {
			/*
			var v_69 = 'https:' == _win.location['protocol'];
			if(v_69 && -1 == _win.location['search']['indexOf']('fb')) {
				_win.location['href'] = 'http://agar.io/'
			} else
				*/
			{
				var v_6a, ctx, v_6b, _screenCenterX, _screenCenterY, v_6e = null,
					webSocket = null,
					v_70 = 0,
					v_71 = 0,
					v_72 = [],
					selfOwnedCells = [],
					v_74 = {},
					gameObjects = [],
					v_76 = [],
					leaderBoardList = [],
					clientMouseX = 0,
					clientMouseY = 0,
					refPositionX = -1,
					refPositionY = -1,
					v_7c = 0,
					v_7d = 0,
					v_7e = 0,
					game_playername_sending = null,
					fieldLeft = -7071.067811865476,
					fieldTop = -7071.06781186547,
					fieldRight = 7071.067811865476,
					fieldBottom = 7071.067811865476,
					//fieldLeft = 0,
					//fieldTop = 0,
					//fieldRight = 14142.13562373095,
					//fieldBottom = 14142.13562373095,
					v_84 = 0,
					v_85 = 0,
					v_86 = 0,
					v_87 = 0,
					v_88 = 1,
					v_89 = null,
					v_8a = 1,
					v_8b = 1,
					v_8c = 0,
					v_8d = 0,
					highest_score = 0,
					v_8f = 1,
					v_90 = 0,
					stopPositionX = v_70 = ~~((fieldLeft + fieldRight) / 2),
					stopPositionY = v_71 = ~~((fieldTop + fieldBottom) / 2),
					v_93 = 1,
					v_94 = '',
					v_95 = null,
					v_96 = 0,
					v_97 = 0,
					v_98 = 0,
					v_99 = 0,
					v_9a = 0,
					v_9b = 0,
					v_9c = 0,
					lb_colors = ['#333333', '#FF3333', '#33FF33', '#3333FF'],
					v_9e = 0,
					v_9f = 0,
					v_a0 = 0,
					v_a1 = 1,
					v_a2 = 1,
					v_a3 = 0,
					v_a4 = 0,
					v_a5 = {},
					v_a6 = '',
					v_a7 = 0,
					extraCellsPosSizes = [],
					TWO_PI = 2 * Math.PI,
					v_aa = 0,
					v_ab = 0,
					frameSendQueueCount = 0,
					v_ad = 0,
					v_ae = 0,
					v_af = [],
					splitIndicatorColors = [{
						type: 1,
						color: '#d3d3d3'
					}, {
						type: 2,
						color: '#76FF03'
					}, {
						type: 4,
						color: '#2196F3'
					}, {
						type: -1,
						color: '#FF9800'
					}, {
						type: -2,
						color: '#FD0000'
					}, {
						type: -4,
						color: 'white'
					}];

				setInterval(function() {
					v_ad = v_ab;
					v_ab = 0;
					v_ae = frameSendQueueCount;
					frameSendQueueCount = 0
				}, 1E3);
				(function() {
					var vb = _win.location['search'];
					'?' == vb.charAt(0) && (vb = vb.slice(1));
					for(var vb = vb.split('&'), vd = 0; vd < vb.length; vd++) {
						var ve = vb[vd]['split']('=');
						v_a5[ve[0]] = ve[1]
					}
				})();
				var v_b1 = document.createElement('canvas');
				if('undefined' == typeof console || 'undefined' == typeof DataView || 'undefined' == typeof WebSocket || null == v_b1 || null == v_b1.getContext || null == _win.localStorage) {
					alert('You browser does not support this game, we recommend you to use Firefox to play this')
				} else {
					var v_b2 = null;
					_win.setNick = function(_name, _team) {
						//_team = '';
						_win.ga && _win.ga('send', 'event', 'Nick', _name.toLowerCase());
						vn();
						game_playername_sending = _name;  //_team + _name;
						gSelfTeamName = _team;
						//game_playername_sending = _name;
						SendGameNickName();
						highest_score = 0;
						setLocalStorage('nick', _name);
						myApp.newGame();
						announcementSent = 0;
						EnterPlayer()
					};
					_win.setNickA = function() {
						var team = document.getElementById('team_name').value;
						var nick = document.getElementById('nick').value;
						setNick(nick, team);
					}
					_win.setRegion = vk;
					_win.setSkins = function(va) {
						v_8a = va
					};
					_win.setNames = function(va) {
						v_8b = va
					};
					_win.setDarkTheme = function(va) {
						v_8f = va
					};
					_win.setColors = function(va) {
						v_8c = va
					};
					_win.setShowMass = function(va) {
						v_90 = va
					};
					_win.connectIP = function(va) {
						var vd = va.trim();
						_jquery('#opt_connect_ip')['val'](vd);
						vd || ':party' != _jquery('#gamemode option:selected')['val']() ? 0 != vd.length && 6 >= vd.length ? v_62(va) : (console.log('connecting IP  =  ' + va), v_a6 = va, vl()) : createParty()
					};
					_win.getCurrentX = function() {
						return selfOwnedCells.length ? v_70 - (fieldRight - 7071.067811865476) : ''
					};
					_win.getCurrentY = function() {
						return selfOwnedCells.length ? v_71 - (fieldBottom - 7071.067811865476) : ''
					};
					_win.getTop1X = function() {
						return stopPositionX
					};
					_win.getTop1Y = function() {
						return stopPositionY
					};
					_win.getLengthX = function() {
						return 14142.135623730952
					};
					_win.getLengthY = function() {
						return 14142.135623730952
					};
					_win.getLB = function() {
						return leaderBoardList
					};
					_win.getSelfIDs = function() {
						return v_72
					};
					_win.getCell = function() {
						return selfOwnedCells
					};
					_win.getHighestScore = function() {
						return highest_score
					};
					_win.quickSpace = function() {
						0 != selfOwnedCells.length && (SendPlayerAction(17), setTimeout(function() {
							SendPlayerAction(17)
						}, 40), setTimeout(function() {
							SendPlayerAction(17)
						}, 80), setTimeout(function() {
							SendPlayerAction(17)
						}, 120))
					};
					_win.doubleSpace = function() {
						setTimeout(function() {
							SendPlayerAction(17)
						}, 50);
						setTimeout(function() {
							SendPlayerAction(17)
						}, 100)
					};
					_win.getFPS = function() {
						return v_a7
					};
					_win.getPacketIO = function() {
						return [v_ad, v_ae]
					};
					_win.spectate = function() {
						isJoinedGame = 0;
						spectateMode = 1;
						game_playername_sending = null;
						SendPlayerAction(1);
						vn();
						myApp.spectate(selfOwnedCells);
						var va = CreatePlayerEntryData('spectate');
						conn.emit('playerEntered', va);
						skinProvider.requestBroadcastSkins();
					};
					_win.setGameMode = function(va) {
						va != v_94 && (':party' == v_94 && _jquery('#helloContainer')['attr']('data-party-state', '0'), vz(va), ':party' != va && vl())
					};
					_win.setZoomLevel = function(va) {
						v_a1 = va
					};
					_win.isFreeSpec = function() {
						return myApp.isSpectating && 0.25 === v_aa
					};
					_win.setAcid = function(va) {
						v_9e = va
					};
					null != _win.localStorage && (null == _win.localStorage['AB9'] && (_win.localStorage['AB9'] = 0 + ~~(100 * Math.random())), v_9c = +_win.localStorage['AB9'], _win.ABGroup = v_9c);
					var v_b3 = null;
					_win.connect = connectToGameServer;
					var v_b4 = 500,
						v_b5 = null,
						v_b6 = 0,
						bPositionX = -1,
						bPositionY = -1,
						v_b9 = null,
						v_ba = 1,
						animationFrameFuncRoot = function() {
							Date.now();
							var vb = 0,
								vd = Date.now();
							return function() {
								try {
									_win.requestAnimationFrame(animationFrameFuncRoot);
									var ve = Date.now();
									myApp.isShowFPS && (1E3 < vb ? (vd = ve, vb = 0, v_a7 = v_7c, v_7c = 0) : vb = ve - vd);
									(!IsDocumentReady() || 240 > Date.now() - v_a0) && updateFrame();
									v_c2()
								} catch(e) {
									console.log(e);
								}
							}
						}(),
						v_bc = {},
						v_bd = 'poland;usa;china;russia;canada;australia;spain;brazil;germany;ukraine;france;sweden;chaplin;north korea;south korea;japan;united kingdom;earth;greece;latvia;lithuania;estonia;finland;norway;cia;maldivas;austria;nigeria;reddit;yaranaika;confederate;9gag;indiana;4chan;italy;bulgaria;tumblr;2ch.hk;hong kong;portugal;jamaica;german empire;mexico;sanik;switzerland;croatia;chile;indonesia;bangladesh;thailand;iran;iraq;peru;moon;botswana;bosnia;netherlands;european union;taiwan;pakistan;hungary;satanist;qing dynasty;matriarchy;patriarchy;feminism;ireland;texas;facepunch;prodota;cambodia;steam;piccolo;ea;india;kc;denmark;quebec;ayy lmao;sealand;bait;tsarist russia;origin;vinesauce;stalin;belgium;luxembourg;stussy;prussia;8ch;argentina;scotland;sir;romania;belarus;wojak;doge;nasa;byzantium;imperial japan;french kingdom;somalia;turkey;mars;pokerface;8;irs;receita federal;facebook;putin;merkel;tsipras;obama;kim jong-un;dilma;hollande;berlusconi;cameron;clinton;hillary;venezuela;blatter;chavez;cuba;fidel;merkel;palin;queen;boris;bush;trump'['split'](';'),
						v_be = '8;nasa;putin;merkel;tsipras;obama;kim jong-un;dilma;hollande;berlusconi;cameron;clinton;hillary;blatter;chavez;fidel;merkel;palin;queen;boris;bush;trump'['split'](';'),
						v_bf = {};



					Date.now || (Date.now = function() {
						return (new Date)['getTime']()
					});

					(function() {
						for(var vb = ['ms', 'moz', 'webkit', 'o'], vd = 0; vd < vb.length && !_win.requestAnimationFrame; ++vd) {
							_win.requestAnimationFrame = _win[vb[vd] + 'RequestAnimationFrame'], _win.cancelAnimationFrame = _win[vb[vd] + 'CancelAnimationFrame'] || _win[vb[vd] + 'CancelRequestAnimationFrame']
						};
						_win.requestAnimationFrame || (_win.requestAnimationFrame = function(va) {
							return setTimeout(va, 1E3 / 60)
						}, _win.cancelAnimationFrame = function(va) {
							clearTimeout(va)
						})
					})();
					var onWindowLoadedJQ = function() {
						var va = new GameObject(0, 0, 0, 32, '#ED1C24', ''),
							canvas = document.createElement('canvas');
						canvas.width = 32;
						canvas.height = 32;
						var ctx = canvas.getContext('2d');
						return function() {
							0 < selfOwnedCells.length && (va.color = selfOwnedCells[0]['color'], va.setGameObjectName(selfOwnedCells[0]['name']));
							ctx.clearRect(0, 0, 32, 32);
							ctx.save();
							ctx.translate(16, 16);
							ctx.scale(0.4, 0.4);
							va.drawGameObject(ctx);
							ctx.restore();
							var fvc = document.getElementById('favicon'),
								ve = fvc.cloneNode(1);
							fvc.parentNode['replaceChild'](ve, fvc)
						}
					}();
					_jquery(function() {
						onWindowLoadedJQ()
					});
					var v_c1 = 'loginCache3';
					_jquery(function() {
						if(+_win.localStorage['wannaLogin']) {
							if(_win.localStorage[v_c1]) {
								var vd = _win.localStorage[v_c1];
								'string' == typeof vd && (vd = JSON.parse(vd));
								Date.now() + 18E5 > vd.expires ? _jquery('#helloContainer')['attr']('data-logged-in', '0') : (_win.localStorage[v_c1] = JSON.stringify(vd), _jquery('.agario-profile-name')['text'](vd.name), v_59(), v_5e({
									e: vd.xp,
									c: vd.xpNeeded,
									d: vd.level
								}), _jquery('#helloContainer')['attr']('data-logged-in', '1'))
							};
							_win.localStorage['fbPictureCache'] && _jquery('.agario-profile-picture')['attr']('src', _win.localStorage['fbPictureCache'])
						}
					});
					_win.facebookLogin = function() {
						_win.localStorage['wannaLogin'] = 1
					};
					_win.fbAsyncInit = function() {
						function vb() {
							_win.localStorage['wannaLogin'] = 1;
							null == _win.FB ? alert('You seem to have something blocking Facebook on your browser, please check for any extensions') : _win.FB['login'](function(va) {
								console.log(va);
								v_5f(va)
							}, {
								scope: 'public_profile, email'
							})
						}
						_win.FB['init']({
							appId: '677505792353827',
							cookie: 1,
							xfbml: 1,
							status: 1,
							version: 'v_2.2'
						});
						_win.FB['Event']['subscribe']('auth.statusChange', function(vd) {
							+_win.localStorage['wannaLogin'] && ('connected' == vd.status ? v_5f(vd) : vb())
						});
						_win.facebookLogin = vb
					};
					_win.logout = function() {
						_jquery('#helloContainer')['attr']('data-logged-in', '0');
						_jquery('#helloContainer')['attr']('data-has-account-data', '0');
						delete _win.localStorage['wannaLogin'];
						delete _win.localStorage[v_c1];
						delete _win.localStorage['fbPictureCache'];
						vl();
						$('.btn-spectate')['prop']('disabled', 0)
					};
					var v_c2 = function() {
						function va(vb, vd, ve, vf, vi) {
							var vj = vd.getContext('2d'),
								v_4f = vd.width;
							vd = vd.height;
							vb.color = vi;
							vb.setGameObjectName(ve);
							vb.size = vf;
							vj.save();
							vj.translate(v_4f / 2, vd / 2);
							vb.drawGameObject(vj);
							vj.restore()
						}
						for(var vd = new GameObject(-1, 0, 0, 32, '#5bc0de', ''), ve = new GameObject(-1, 0, 0, 32, '#5bc0de', ''), vf = '#0791ff #5a07ff #ff07fe #ffa507 #ff0774 #077fff #3aff07 #ff07ed #07a8ff #ff076e #3fff07 #ff0734 #07ff20 #ff07a2 #ff8207 #07ff0e'['split'](' '), vi = [], vj = 0; vj < vf.length; ++vj) {
							var angle = vj / vf.length * 12,
								dist = 30 * Math.sqrt(vj / vf.length);
							vi.push(new GameObject(-1, Math.cos(angle) * dist, Math.sin(angle) * dist, 10, vf[vj], ''))
						};
						v_5d(vi);
						var vk = document.createElement('canvas');
						vk.getContext('2d');
						vk.width = vk.height = 70;
						va(ve, vk, '', 26, '#ebc0de');
						return function() {
							_jquery('.cell-spinner')['filter'](':visible')['each'](function() {
								var ve = _jquery(this),
									vf = Date.now(),
									vi = this.width,
									vj = this.height,
									vg = this.getContext('2d');
								vg.clearRect(0, 0, vi, vj);
								vg.save();
								vg.translate(vi / 2, vj / 2);
								for(var vh = 0; 10 > vh; ++vh) {
									vg.drawImage(vk, (0.1 * vf + 80 * vh) % (vi + 140) - vi / 2 - 70 - 35, vj / 2 * Math.sin((0.001 * vf + vh) % Math.PI * 2) - 35, 70, 70)
								};
								vg.restore();
								(ve = ve.attr('data-itr')) && (ve = vm(ve));
								va(vd, this, ve || '', +_jquery(this)['attr']('data-size'), '#5bc0de')
							});
							_jquery('#statsPellets')['filter'](':visible')['each'](function() {
								_jquery(this);
								var vd = this.width,
									ve = this.height;
								this.getContext('2d')['clearRect'](0, 0, vd, ve);
								for(vd = 0; vd < vi.length; vd++) {
									va(vi[vd], this, '', vi[vd]['size'], vi[vd]['color'])
								}
							})
						}
					}();
					_win.createParty = function() {
						vz(':party');
						v_b3 = function(vd) {
							v_63('/#' + _win.encodeURIComponent(vd));
							_jquery('.partyToken')['val'](_win.encodeURIComponent(vd));
							_jquery('#helloContainer')['attr']('data-party-state', '1')
						};
						vl();
						isJoinedGame = 0;
						$('.btn-spectate')['prop']('disabled', 0)
					};
					_win.joinParty = v_62;
					_win.cancelParty = function() {
						v_63('/');
						_jquery('#helloContainer')['attr']('data-party-state', '0');
						vz('');
						vl()
					};
					var v_c3 = [],
						v_c4 = 0,
						v_c5 = '#000000',
						v_c6 = 0,
						v_c7 = 0,
						v_c8 = 0,
						v_c9 = 0,
						v_ca = 0,
						v_cb = 0,
						v_cc = 0,
						v_cd = 1;
					setInterval(function() {
						v_c7 && v_c3.push(calcCurrentScore() / 100)
					}, 1E3 / 60);
					setInterval(function() {
						var va = v_66();
						0 != va && (++v_ca, 0 == v_cc && (v_cc = va), v_cc = Math.min(v_cc, va))
					}, 1E3);
					_win.closeStats = function() {
						v_c6 = 0;
						_jquery('#stats')['hide']();
						vi(0)
					};
					_win.setSkipStats = function(va) {
						v_cd = !va
					};
					_jquery(function() {
						_jquery(vf)
					})
				}
			}
		}
	};
	loadGameCore(window, window.jQuery);

	myApp.afterGameLogicLoaded();

	conn2.setChatListenerProc(chatRoom.receiveMessage.bind(chatRoom));
	conn2.setMapListenerProc(minimap.updateNode.bind(minimap));
	conn2.setSkinListenerProc(skinProvider.receiveSkinInfo.bind(skinProvider));
	conn2.setSkinRequestedProc(skinProvider.skinRequested.bind(skinProvider));

	//300
	function initialize_misc() {

		$(document)['keydown'](function(va) {
			if('input' != va.target['tagName']['toLowerCase']() && 'textarea' != va.target['tagName']['toLowerCase']() || 13 == va.keyCode) {
				var vb = '';
				isValidHotKey(va) && (vb = getPressedKey(va));
				18 == va.keyCode && va.preventDefault();
				if(selectedHotkeyRow) {
					if(46 == va.keyCode) {
						va.preventDefault(), selectedHotkeyRow.find('.hotkey')['text'](vb)
					} else {
						if('' != vb) {
							va.preventDefault();
							for(var vf = $('.hotkey'), vg = 0; vg < vf.length; vg++) {
								if($(vf[vg])['text']() == vb) {
									return
								}
							}
							;
							selectedHotkeyRow.find('.hotkey')['text'](vb);
							selectedHotkeyRow.removeClass('table-row-selected');
							selectedHotkeyRow = null
						}
					}
				}
				;
				'' != vb && hotkeyMapping[vb] && (va.preventDefault(), hotkeyConfig[hotkeyMapping[vb]] && hotkeyConfig[hotkeyMapping[vb]]['keyDown'] && hotkeyConfig[hotkeyMapping[vb]]['keyDown']())
			}
		});


		$(document)['keyup'](function(va) {
			if('input' != va.target['tagName']['toLowerCase']() && 'textarea' != va.target['tagName']['toLowerCase']() || 13 == va.keyCode) {
				var vb = '';
				isValidHotKey(va) && (vb = getPressedKey(va));
				'' != vb && hotkeyMapping[vb] && (va.preventDefault(), hotkeyConfig[hotkeyMapping[vb]] && hotkeyConfig[hotkeyMapping[vb]]['keyUp'] && hotkeyConfig[hotkeyMapping[vb]]['keyUp']())
			}
		});


		$('#overlays2')['mousedown'](function(va) {
			0 === va.button ? !myApp.isEnableMouseW || 'input' == va.target['tagName']['toLowerCase']() && 'textarea' == va.target['tagName']['toLowerCase']() || (myApp.autoW = 1, handleQuickW(), va.preventDefault()) : 2 === va.button && $('#opt_chatbox__INVALID_TAG_FOR_DISABLE_STATEMENT__')['click']()
		});


		$('#overlays2')['mouseup'](function(va) {
			0 === va.button && myApp.isEnableMouseW && 'input' != va.target['tagName']['toLowerCase']() && 'textarea' != va.target['tagName']['toLowerCase']() && (myApp.autoW = 0, va.preventDefault())
		});

		function isValidHotKey(va) {
			return 48 <= va.keyCode && 57 >= va.keyCode || 65 <= va.keyCode && 90 >= va.keyCode || 9 == va.keyCode || 13 == va.keyCode ? 1 : 0
		}

		function getPressedKey(va) {
			var vb = '';
			va.ctrlKey && (vb += 'CTRL_');
			va.altKey && (vb += 'ALT_');
			return vb = 9 == va.keyCode ? vb + 'TAB' : 13 == va.keyCode ? vb + 'ENTER' : vb + String.fromCharCode(va.keyCode)
		}

		function copyToClipboard(va) {
			window.postMessage({
				action: Action.COPY,
				data: va
			}, '*')
		}

		window.onbeforeunload = function() {
			return 'You are leaving Agar.io.'
		};

		function escapeRegex(va) {
			return va.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, '\$&')
		}

		var disconnectTimeout;
		$(window)['focus'](function() {
			isWindowFocus = 1;
			disconnectTimeout && clearTimeout(disconnectTimeout)
		})['blur'](function() {
			isWindowFocus = 0
		});
		jQuery.cachedScript = function(va, vb) {
			vb = $['extend'](vb || {}, {
				dataType: 'script',
				cache: 1,
				url: va
			});
			return jQuery.ajax(vb)
		};

		function drawMinimapNodes() {
			minimap.uploadSelfPosition();
			setTimeout(drawMinimapNodes, 1000);  //1E3)
		}

		if(UseOgarMapImpl){
			minimap.start();
		}else{
			drawMinimapNodes();
		}

		updateGameInfoDiv();

		function updateGameInfoDiv() {
			$('#overlays')['is'](':visible') && myApp.updateLBInfo();
			setTimeout(updateGameInfoDiv, 1E3)
		}

		clearOldNodesData();

		function clearOldNodesData() {
			for(var va = 1; va < nodeList.length; va++) {
				var vb = nodeList[va][8];
				vb && 5E3 < Date.now() - vb && (2 > va ? (nodeList[va][2] = null, nodeList[va][3] = null) : nodeList[va][0] = 'del')
			}
			;
			setTimeout(clearOldNodesData, 5E3)
		}

		updateLbDiv();

		var leaderboardTeamColors = {
			'〖ƝƁƘ〗' : '#FF0000',
			'ƬψƬ' : '#008000',
			'ƵŦ' : '#000000',
			'[Fire]' : '#FF8C00',


		};

		function updateLbDiv() {
			if($('#div_lb')['is'](':visible')) {
				var lbs = getLB(),
					vb = getSelfIDs(),
					vf = '';
				if(lbs) {
					for(var i = 0; i < lbs.length; i++) {
						for(var vh = 0, vd = 0; vd < vb.length; vd++) {
							if(vb[vd] == lbs[i]['id']) {
								vh = 1;
								break
							}
						}
						;

						vd = lbs[i]['name'] ? escapeHtml(lbs[i]['name']) : 'An unnamed cell';

						if(EnableLeaderboardTeamColoring){
							var col = "#FFFFFF";
							var name = vd;
							for(var key in leaderboardTeamColors){
								if(name.startsWith(key)){
									col = leaderboardTeamColors[key];
								}
							}
							//var col = 'red';
							//vf = vh ? vf + "<div class='self'>" :
							vf = vf + '<div style="color:' + col + '">';
						}else{
							vf = vh ? vf + "<div class='self'>" : vf + '<div>';
						}

						vf += i + 1 + '. ' + vd + '</div>'
					}
				}
				;
				document.getElementById('lb_detail')['innerHTML'] = vf
			}
			;
			setTimeout(updateLbDiv, 1E3)
		}

		updateScoreDiv();

		function updateScoreDiv() {
			var score = getHighestScore(),
				cell = getCell(),
				vf = [];
			0 != score && (myApp.isShowScroll && vf.push('Score: ' + ~~(score / 100)), cell && 0 < cell.length && (myApp.isShowSTE && (score = myApp.getSTE(cell), vf.push('STE: ' + score)), myApp.isShowBallTotal && vf.push('[' + cell.length + '/16]')));
			myApp.isShowFPS && (cell = getFPS(), 50 >= cell ? cell += 8 : 45 >= cell ? cell += 10 : 40 >= cell && (cell += 15), vf.push('FPS: ' + cell));
			isFreeSpec() && myApp.specTeammate && myApp.isStopMovement && nodeList[myApp.specTeammate] && vf.push('SPEC: ' + nodeList[myApp.specTeammate][1]);
			myApp.testing && vf.push('*** TESTING ***');
			0 < vf.length ? ($('#div_score')['is'](':visible') || $('#div_score')['show'](), document.getElementById('div_score')['innerHTML'] = vf.join('&nbsp;&nbsp;&nbsp;')['trim']()) : $('#div_score')['hide']();
			setTimeout(updateScoreDiv, 500)
		}

		//$['cachedScript']('https://cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/0.6.8/js/min/perfect-scrollbar.jquery.min.js')['done'](function (va, vb) {
		$['cachedScript']('js/perfect-scrollbar.jquery.min.js')['done'](function(va, vb) {
			chatRoom.createScrollBar()
		});

		//$['cachedScript']('http://extension.agarplus.io/jquery.toast.min.js')['done'](function (va, vb) {
		$['cachedScript']('js/jquery.toast.min.js')['done'](function(va, vb) {
			for(var vf; vf = toastQueue.shift() ;) {
				chatRoom.popup(vf)
			}
		});
		$('#gamemode')['parent']()['append']('<div id="testing_div"> <div id="lbl_testing" style="height:20px;">Testing : </div><input value="' + testingVal + '" type="text" id="testing" class="form-control" placeholder="Testing data"></div>');
		$('#testing')['change'](function() {
			testingVal = Number($('#testing')['val']());
			console.log('testingVal=' + testingVal)
		});
		$('#testing_div')['hide']();
		$('.agario-profile-picture')['hide']();
		$('.agario-profile-name-container')['hide']();
		$('.agario-profile-panel')['click'](function() {
			$('.agario-profile-picture')['is'](':visible') ? ($('.agario-profile-picture')['hide'](), $('.agario-profile-name-container')['hide']()) : ($('.agario-profile-picture')['show'](), $('.agario-profile-name-container')['show']())
		});
		var handleResource = function(a, b) {
			q
			if(!a || !b) {
				console.log(' ** null in download object url, return;')
			} else {
				if(!customSkin[a]) {
					var img = new Image;
					img.onload = function() {
						customSkin[a] = this;
						myApp.getCustomSkinUrl() == a && myApp.changePreviewImage(this.src)
					};
					img.onerror = function() {
						window.URL['revokeObjectURL'](b);
						skinDownloadFail[a] = skinDownloadFail[a] ? skinDownloadFail[a] + 1 : 1;
						console.log('Load image error')
					};
					img.src = b
				}
			}
		};
		/*
		$('#backgroundColor')['minicolors']({
			defaultValue: getLocalStorage('backgroundColor') || '#000000',
			change: function(va, vb) {
				setLocalStorage('backgroundColor', va);
				$('body')['css']('background-color', va)
			}
		});
		$('body')['css']('background-color', getLocalStorage('backgroundColor') || '#000000');
		$('#borderColor')['minicolors']({
			defaultValue: getLocalStorage('borderColor') || '#ffffff',
			change: function(va, vb) {
				setLocalStorage('borderColor', va)
			}
		});
		$('#pelletColor')['minicolors']({
			defaultValue: getLocalStorage('pelletColor') || '#0849d4',
			change: function(va, vb) {
				setLocalStorage('pelletColor', va);
				$('.sender')['css']('color', va);
				$('.toast_sender')['css']('color', va);
				$('#div_lb .header')['css']('color', va)
			}
		});
		$('.sender')['css']('color', getLocalStorage('pelletColor') || '#0849d4');
		$('.toast_sender')['css']('color', getLocalStorage('pelletColor') || '#0849d4');
		$('#div_lb .header')['css']('color', getLocalStorage('pelletColor') || '#0849d4');
		*/


		$('#backgroundColor')['minicolors']({
			defaultValue: getLocalStorage('backgroundColor') || '#ffffff',
			change: function(va, vb) {
				setLocalStorage('backgroundColor', va);
				$('body')['css']('background-color', va)
			}
		});
		$('body')['css']('background-color', getLocalStorage('backgroundColor') || '#ffffff');
		$('#borderColor')['minicolors']({
			defaultValue: getLocalStorage('borderColor') || '#d1d1d1',
			change: function(va, vb) {
				setLocalStorage('borderColor', va)
			}
		});
		$('#pelletColor')['minicolors']({
			defaultValue: getLocalStorage('pelletColor') || '#2869f7',
			change: function(va, vb) {
				setLocalStorage('pelletColor', va);
				$('.sender')['css']('color', va);
				$('.toast_sender')['css']('color', va);
				$('#div_lb .header')['css']('color', va)
			}
		});
		$('.sender')['css']('color', getLocalStorage('pelletColor') || '#2869f7');
		$('.toast_sender')['css']('color', getLocalStorage('pelletColor') || '#2869f7');
		$('#div_lb .header')['css']('color', getLocalStorage('pelletColor') || '#2869f7');
	}
	initialize_misc();

	//マウス操作補助機能のセットアップ, 400
	function initialize_mouse_support() {
		"use strict";

		//デバッグ表示
		function trace(s) {
			console.log(s);
		}

		//右クリックによるコンテキストメニュー表示を抑止
		function setup_prevent_contextmenu() {
			$(document).on("contextmenu", function(event) {
				event.preventDefault();
			});
		}

		//仮想キーイベントを生成
		function raise_virtual_key_event(char, is_press) {
			var type = is_press ? "keydown" : "keyup";
			var code = char.charCodeAt(0);
			$("body").trigger($.Event(type, { keyCode: code }));
		}

		//仮想キーストロークを生成
		function raise_virtual_key_stroke(char) {
			raise_virtual_key_event(char, true);
			raise_virtual_key_event(char, false);
		}

		//マウスによる操作
		function setup_mouse_handlers() {
			//マウスボタン定数
			var MouseButtonLeft = 1;
			var MouseButtonMiddle = 2;
			var MouseButtonRight = 3;



			//トリガ発行後、周期的に一定回数キーを連打するクラス
			class FixedCountKeyRepeater {
				constructor(target_key, interval_ms, num_fires) {
					this.target_key = target_key;
					this.interval_ms = interval_ms;
					this.num_fires = num_fires;
				}

				trigger() {
					var count = 0;
					var self = this;
					var ti = setInterval(function() {
						raise_virtual_key_stroke(self.target_key);
						if(++count >= self.num_fires) {
							clearInterval(ti);
						}
					}, this.interval_ms);
				}
			}

			//初回ディレイと周期を設定し、継続的にキーを連打するクラス
			class SlowStartKeyRepeater {
				constructor(target_key, first_delay_ms, interval_ms) {
					this.target_key = target_key;
					this.first_delay_ms = first_delay_ms;
					this.interval_ms = interval_ms;

					this.timer0 = null;
					this.timer1 = null;
				}

				start() {
					var self = this;
					var fire = function() {
						raise_virtual_key_stroke(self.target_key);
					}

					this.timer0 = setTimeout(function() {
						self.timer1 = setInterval(fire, self.interval_ms);
					}, this.first_delay_ms);
					fire();
				}

				stop() {
					if(this.timer0 !== null) {
						clearTimeout(this.timer0);
						this.timer0 = null;
					}
					if(this.timer1 !== null) {
						clearInterval(this.timer1);
						this.timer1 = null;
					}
				}
			}

			function is_overlays_visible() {
				return $("#overlays").css("display") === "block";
			}



			//操作を行うボタンの割り当て
			var btSplit = MouseButtonLeft;
			var btFeed = MouseButtonRight;
			var btQuickSplit = MouseButtonMiddle;
			/*
			if(SwapMouseButtonsLR) {
				btSplit = MouseButtonRight;
				btFeed = MouseButtonLeft;
			}
			*/

			//if(MouseSupportEnabled) {
			//餌,キー連打機能インスタンス
			var krFeeding = new SlowStartKeyRepeater('W', 250, 5);　//キー,初期ディレイ[ms],周期[ms]

			//16分裂,キー連打機能インスタンス
			var krQuickSplit = new FixedCountKeyRepeater(' ', 30, 10); //キー,周期[ms],回数

			var Feed_flg = 0;

			$(document).mousedown(function(ev) {
				if(is_overlays_visible()) return;

				var enabled = myApp.isEnableMouseControl;
				if(!enabled) return;

				//ボタン割り当て更新
				var swapLR = myApp.swapMouseButtonsLR;
				btSplit = MouseButtonLeft;
				btFeed = MouseButtonRight;
				if(swapLR) {
					btSplit = MouseButtonRight;
					btFeed = MouseButtonLeft;
				}

				var bt = ev.which;
				if(bt == btSplit) {
					//分裂
					raise_virtual_key_stroke(" ");
				} else if(bt == btFeed) {
					//餌
					if(!Feed_flg) {
						krFeeding.start();
						Feed_flg = 1;
					}
					//ev.preventDefault();
					var selection = window.getSelection();
					selection.collapse(document.body, 0);

				} else if(bt == btQuickSplit) {
					//16分裂
					krQuickSplit.trigger();
				}

				/*
				if(bt == MouseButtonRight) {
					//右クリック時に,チャット表示がon/offするのを常に表示で固定
					$("#chatbox, #chatroom").css("display", "block");
				}*/
			});

			$(document).mouseup(function(ev) {
				var bt = ev.which;
				if(bt == btFeed) {
					krFeeding.stop();
					Feed_flg = 0;
				}
				ev.preventDefault();
			});

			$(document).on("dragend", function(e) {
				krFeeding.stop();
			});

			$(document).on("dragstart", function(e) {
				setTimeout(function() {
					var selection = window.getSelection();
					selection.collapse(document.body, 0);
				}, 10);
			});
			//}
		}

		//画面中心にクロスヘアを表示
		function setup_center_crosshair() {
			//ゲーム画面の描画が乱れるバグがあるため現在未使用

			var update_crosshair_canvas = function() {
				var canvas = $("#frontCanvas").get(0);
				canvas.width = window.innerWidth;
				canvas.height = window.innerHeight;

				var ctx = canvas.getContext('2d');
				var cx = canvas.width / 2;
				var cy = canvas.height / 2;
				var d = 100;
				ctx.strokeStyle = "#888";
				ctx.beginPath();
				ctx.moveTo(cx, cy - d);
				ctx.lineTo(cx, cy + d);
				ctx.moveTo(cx - d, cy);
				ctx.lineTo(cx + d, cy);
				ctx.closePath();
				ctx.stroke();
			};

			if(ShowCenterCrosshair) {
				$("body").append('<canvas id="frontCanvas" style="zposition: absolute; z-index:222; top : 0; pointer-events:none"/>');
				$("#frontCanvas").css("-webkit-user-select", "none");

				window.onresize = update_crosshair_canvas;
				update_crosshair_canvas();
			}
		}

		//チャットボックスを左上に小さく表示
		function update_chatbox_leftsmall() {
			//function update_chatroom_view() {
			var croom = $("#chatroom");
			croom.css("display", "block");
			croom.css("width", "150px");
			croom.css("height", "150px");
			croom.css("top", "50px");
			croom.css("left", "15px");
			//var span = $("#chatroom span");
			//span.css("font-size", "12px");
			//}

			//update_chatroom_view();
			//window.onresize = update_chatroom_view;
			//setInterval(update_chatroom_view, 1000);
		}

		//チャットボックスを下に横長に表示
		function update_chatbox_bottom_horizontal() {

			//var croom = $("#chatbox, #chatroom");
			//croom.css("width", "750px");
			//croom.css("height", "100px");
			//function update_chatroom_view() {
			var cr_width = 750;
			var cr_height = 100;
			var chatroom = $("#chatbox, #chatroom");
			chatroom.css("width", cr_width + "px");
			chatroom.css("height", cr_height + "px");
			chatroom.css("display", "block");
			chatroom.css("min-height", "10px");
			chatroom.css("left", (window.innerWidth - cr_width) / 2);
			chatroom.css("top", window.innerHeight - cr_height - 25);

			//var span = $("#chatroom span");
			//span.css("font-size", "12px");
			//}
			//window.onresize = update_chatroom_view;
			//update_chatroom_view();
			//setInterval(update_chatroom_view, 100);
		}

		//チャットボックスの表示を調整
		function setup_chatbox_customized() {
			/*
			if(ChatDisplayMode === "Normal") {
	
			} else if(ChatDisplayMode === "LeftSmall") {
				setup_chatbox_leftsmall();
			} else if(ChatDisplayMode === "BottomHorizontal") {
				setup_chatbox_bottom_horizontal();
			}
			*/

			//myApp.showChatAtBottom = false;
			var isBottom = myApp.showChatAtBottom;

			function arrange_chatroom_view() {
				if(isBottom) {
					update_chatbox_bottom_horizontal();
				} else {
					update_chatbox_leftsmall();
				}
			}

			setInterval(function() {
				if(myApp.showChatAtBottom !== isBottom) {
					isBottom = myApp.showChatAtBottom;
					arrange_chatroom_view();
				}
			}, 100);

			$(window).resize(function() {
				arrange_chatroom_view();
				//trace("resized");
			});
			arrange_chatroom_view();
		}

		//ダブルクリック時のマップの選択を抑止
		function setup_disable_user_select() {
			setInterval(function() {
				$("#minimap, #minimapNode").css("-webkit-user-select", "none");
			}, 1000);
		}

		//プライベートサーバーに接続
		function connect_to_private_server() {
			var uri = modifyUrlForLocalhostConnection(GameServerAddress);
			/*
			//urlのクエリ文字列によるローカル接続オプション対応
			var html_query_str = location.search;
			var req_local_connection = html_query_str === "?localhost=1";
			if(req_local_connection) {
				var port = PrivateServerAddress.split(":")[2];
				uri = "ws://localhost:" + port;
			}
			*/
			connect(uri);
		}

		//キーボードによる操作
		function setup_key_handlers() {
			$(document).on('keydown', function(e) {
				var keyF9 = 120;
				if(e.keyCode === keyF9) {
					//プライベートサーバーに接続
					//連打はやめましょう
					connect_to_private_server();
				}
			});
		}

		//メインパネル,プロファイルパネルの調整
		function setup_panel_customize() {
			//パーティートークン生成ボタンをプライベートサーバー接続ボタンに変更
			//{
			//	$(".createParty").remove();
			//	$(".agarioProfilePanel").append("<button id='btConnect'></button>");
			//	var bt = $("#btConnect");
			//	bt.addClass("btn btn-primary");
			//	bt.css("margin-bottom", "5px");
			//	bt.css("font-family", "メイリオ");
			//	bt.css("letter-spacing", "0px");
			//	bt.css("height", "35px");
			//	bt.text("プライベートサーバーに接続");
			//	bt.on("click", function() {
			//		connect_to_private_server();
			//	});
			//}


			//$(".createParty").remove();
			//$(".btConnect").remove();

			//$(".agarioProfilePanel").css("padding-bottom", "45px");

			//リージョンを非選択にする
			//$("#gamemode").val(":party");

			//サーバ,ゲームモードの選択セレクタを削除
			//$("#region").remove();
			//$("#gamemode").remove();

			//Joinボタンを削除
			//$(".joinParty").remove();

			//画面真ん中の広告を削除
			//$(".adsbygoogle").remove();

			//コードを入力
			//$(".partyToken").val(FixedPartyCode);
			$(".partyToken").val("");
			//$(".btn-login").remove();

			//$(".btn-spectate").css("width", "100%");
		}


		//スキンがプレビュー表示されない問題の対策
		function setup_skin_preview_fix() {
			//オリジンがAgar.io以外の場合に問題がおこる(?)
			//XMLHttpRequestを使わず、直接URL指定で表示するように調整

			function update_skin_preview() {
				var ref_img = localStorage.getItem("skin_url");
				var img = $("#preview-img")[0];
				if(img.src !== ref_img) {
					img.src = ref_img;
				}
			}

			//$(window).bind("storage", function(e) {
			//	trace(e.originalEvent.key, e.originalEvent.newValue);
			//	update_skin_preview();
			//	//console.log(e.)
			//});

			//setInterval(function() {
			//	update_skin_preview();
			//}, 200);

			//$("#profile-pic div.nav2").on("click", function() {
			//	update_skin_preview();
			//});	

			$("#skin_url").on("change", function() {
				update_skin_preview();
			});
			update_skin_preview();
		}

		function setup_remote_console() {
			function openRemoteConsoleWindow() {
				//trace('open remote console');
				window.GameServerAddress = modifyUrlForLocalhostConnection(GameServerAddress);
				window.open('remote_console.html', 'remote console', 'width=600, height=600, menubar=no, toolbar=no, scrollbars=no');
			}
			$(window).on('keydown', function(e) {
				var key = e.keyCode;
				var kF10 = 121;
				//var kEnter = 13;
				if(e.shiftKey && key == kF10 && RemoteConsoleEnabled) {
					openRemoteConsoleWindow();
				}
			});
		}


		//trace("agar.io mouse support tool, v1_160512_A127");
		setup_prevent_contextmenu();
		setup_mouse_handlers();
		setup_key_handlers();
		setup_disable_user_select();

		setup_chatbox_customized();

		//setup_center_crosshair();
		setup_panel_customize();
		//connect_to_private_server();

		//setup_skin_preview_fix();

		document.title = WebPageTitle;

		//setup_remote_console();
	}
	initialize_mouse_support();

	/*
	function XMLHttpRequestCreate(){
	try{
		return new XMLHttpRequest();
	}catch(e){}
	try{
		return new ActiveXObject('MSXML2.XMLHTTP.6.0');
	}catch(e){}
	try{
		return new ActiveXObject('MSXML2.XMLHTTP.3.0');
	}catch(e){}
	try{
		return new ActiveXObject('MSXML2.XMLHTTP');
	}catch(e){}

	return null;
	}
	var xhr = XMLHttpRequestCreate();
	xhr.onreadystatechange = function (){

		switch(xhr.readyState){
		case 4:
			if(xhr.status != 0){
				if((200 <= xhr.status && xhr.status < 300) || (xhr.status == 304)){
					var Data = JSON.parse(xhr.responseText);
					document.getElementById('pinfo')['innerHTML'] = "<center>"+Data.current_players + "/" + Data.max_players + " (play=" + Data.alive + " + spec=" + Data.spectators + ") " + "</center>";
				}
			}
			break;
		}
	};

	setInterval(function(){
		var uri = modifyUrlForLocalhostConnection(StatusServerAddress);
		xhr.open('POST', uri);
		xhr.send();
	}, 3000);
	*/
}
